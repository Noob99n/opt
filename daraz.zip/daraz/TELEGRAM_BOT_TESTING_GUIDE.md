# 🤖 Telegram Bot - Complete Testing Guide

## ✅ **Already Working Features:**

### 1. **Screenshot Forwarding with Approve/Decline Buttons**

**What happens:**
```
User uploads payment screenshot on website
     ↓
Automatically forwards to your Telegram
     ↓
Shows message with TWO BUTTONS:
  [✅ Approve]  [❌ Decline]
     ↓
You click the button you want
     ↓
Status updates in database automatically
     ↓
You get confirmation message
```

**Message Format:**
```
💳 New Payment Screenshot

📦 Product: Apple iPhone 16 Pro Max...
💰 Amount: Rs. 2,045
🕐 Time: 24/11/2025, 08:42:30
🆔 ID: abc123

⏳ Status: Pending Review

[Screenshot Image]
[✅ Approve Button] [❌ Decline Button]
```

**When you click:**
- **✅ Approve**: Payment marked as "approved", counts in total
- **❌ Decline**: Payment marked as "declined", doesn't count

---

## 📊 **Bot Commands Reference**

### 1. `/start`
Shows welcome message and all commands
```
🤖 Welcome Admin!

Available Commands:
📊 /status - View today's approved payment statistics
📄 /status_all - Export all transactions as TXT file
✅ /approve_all - Approve all pending payments
❌ /decline_all - Decline all pending payments
🔄 /change - Upload new QR code image
🗑️ /delete - Delete all transaction logs (requires confirmation)
```

---

### 2. `/status` - Today's Stats (ONLY APPROVED)
Shows today's payment statistics
```
📊 Today's Payment Statistics

📅 Date: 24/11/2025

💰 Total Submissions: 15
✅ Approved: 8
❌ Declined: 3
⏳ Pending: 4

💵 Total Collected (Approved Only): Rs. 6,500
```

**Important:** Total only includes APPROVED payments! ✅

---

### 3. `/status_all` - Export All Transactions
Exports complete transaction history as TXT file
```
📄 File sent: transactions_20251124.txt

Contents:
=== ALL TRANSACTION LOGS ===

1. Transaction ID: 674abc...
   Date: 24/11/2025, 08:30:15
   Product: iPhone 16 Pro Max
   Amount: Rs. 2,045
   Status: APPROVED
   User: guest
   ----------------------------------------

[... all transactions ...]

Total Transactions: 50
Approved: 30
Total Amount (All): Rs. 50,000
Total Collected (Approved Only): Rs. 30,000
```

---

### 4. `/change` - Upload New QR Code
Updates the QR code on website
```
Step 1: Send /change
Step 2: Bot asks for image
Step 3: Upload photo
Step 4: Bot confirms "✅ QR code updated!"
Step 5: Website automatically shows new QR
```

**Note:** QR URLs are temporary (Telegram CDN). For production, use Cloudinary (see PRODUCTION_NOTES.md)

---

### 5. `/approve_all` - Approve All Pending Payments

Approve all pending payments in one command!

**How it works:**
```
Step 1: Send /approve_all
  → Bot checks for pending payments

Step 2a: If pending payments exist
  → Bot approves all automatically
  → Shows summary:
      ✅ Bulk Approval Successful!
      📊 Approved Payments: 5
      💰 Total Amount: Rs. 10,225
      All pending payments have been approved.

Step 2b: If no pending payments
  → Bot: "⚠️ No pending payments to approve."
```

**Benefits:**
- ✅ Quick bulk approval
- ✅ Shows count and total amount
- ✅ Instant status update for all users
- ✅ Saves time when multiple payments

---

### 6. `/decline_all` - Decline All Pending Payments

Decline all pending payments in one command!

**How it works:**
```
Step 1: Send /decline_all
  → Bot checks for pending payments

Step 2a: If pending payments exist
  → Bot declines all automatically
  → Shows summary:
      ❌ Bulk Decline Successful!
      📊 Declined Payments: 3
      💰 Total Amount: Rs. 6,135
      All pending payments have been declined.

Step 2b: If no pending payments
  → Bot: "⚠️ No pending payments to decline."
```

**Use Cases:**
- ❌ Clear invalid/spam screenshots
- ❌ Reject old pending requests
- ❌ Quick cleanup at end of day

**Note:** Use with caution! This affects ALL pending payments at once.

---

### 7. `/delete` - Delete All Logs (3x Confirmation)

**How it works:**
```
Step 1: Send /delete
  → Bot: "Type /delete_confirm_1 to proceed"

Step 2: Send /delete_confirm_1
  → Bot: "Type /delete_confirm_2 to continue"

Step 3: Send /delete_confirm_2
  → Bot: "Type /delete_confirm_3 to DELETE ALL LOGS"

Step 4: Send /delete_confirm_3
  → Bot: "✅ All transaction logs deleted. Total deleted: X records"
```

**Safety:** 3 confirmations required to prevent accidental deletion!

---

## 🧪 **How to Test Everything**

### Test 1: Screenshot Upload & Individual Approval
```bash
1. Open website → Go to QR payment page
2. Upload any screenshot
3. Click "Verify Payment"
4. Check Telegram (should receive screenshot with buttons)
5. Click ✅ Approve button
6. Verify: Confirmation message appears
7. Send /status → Check approved count increased
```

### Test 2: Screenshot Upload & Decline
```bash
1. Upload another screenshot on website
2. Check Telegram (new screenshot with buttons)
3. Click ❌ Decline button
4. Verify: Decline confirmation message
5. Send /status → Check declined count increased
6. Verify: Total Collected did NOT increase ✅
```

### Test 3: /status Command
```bash
1. Send /status in Telegram
2. Verify: Shows today's stats
3. Check: Total Collected = Only approved payments
4. Math check: (Approved count × average amount) ≈ Total Collected
```

### Test 4: /status_all Export
```bash
1. Send /status_all in Telegram
2. Download TXT file
3. Open file
4. Verify: All transactions listed
5. Check: Two totals shown (All vs Approved Only)
```

### Test 5: QR Code Update
```bash
1. Send /change in Telegram
2. Upload a QR code image (any image works for testing)
3. Wait for confirmation: "✅ QR code updated!"
4. Open website QR payment page
5. Verify: New QR code visible
6. Try downloading QR → Should work ✅
```

### Test 6: Bulk Approve All
```bash
1. Upload 3-5 screenshots (create multiple pending)
2. Send /approve_all in Telegram
3. Verify: Confirmation with count and total
4. Send /status → Check all approved
5. Check website: All orders should show success
```

### Test 7: Bulk Decline All
```bash
1. Upload 2-3 screenshots (create pending)
2. Send /decline_all in Telegram
3. Verify: Decline confirmation message
4. Send /status → Declined count increased
5. Verify: Total Collected did NOT increase
6. Check website: Orders show failed/cancelled
```

### Test 8: Delete Command (CAREFUL!)
```bash
⚠️ WARNING: This will DELETE ALL transaction logs!
Only test if you're okay losing test data.

1. Send /delete
2. Follow prompts: /delete_confirm_1
3. Continue: /delete_confirm_2
4. Final: /delete_confirm_3
5. Verify: "✅ All transaction logs deleted"
6. Send /status → Should show 0 transactions
```

---

## 🔧 **Troubleshooting**

### Issue: "Not authorised" message
**Solution:** Bot only works for User ID: 7646520243
- Make sure you're using the correct Telegram account
- Check if ADMIN_USER_ID is set correctly in code

### Issue: Screenshot not forwarding to Telegram
**Possible causes:**
1. TELEGRAM_BOT_TOKEN not set in Replit Secrets
2. Bot not initialized (check server logs: "✅ Telegram bot initialized")
3. Image too large (max 5MB)
4. Invalid image format (must be PNG/JPG)

**Fix:**
```bash
1. Check logs: Look for "Error forwarding screenshot"
2. Verify token: Check Replit Secrets panel
3. Test with smaller image (<1MB)
```

### Issue: Approve/Decline buttons not working
**Possible causes:**
1. Database connection issue
2. Transaction ID invalid

**Fix:**
```bash
1. Check server logs for MongoDB errors
2. Try clicking button again
3. If persists, check database connection
```

### Issue: /delete command not working
**Possible causes:**
1. MongoDB connection not established
2. Permissions issue

**Debug:**
```bash
1. Check server logs after sending /delete_confirm_3
2. Look for "Error deleting logs: [message]"
3. Verify MongoDB connection is active
```

### Issue: QR code not downloading
**Already Fixed!** ✅
- Now uses proxy endpoint to bypass CORS
- Fallback to SVG if remote fetch fails

---

## 🎯 **Quick Reference - What Works Now**

```
✅ Screenshot forwarding to Telegram - WORKING
✅ Approve/Decline buttons on message - WORKING
✅ One-click approval system - WORKING
✅ /status shows approved-only total - WORKING
✅ /status_all export with details - WORKING
✅ /change QR code update - WORKING
✅ /delete with 3x confirmation - IMPLEMENTED
✅ QR download on website - FIXED
✅ 13-second payment verification - WORKING
✅ Order confirmed message - WORKING
✅ More Shopping button - WORKING
```

---

## 💡 **Pro Tips**

1. **Approve in Bulk:**
   - Multiple screenshots? Just click approve/decline on each
   - No need to type commands
   - Instant feedback

2. **Check Revenue:**
   - Use /status daily to see approved payments
   - Total Collected = Real revenue
   - Pending/Declined don't count

3. **Export for Records:**
   - Use /status_all weekly
   - Keep TXT files for accounting
   - Shows all transactions with status

4. **Safe Delete:**
   - 3 confirmations prevent accidents
   - Only delete when you're sure
   - Consider exporting first (/status_all)

5. **QR Management:**
   - Update QR anytime with /change
   - Website updates automatically
   - For production: Use Cloudinary (permanent URLs)

---

## 📱 **Mobile Testing**

Test from mobile device:
1. Open Telegram on phone
2. Send commands (same as above)
3. Tap Approve/Decline buttons
4. Works exactly the same! ✅

---

## 🎊 **Summary**

**You have a COMPLETE payment management system:**
- ✅ Automatic screenshot forwarding
- ✅ One-click approve/decline (individual)
- ✅ Bulk approve all pending payments
- ✅ Bulk decline all pending payments
- ✅ Real-time statistics
- ✅ Complete transaction export
- ✅ Dynamic QR management
- ✅ Safe delete with confirmations
- ✅ Professional user experience

**Everything is working! Just test to verify! 🚀**

---

## 💡 **Bulk Operations Guide**

### When to use `/approve_all`:
```
✅ End of day - Approve all legitimate payments
✅ Bulk processing - Multiple valid orders
✅ Time-saving - 10+ pending payments
✅ Trust scenario - When all pending are valid
```

### When to use `/decline_all`:
```
❌ Spam cleanup - Multiple invalid screenshots
❌ End of promotion - Clear old pending
❌ Reset scenario - Start fresh next day
❌ Error correction - Bulk invalid submissions
```

### Best Practices:
```
1. Check /status first to see pending count
2. Review individual payments if unsure
3. Use bulk commands for clear-cut scenarios
4. Individual buttons for case-by-case review
5. Export /status_all before bulk decline (backup)
```
