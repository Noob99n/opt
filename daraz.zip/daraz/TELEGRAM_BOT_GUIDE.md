# 🤖 Telegram Bot Admin Guide

## Overview
Professional Telegram bot for admin payment management with full authorization and security.

## Setup Complete ✅
- Bot Token: Configured in Replit Secrets
- Admin User ID: 7646520243
- Status: **ACTIVE** ✅ Telegram bot initialized successfully

## Bot Commands

### 📱 /start
**Welcome message and command list**
```
Shows all available commands and their descriptions
Only accessible by admin (User ID: 7646520243)
```

### 📊 /status
**Today's payment statistics**
```
Returns:
- Total payments today
- Verified count
- Pending count
- Total amount (Rs.)
- Last updated timestamp
```

**Example Output:**
```
📊 Today's Payment Statistics

📅 Date: 24/11/2025

💰 Total Payments: 15
✅ Verified: 12
⏳ Pending: 3
💵 Total Amount: Rs. 29,550

Last updated: 08:30:45
```

### 📄 /status_all
**Export all transaction logs**
```
Generates a TXT file with complete transaction history
Includes:
- Transaction ID
- Date & Time
- Product Name
- Amount
- Status
- User ID

File naming: transactions_[timestamp].txt
```

**Example Output:**
```
=== ALL TRANSACTION LOGS ===

1. Transaction ID: 687abc123def456
   Date: 24/11/2025, 08:15:30
   Product: Apple iPhone 16 Pro Max
   Amount: Rs. 2,045
   Status: VERIFIED
   User: guest
   ----------------------------------------

2. Transaction ID: 687def456abc789
   Date: 24/11/2025, 09:22:15
   Product: Apple iPhone 13
   Amount: Rs. 1,245
   Status: PENDING
   User: guest
   ----------------------------------------

Total Transactions: 15
Total Amount: Rs. 29,550
Generated: 24/11/2025, 10:30:00
```

### 🔄 /change
**Update QR code on website**
```
Steps:
1. Send /change command
2. Upload new QR code image (JPG/PNG)
3. Image automatically uploaded to database
4. QR code updated on website instantly
```

**Response:**
```
✅ QR code updated successfully!
The new QR is now live on the website.
```

### 🗑️ /delete
**Delete all transaction logs (3x confirmation)**
```
Security: Requires 3 confirmations to prevent accidents

Step 1: /delete
Step 2: /delete_confirm_1
Step 3: /delete_confirm_2
Step 4: /delete_confirm_3

Only then will logs be deleted permanently.
```

**Confirmation Flow:**
```
User: /delete
Bot: ⚠️ WARNING: DELETE ALL LOGS
     Type: /delete_confirm_1 to proceed

User: /delete_confirm_1
Bot: ⚠️ Second confirmation required.
     Type: /delete_confirm_2 to continue

User: /delete_confirm_2
Bot: ⚠️ FINAL confirmation required.
     Type: /delete_confirm_3 to DELETE ALL LOGS

User: /delete_confirm_3
Bot: ✅ All transaction logs deleted.
     Total deleted: 15 records
```

## Automatic Features

### 📸 Screenshot Forwarding
**When user uploads payment screenshot on website:**
```
Bot automatically sends to admin:
- Product name
- Payment amount
- Screenshot image
- Timestamp
- Status: Pending Verification

Creates transaction log in database
```

**Auto-Forward Message:**
```
💳 New Payment Screenshot

📦 Product: Apple iPhone 16 Pro Max
💰 Amount: Rs. 2,045
🕐 Time: 24/11/2025, 08:15:30

Status: Pending Verification

[Screenshot Image]
```

## Authorization

### Admin-Only Access
```
Authorized User ID: 7646520243
Any other user receives:

❌ You are not authorised to use this bot.
```

### Security Features
- User ID verification on every command
- No data exposure to unauthorized users
- Secure token management via Replit Secrets

## Database Collections

### TransactionLog
```javascript
{
  userId: String (default: 'guest'),
  amount: Number,
  productTitle: String,
  screenshotUrl: String,
  status: 'pending' | 'verified' | 'failed',
  timestamp: Date,
  telegramMessageId: Number
}
```

### QRCode
```javascript
{
  imageUrl: String,
  updatedAt: Date,
  updatedBy: String (default: 'admin')
}
```

## API Endpoints

### GET /api/qr-code
```
Returns current QR code URL
Used by website to display payment QR
```

### POST /api/qr-code
```
Updates QR code in database
Called by Telegram bot when admin uploads new QR
```

### POST /api/transaction-log
```
Creates new transaction log
Forwards screenshot to admin Telegram
Called when user uploads payment proof
```

## Usage Workflow

### Daily Admin Workflow
```
1. Start day: /status (check yesterday's pending)
2. Monitor: Wait for screenshot auto-forwards
3. Verify payments manually
4. End day: /status (today's summary)
5. Weekly: /status_all (export for records)
```

### QR Code Update Workflow
```
1. Create new QR code for payment account
2. Send /change to bot
3. Upload QR image
4. Confirm update message
5. Test: Visit website and verify new QR displays
```

### Transaction Management
```
1. Receive screenshot notification
2. Verify payment in bank/UPI app
3. Update order status manually
4. Export logs: /status_all (for accounting)
```

## Troubleshooting

### Bot Not Responding
```
1. Check Replit Secrets: TELEGRAM_BOT_TOKEN set
2. Check logs: "✅ Telegram bot initialized successfully"
3. Restart workflow if needed
```

### Screenshot Not Forwarding
```
1. Check user uploaded screenshot on website
2. Check transaction log created in database
3. Verify admin user ID: 7646520243
```

### QR Code Not Updating
```
1. Confirm upload success message
2. Check /api/qr-code endpoint
3. Clear browser cache and refresh website
```

## Technical Details

### Package
```
node-telegram-bot-api
@types/node-telegram-bot-api
```

### Bot File
```
server/telegram-bot.ts
- initTelegramBot()
- forwardScreenshotToAdmin()
- handleStart(), handleStatus(), handleStatusAll()
- handleChange(), handleDelete()
```

### Initialization
```javascript
// server/index.ts
import { initTelegramBot } from "./telegram-bot";
initTelegramBot();
```

## Best Practices

1. **Daily Status Checks**: Use /status every morning
2. **Regular Exports**: Use /status_all weekly for backup
3. **QR Security**: Change QR code if compromised
4. **Log Management**: Delete old logs quarterly with /delete
5. **Screenshot Verification**: Always verify payments in actual bank account

## Support

For issues or questions:
1. Check bot logs in Replit workflow
2. Verify TELEGRAM_BOT_TOKEN is set
3. Ensure admin user ID matches: 7646520243
4. Test with /start command

---

**Status: ✅ FULLY OPERATIONAL**

Bot is live and ready for payment management! 🚀
