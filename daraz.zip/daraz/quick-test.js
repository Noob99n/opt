// Quick MongoDB connection test
import mongoose from 'mongoose';

const MONGODB_URI = process.env.MONGODB_URI;

console.log('🔍 Testing MongoDB connection...');
console.log('URI available:', MONGODB_URI ? 'Yes' : 'No');

async function quickTest() {
  try {
    console.log('⏳ Connecting...');
    await mongoose.connect(MONGODB_URI, {
      serverSelectionTimeoutMS: 10000
    });
    
    console.log('✅ SUCCESS! MongoDB connected');
    console.log('Database:', mongoose.connection.db.databaseName);
    
    await mongoose.disconnect();
    console.log('Connection test completed');
    process.exit(0);
    
  } catch (error) {
    console.log('❌ FAILED:', error.message);
    process.exit(1);
  }
}

quickTest();