import { useState, useEffect } from 'react';
import { CartItemWithProduct } from '@/types';

// Guest cart using localStorage
export function useCart() {
  const [cartItems, setCartItems] = useState<CartItemWithProduct[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load cart from localStorage on mount
  useEffect(() => {
    const loadCart = () => {
      try {
        const stored = localStorage.getItem('guest-cart');
        if (stored) {
          const parsedCart = JSON.parse(stored);
          setCartItems(parsedCart);
        }
      } catch (error) {
        console.error('Error loading cart:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadCart();
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('guest-cart', JSON.stringify(cartItems));
    }
  }, [cartItems, isLoading]);

  const addToCart = async ({ productId, quantity = 1 }: { productId: string | number; quantity?: number }) => {
    try {
      // Use string productId (MongoDB _id)
      const id = typeof productId === 'string' ? productId : productId.toString();
      
      // Fetch product details
      const response = await fetch(`/api/products/${id}`);
      if (!response.ok) {
        console.error('Product fetch failed:', response.status, response.statusText);
        throw new Error('Product not found');
      }
      const product = await response.json();
      console.log('Product fetched:', product);

      // Use functional setter to avoid race conditions
      setCartItems(prevItems => {
        const existingItem = prevItems.find(item => item.productId === id);
        
        let updatedCart;
        if (existingItem) {
          // Update quantity if item exists
          updatedCart = prevItems.map(item =>
            item.productId === id
              ? { ...item, quantity: item.quantity + quantity }
              : item
          );
        } else {
          // Add new item
          const newItem: CartItemWithProduct = {
            id: Date.now(), // Simple ID for guest cart
            productId: id,
            quantity,
            userId: 'guest',
            product: {
              id: product._id || product.id,
              title: product.title,
              price: product.price,
              originalPrice: product.originalPrice,
              imageUrl: product.imageUrl,
              rating: product.rating,
              reviewCount: product.reviewCount,
              discount: product.discount,
              brand: product.brand,
            }
          };
          updatedCart = [...prevItems, newItem];
        }
        
        // Save to localStorage BEFORE returning updated cart
        localStorage.setItem('guest-cart', JSON.stringify(updatedCart));
        
        return updatedCart;
      });
    } catch (error) {
      console.error('Add to cart error:', error);
    }
  };

  const updateCartItem = ({ id, quantity }: { id: number; quantity: number }) => {
    setCartItems(prevItems =>
      prevItems.map(item =>
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  const removeFromCart = (id: number) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== id));
  };

  const clearCart = () => {
    setCartItems([]);
    localStorage.removeItem('guest-cart');
  };

  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const cartTotal = cartItems.reduce((sum, item) => {
    const price = parseFloat(item.product.price);
    return sum + (price * item.quantity);
  }, 0);

  return {
    cartItems,
    cartCount,
    cartTotal,
    isLoading,
    error: null,
    addToCart,
    updateCartItem,
    removeFromCart,
    clearCart,
    isAddingToCart: false,
    isUpdatingCart: false,
    isRemovingFromCart: false,
  };
}
