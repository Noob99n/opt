import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useRoute } from 'wouter';

interface TenantInfo {
  slug: string | null;
  storeName: string | null;
  adminUsername: string | null;
  isActive: boolean;
  isTenantStore: boolean;
}

interface TenantContextType {
  tenant: TenantInfo;
  isLoading: boolean;
  error: string | null;
  getApiPath: (path: string) => string;
  getRoutePath: (path: string) => string;
}

const defaultTenant: TenantInfo = {
  slug: null,
  storeName: null,
  adminUsername: null,
  isActive: false,
  isTenantStore: false
};

const TenantContext = createContext<TenantContextType>({
  tenant: defaultTenant,
  isLoading: false,
  error: null,
  getApiPath: (path) => path,
  getRoutePath: (path) => path
});

export function useTenant() {
  return useContext(TenantContext);
}

interface TenantProviderProps {
  children: ReactNode;
  slug?: string;
}

export function TenantProvider({ children, slug: propSlug }: TenantProviderProps) {
  const [, params] = useRoute('/store/:slug/*?');
  const [, simpleParams] = useRoute('/store/:slug');
  
  const slug = propSlug || params?.slug || simpleParams?.slug || null;
  
  const [tenant, setTenant] = useState<TenantInfo>(defaultTenant);
  const [isLoading, setIsLoading] = useState(!!slug);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!slug) {
      setTenant(defaultTenant);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);

    fetch(`/api/store/${slug}/info`)
      .then(res => {
        if (!res.ok) throw new Error('Store not found');
        return res.json();
      })
      .then(data => {
        setTenant({
          slug,
          storeName: data.storeName,
          adminUsername: data.adminUsername,
          isActive: data.isActive,
          isTenantStore: true
        });
        setIsLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setTenant({ ...defaultTenant, slug, isTenantStore: true });
        setIsLoading(false);
      });
  }, [slug]);

  const getApiPath = (path: string): string => {
    if (!slug) return path;
    
    if (path.startsWith('/api/products')) {
      return `/api/store/${slug}/products`;
    }
    if (path.startsWith('/api/script-products')) {
      return `/api/store/${slug}/script-products`;
    }
    if (path.startsWith('/api/flash-sale')) {
      return `/api/store/${slug}/flash-sale`;
    }
    if (path.startsWith('/api/product/')) {
      const productId = path.replace('/api/product/', '');
      return `/api/store/${slug}/product/${productId}`;
    }
    if (path.startsWith('/api/categories')) {
      return `/api/store/${slug}/categories`;
    }
    if (path.startsWith('/api/search')) {
      return `/api/store/${slug}/search${path.includes('?') ? path.substring(path.indexOf('?')) : ''}`;
    }
    if (path.startsWith('/api/qr-code')) {
      return `/api/store/${slug}/qr-code`;
    }
    if (path.startsWith('/api/transactions')) {
      return `/api/store/${slug}/transactions`;
    }
    if (path.startsWith('/api/transaction-log')) {
      return `/api/store/${slug}/transaction-log`;
    }
    if (path.startsWith('/api/transaction-status/')) {
      const txId = path.replace('/api/transaction-status/', '');
      return `/api/store/${slug}/transaction-status/${txId}`;
    }
    
    return path;
  };

  const getRoutePath = (path: string): string => {
    if (!slug) return path;
    
    if (path === '/' || path === '') {
      return `/store/${slug}`;
    }
    if (path.startsWith('/')) {
      return `/store/${slug}${path}`;
    }
    return `/store/${slug}/${path}`;
  };

  return (
    <TenantContext.Provider value={{ tenant, isLoading, error, getApiPath, getRoutePath }}>
      {children}
    </TenantContext.Provider>
  );
}

export function TenantAwareLink({ to, children, className, ...props }: { to: string; children: ReactNode; className?: string; [key: string]: any }) {
  const { getRoutePath } = useTenant();
  const href = getRoutePath(to);
  
  return (
    <a href={href} className={className} {...props}>
      {children}
    </a>
  );
}
