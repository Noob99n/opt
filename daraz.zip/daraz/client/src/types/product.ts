// Product type definitions for type-safe operations

export interface ProductSpecifications {
  display?: string;
  size?: string;
  resolution?: string;
  contrastRatio?: string;
  brightness?: string;
  features?: string;
  waterResistance?: string;
  chip?: string;
  cpu?: string;
  gpu?: string;
  neuralEngine?: string;
  operatingSystem?: string;
  camera?: string;
  storage?: string;
  ram?: string;
  color?: string;
}

export interface DeliveryInfo {
  location?: string;
  type?: string;
  timeframe?: string;
  cost?: string | number;
}

export interface ServiceInfo {
  returnPolicy?: string;
  returnNote?: string;
  warranty?: string;
}

export interface ScriptProduct {
  _id: string;
  id?: string;
  slug?: string;
  title: string;
  description?: string;
  price: string | number;
  originalPrice?: string | number;
  discount: number;
  imageUrl?: string;
  rating?: string | number;
  reviewCount?: number;
  brand?: string;
  stock?: number;
  isFlashDeal: boolean;
  specifications?: ProductSpecifications;
  delivery?: DeliveryInfo;
  service?: ServiceInfo;
}

export type ScriptProductsResponse = ScriptProduct[];
