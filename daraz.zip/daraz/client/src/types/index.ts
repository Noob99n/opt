export interface CartItemWithProduct {
  id: number;
  productId: string | number;  // Support both MongoDB string IDs and numeric IDs
  quantity: number;
  userId: string;
  product: {
    id: string | number;  // Support both MongoDB string IDs and numeric IDs
    title: string;
    price: string;
    originalPrice?: string;
    imageUrl?: string;
    rating?: string;
    reviewCount?: number;
    discount?: number;
    brand?: string;
  };
}

export interface AddressFormData {
  fullName: string;
  phoneNumber: string;
  province: string;
  city: string;
  zone: string;
  address: string;
  landmark?: string;
  label: 'HOME' | 'OFFICE';
  isDefaultShipping: boolean;
  isDefaultBilling: boolean;
}

export interface OrderSummary {
  subtotal: number;
  shippingFee: number;
  discount: number;
  total: number;
}

export interface PaymentMethod {
  id: string;
  name: string;
  description: string;
  icon: string;
  recommended?: boolean;
}
