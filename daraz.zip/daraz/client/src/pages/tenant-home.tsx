import { useMemo, useState, useEffect, createContext, useContext } from 'react';
import { useLocation, useRoute } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { SearchBar } from '@/components/layout/search-bar';
import { BannerCarousel } from '@/components/layout/banner-carousel';
import { useTenant } from '@/context/TenantContext';
import { AlertCircle, ShoppingBag, Zap, Clock, Star } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { ScriptProduct, ScriptProductsResponse } from '@/types/product';
import { getProxiedImageUrl } from '@/lib/image-proxy';

const TimerContext = createContext({ minutes: 10, seconds: 0 });

const toPrice = (value: string | number | undefined): number => {
  if (value === undefined) return 0;
  return typeof value === 'number' ? value : parseFloat(value);
};

export default function TenantHome() {
  const { tenant, isLoading: isTenantLoading, error: tenantError, getRoutePath } = useTenant();
  const [, params] = useRoute('/store/:slug');
  const [, params2] = useRoute('/store/:slug/:rest*');
  const slug = params?.slug || params2?.slug || tenant.slug || '';
  const [, setLocation] = useLocation();
  
  const [offerTimer, setOfferTimer] = useState({ minutes: 10, seconds: 0 });
  
  useEffect(() => {
    const timer = setInterval(() => {
      setOfferTimer(prev => {
        let { minutes, seconds } = prev;
        if (seconds === 0) {
          if (minutes === 0) return { minutes: 10, seconds: 0 };
          minutes--;
          seconds = 59;
        } else {
          seconds--;
        }
        return { minutes, seconds };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const { data: flashSaleProducts = [], isLoading: isLoadingFlash } = useQuery<ScriptProductsResponse>({
    queryKey: ['/api/store', slug, 'flash-sale'],
    queryFn: async () => {
      const res = await fetch(`/api/store/${slug}/flash-sale`);
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!slug && !!tenant.isActive
  });

  if (isTenantLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <ShoppingBag className="w-12 h-12 text-orange-500 mx-auto mb-4 animate-pulse" />
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (tenantError || !tenant.isActive) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Store Not Found</h2>
            <p className="text-gray-600 mb-4">
              The store "{slug}" doesn't exist or is no longer active.
            </p>
            <Badge variant="secondary" className="text-sm">
              Please check the URL and try again
            </Badge>
          </CardContent>
        </Card>
      </div>
    );
  }

  const navigateToProduct = (product: ScriptProduct) => {
    setLocation(`/store/${slug}/product/${product.slug || product._id || product.id}`);
  };

  const navigateToCategories = () => {
    setLocation(`/store/${slug}/categories`);
  };

  const handleSearch = (query: string) => {
    if (query.trim()) {
      setLocation(`/store/${slug}/search?q=${encodeURIComponent(query)}`);
    }
  };

  return (
    <div className="min-h-screen pb-20">
      <div style={{ 
        minHeight: '50vh',
        position: 'relative',
        backgroundColor: '#f8f9fa'
      }}>

        {/* Daraz Logo Header */}
        <div className="bg-white border-b border-gray-100 pt-1 pb-1 px-4">
          <div className="download-banner">
            <img 
              src="https://res.cloudinary.com/djbiyudvw/image/upload/v1752394198/IMG_20250713_104903_jursux.png" 
              alt="Daraz App Logo" 
              className="w-full h-16 object-cover"
              style={{ 
                objectPosition: 'center',
                imageRendering: 'crisp-edges',
                filter: 'contrast(1.1) saturate(1.1)'
              }}
            />
          </div>
        </div>

        <SearchBar onSearch={handleSearch} />

        {/* Banner Carousel */}
        <div className="px-4 mt-4">
          <BannerCarousel />
        </div>

        {/* Category Grid Image */}
        <div className="px-4">
          <img 
            src="https://res.cloudinary.com/djbiyudvw/image/upload/v1764077993/Picsart_25-11-25_17-33-35-261_a6foo4.png" 
            alt="Categories" 
            className="w-full cursor-pointer"
            onClick={navigateToCategories}
          />
        </div>
      </div>

      {/* FLASH SALE SECTION */}
      <div className="mb-6 bg-white rounded-2xl mx-4 shadow-sm overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="text-red-500 text-[6px] font-bold leading-tight text-center">
              <div>महाबचत</div>
              <div className="ml-2">बजार</div>
            </div>
            <div className="flex items-center">
              <span className="font-bold text-lg">Flas</span>
              <Zap className="w-4 h-4 text-orange-500 fill-orange-500" />
              <span className="font-bold text-lg">h Sale</span>
            </div>
            <div className="bg-red-600 text-white text-xs px-2 py-1 rounded flex items-center gap-1 shadow-sm">
              <Clock className="w-3 h-3" />
              <span className="font-bold">{String(offerTimer.minutes).padStart(2, '0')}:{String(offerTimer.seconds).padStart(2, '0')}</span>
            </div>
          </div>
          <button className="text-orange-500 text-sm font-medium">SHOP MORE ›</button>
        </div>
        
        <div className="px-4 pb-4">
          {isLoadingFlash ? (
            <div className="flex gap-3 overflow-x-auto scrollbar-hide">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="flex-shrink-0 w-32">
                  <div className="w-full h-24 bg-gray-200 rounded-lg mb-2 animate-pulse"></div>
                  <div className="h-4 bg-gray-200 rounded mb-1 animate-pulse"></div>
                  <div className="h-6 bg-gray-200 rounded animate-pulse"></div>
                </div>
              ))}
            </div>
          ) : flashSaleProducts.length > 0 ? (
            <div className="flex gap-3 overflow-x-auto scrollbar-hide">
              {flashSaleProducts.slice(0, 5).map((product: ScriptProduct) => (
                <div key={product._id || product.id} className="flex-shrink-0 w-32" onClick={() => navigateToProduct(product)}>
                  <div className="cursor-pointer">
                    <img 
                      src={getProxiedImageUrl(product.imageUrl)} 
                      className="w-full h-24 object-contain rounded-lg mb-2 bg-white" 
                      alt={product.title}
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        const target = e.currentTarget;
                        if (!target.dataset.fallback) {
                          target.dataset.fallback = "true";
                          target.src = '/placeholder-product.svg';
                        }
                      }}
                    />
                  </div>
                  <div className="mb-2 bg-white p-1 rounded">
                    <div className="flex items-center gap-1">
                      <span className="text-red-600 font-bold">Rs. {toPrice(product.price).toLocaleString()}</span>
                      <span className="bg-orange-100 text-orange-600 text-[10px] px-1 py-0.5 rounded font-medium">-{product.discount}%</span>
                    </div>
                    {product.originalPrice && (
                      <div className="text-gray-400 line-through text-xs">Rs. {toPrice(product.originalPrice).toLocaleString()}</div>
                    )}
                  </div>
                  <div className="bg-red-500 text-white text-xs px-2 py-1 rounded-full text-center">
                    {(product.stock && product.stock > 100) ? "In Stock" : `${product.stock || 0} left`}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-4 text-gray-500">
              <p className="text-sm">No flash sale products available</p>
            </div>
          )}
        </div>
      </div>

      {/* BANNER IMAGE */}
      <div className="mb-6 mx-4">
        <img 
          src="https://res.cloudinary.com/djbiyudvw/image/upload/v1752898189/Screenshot_2025_0719_093936_iphiqd.png"
          alt="Promotional Banner"
          className="w-full h-auto rounded-2xl shadow-sm object-cover"
          onError={(e) => { e.currentTarget.style.display = 'none'; }}
        />
      </div>

      {/* ALL PRODUCTS SECTION */}
      <div className="mb-6 mx-4">
        <TimerContext.Provider value={offerTimer}>
          <TenantProductsSection slug={slug} navigateToProduct={navigateToProduct} />
        </TimerContext.Provider>
      </div>
    </div>
  );
}

function TenantProductsSection({ slug, navigateToProduct }: { slug: string; navigateToProduct: (p: ScriptProduct) => void }) {
  const offerTimer = useContext(TimerContext);
  
  const { data: products = [], isLoading } = useQuery<ScriptProductsResponse>({
    queryKey: ['/api/store', slug, 'products'],
    queryFn: async () => {
      const res = await fetch(`/api/store/${slug}/products`);
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!slug
  });

  const regularProducts = useMemo(() => 
    products.filter((product: ScriptProduct) => !product.isFlashDeal),
    [products]
  );

  if (isLoading) {
    return (
      <div className="bg-white rounded-2xl p-4 shadow-sm">
        <div className="grid grid-cols-2 gap-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="animate-pulse">
              <div className="bg-gray-200 rounded-lg mb-2" style={{ paddingBottom: '100%' }}></div>
              <div className="bg-gray-200 h-4 rounded mb-1"></div>
              <div className="bg-gray-200 h-4 rounded w-3/4"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="bg-white rounded-2xl p-6 shadow-sm text-center">
        <ShoppingBag className="w-12 h-12 text-gray-300 mx-auto mb-4" />
        <p className="text-gray-800 font-semibold">No Products Available</p>
        <p className="text-sm text-gray-500">This store hasn't added any products yet</p>
      </div>
    );
  }

  const toPrice = (value: string | number | undefined): number => {
    if (value === undefined) return 0;
    return typeof value === 'number' ? value : parseFloat(value);
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
      <div className="px-4 py-3 border-b">
        <h3 className="font-bold text-lg flex items-center gap-2"><ShoppingBag className="w-5 h-5" /> All Products</h3>
      </div>
      <div className="p-4">
        <div className="grid grid-cols-2 gap-4">
          {products.map((product: ScriptProduct) => (
            <div 
              key={product._id || product.id} 
              className="cursor-pointer"
              onClick={() => navigateToProduct(product)}
              data-testid={`card-product-${product._id || product.id}`}
            >
              <div className="relative w-full" style={{ paddingBottom: '100%' }}>
                <img 
                  src={getProxiedImageUrl(product.imageUrl)} 
                  className="absolute top-0 left-0 w-full h-full object-contain rounded-lg bg-gray-100"
                  alt={product.title}
                  loading="eager"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (!target.dataset.fallback) {
                      target.dataset.fallback = "true";
                      target.src = '/placeholder-product.svg';
                    }
                  }}
                />
              </div>
              
              <div className="space-y-1">
                <h3 className="text-sm font-medium text-gray-800 line-clamp-2 leading-tight">
                  {product.title}
                </h3>
                
                <div className="flex items-center gap-1 flex-wrap">
                  <span className="text-lg font-bold text-orange-500">
                    Rs. {toPrice(product.price).toLocaleString()}
                  </span>
                  {product.discount && product.discount > 0 && (
                    <span className="bg-orange-100 text-orange-600 text-[10px] px-1 py-0.5 rounded font-medium">-{product.discount}%</span>
                  )}
                </div>
                {product.originalPrice && toPrice(product.originalPrice) > toPrice(product.price) && (
                  <div className="text-sm text-gray-400 line-through">
                    Rs. {toPrice(product.originalPrice).toLocaleString()}
                  </div>
                )}
                
                {product.rating && toPrice(product.rating) > 0 && (
                  <div className="flex items-center space-x-1">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`w-3 h-3 ${i < Math.floor(toPrice(product.rating)) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                        />
                      ))}
                    </div>
                    <span className="text-xs text-gray-500">
                      ({product.reviewCount || 0})
                    </span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
