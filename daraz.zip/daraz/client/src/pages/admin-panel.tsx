import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { 
  Lock, FileText, LogOut, Calendar, User, RefreshCw, 
  Play, Square, Check, ExternalLink, Store, Bot, Save, Trash2
} from 'lucide-react';

interface Script {
  _id: string;
  name: string;
  description: string;
  category: string;
  status: string;
  isActive: boolean;
}

interface AdminInfo {
  id: string;
  username: string;
  expiryDate: string;
  activeScriptId?: string;
  storeSlug?: string;
  botToken?: string;
  botChatId?: string;
}

export default function AdminPanel() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  const [adminInfo, setAdminInfo] = useState<AdminInfo | null>(null);
  const [botToken, setBotToken] = useState('');
  const [botChatId, setBotChatId] = useState('');
  const [isSavingBot, setIsSavingBot] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const res = await fetch('/api/admin/check-auth');
      const data = await res.json();
      if (data.authenticated && data.admin) {
        setIsAuthenticated(true);
        setAdminInfo(data.admin);
        if (data.admin.botToken) setBotToken(data.admin.botToken);
        if (data.admin.botChatId) setBotChatId(data.admin.botChatId);
      }
    } catch (e) {
      setIsAuthenticated(false);
    } finally {
      setIsCheckingAuth(false);
    }
  };

  const handleSaveBotSettings = async () => {
    if (!botToken.trim() || !botChatId.trim()) {
      toast({ title: "Error", description: "Please enter both Bot Token and Chat ID", variant: "destructive" });
      return;
    }
    setIsSavingBot(true);
    try {
      const response = await fetch('/api/admin/bot-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ botToken, botChatId })
      });
      const data = await response.json();
      if (response.ok) {
        setAdminInfo(prev => prev ? { ...prev, botToken, botChatId } : null);
        toast({ title: "Success", description: "Bot settings saved" });
      } else {
        toast({ title: "Error", description: data.error || "Failed to save", variant: "destructive" });
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to save bot settings", variant: "destructive" });
    } finally {
      setIsSavingBot(false);
    }
  };

  const handleDeleteBotSettings = async () => {
    setIsSavingBot(true);
    try {
      const response = await fetch('/api/admin/bot-settings', { method: 'DELETE' });
      if (response.ok) {
        setBotToken('');
        setBotChatId('');
        setAdminInfo(prev => prev ? { ...prev, botToken: undefined, botChatId: undefined } : null);
        toast({ title: "Success", description: "Bot settings removed" });
      } else {
        toast({ title: "Error", description: "Failed to remove", variant: "destructive" });
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to remove bot settings", variant: "destructive" });
    } finally {
      setIsSavingBot(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      toast({ title: "Error", description: "Please enter username and password", variant: "destructive" });
      return;
    }
    setIsLoading(true);
    try {
      const response = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await response.json();
      if (response.ok) {
        setIsAuthenticated(true);
        setAdminInfo(data.admin);
        toast({ title: "Success", description: "Login successful" });
      } else {
        toast({ title: "Error", description: data.error || "Invalid credentials", variant: "destructive" });
      }
    } catch (error) {
      toast({ title: "Error", description: "Login failed", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/admin/logout', { method: 'POST' });
      setIsAuthenticated(false);
      setAdminInfo(null);
      setUsername('');
      setPassword('');
    } catch (e) {
      console.error(e);
    }
  };

  const { data: scripts = [], isLoading: scriptsLoading } = useQuery<Script[]>({
    queryKey: ['/api/scripts'],
    enabled: isAuthenticated
  });

  const setScriptMutation = useMutation({
    mutationFn: async (scriptId: string | null) => {
      const res = await apiRequest('POST', '/api/admin/set-script', { scriptId });
      return res.json();
    },
    onSuccess: (data: any) => {
      if (adminInfo) {
        setAdminInfo({ ...adminInfo, activeScriptId: data.activeScriptId });
      }
      queryClient.invalidateQueries({ queryKey: ['/api/admin/check-auth'] });
      toast({ title: "Success", description: "Script updated" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update script", variant: "destructive" });
    }
  });

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const daysRemaining = (dateStr: string) => {
    const diff = new Date(dateStr).getTime() - new Date().getTime();
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  };

  if (isCheckingAuth) {
    return (
      <div className="fixed inset-0 bg-gray-900 flex items-center justify-center z-50">
        <RefreshCw className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 bg-gray-900 flex items-center justify-center p-4 z-50">
        <Card className="w-full max-w-sm bg-gray-800 border-gray-700">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mb-4">
              <Lock className="w-8 h-8 text-blue-400" />
            </div>
            <CardTitle className="text-white text-xl">Admin Panel</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <Input
                type="text"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                data-testid="input-admin-login-username"
              />
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                data-testid="input-admin-login-password"
              />
              <Button 
                type="submit" 
                className="w-full"
                disabled={isLoading}
                data-testid="button-admin-login"
              >
                {isLoading ? 'Loading...' : 'Login'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-gray-900 z-50 overflow-hidden">
      <div className="h-full flex flex-col">
        <header className="bg-gray-800 border-b border-gray-700 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <User className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-white">Admin Panel</h1>
              <p className="text-sm text-gray-400">Welcome, {adminInfo?.username}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {adminInfo?.expiryDate && (
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <Calendar className="w-4 h-4" />
                <span>Expires: {formatDate(adminInfo.expiryDate)}</span>
                <Badge variant="secondary" className="text-xs">
                  {daysRemaining(adminInfo.expiryDate)} days left
                </Badge>
              </div>
            )}
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => window.open(`/store/${adminInfo?.storeSlug || adminInfo?.username?.toLowerCase().replace(/[^a-z0-9]/g, '-')}`, '_blank')}
              className="border-blue-500/50 text-blue-400 hover:bg-blue-500/10"
              data-testid="button-view-store"
            >
              <Store className="w-4 h-4 mr-2" />
              View My Store
              <ExternalLink className="w-3 h-3 ml-1" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleLogout}
              className="text-gray-400 hover:text-white"
              data-testid="button-admin-logout"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </header>

        <div className="flex-1 overflow-auto p-6">
          <div className="max-w-4xl mx-auto">
            <div className="mb-6">
              <h2 className="text-lg font-medium text-white mb-2">Select Script to Run</h2>
              <p className="text-sm text-gray-400">Choose a script from the list below. Only one script can be active at a time.</p>
            </div>

            {scriptsLoading ? (
              <div className="text-center py-8 text-gray-400">Loading scripts...</div>
            ) : scripts.length === 0 ? (
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="py-12 text-center">
                  <FileText className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">No scripts available yet.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {scripts.map((script) => {
                  const isActive = adminInfo?.activeScriptId === script._id;
                  return (
                    <Card 
                      key={script._id} 
                      className={`bg-gray-800 border-gray-700 transition-colors ${isActive ? 'border-green-500/50 bg-green-500/5' : ''}`}
                      data-testid={`card-script-${script._id}`}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isActive ? 'bg-green-500/20' : 'bg-purple-500/20'}`}>
                              <FileText className={`w-5 h-5 ${isActive ? 'text-green-400' : 'text-purple-400'}`} />
                            </div>
                            <div>
                              <h3 className="text-white font-medium flex items-center gap-2">
                                {script.name}
                                {isActive && (
                                  <Badge className="bg-green-500/20 text-green-400 text-xs">
                                    <Check className="w-3 h-3 mr-1" />
                                    Running
                                  </Badge>
                                )}
                              </h3>
                              <div className="flex items-center gap-2 text-sm text-gray-400">
                                <Badge variant="outline" className="text-xs">{script.category}</Badge>
                                {script.description && (
                                  <span className="truncate max-w-xs">{script.description}</span>
                                )}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {isActive ? (
                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => setScriptMutation.mutate(null)}
                                disabled={setScriptMutation.isPending}
                                data-testid={`button-stop-script-${script._id}`}
                              >
                                <Square className="w-4 h-4 mr-2" />
                                Stop
                              </Button>
                            ) : (
                              <Button
                                variant="default"
                                size="sm"
                                onClick={() => setScriptMutation.mutate(script._id)}
                                disabled={setScriptMutation.isPending}
                                data-testid={`button-run-script-${script._id}`}
                              >
                                <Play className="w-4 h-4 mr-2" />
                                Run
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}

            {/* Bot Settings Section */}
            <div className="mt-8 mb-6">
              <h2 className="text-lg font-medium text-white mb-2 flex items-center gap-2">
                <Bot className="w-5 h-5 text-blue-400" />
                Telegram Bot Settings
              </h2>
              <p className="text-sm text-gray-400">Configure your own Telegram bot to receive payment notifications. If not set, notifications will go to the owner's bot.</p>
            </div>

            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-4 space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Bot Token</label>
                  <Input
                    type="text"
                    placeholder="Enter your Telegram bot token"
                    value={botToken}
                    onChange={(e) => setBotToken(e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-500"
                    data-testid="input-admin-bot-token"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Chat ID</label>
                  <Input
                    type="text"
                    placeholder="Enter your Telegram chat ID"
                    value={botChatId}
                    onChange={(e) => setBotChatId(e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-500"
                    data-testid="input-admin-bot-chat-id"
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={handleSaveBotSettings}
                    disabled={isSavingBot}
                    className="flex-1"
                    data-testid="button-save-bot-settings"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    {isSavingBot ? 'Saving...' : 'Save Bot Settings'}
                  </Button>
                  {(adminInfo?.botToken || adminInfo?.botChatId) && (
                    <Button
                      variant="destructive"
                      onClick={handleDeleteBotSettings}
                      disabled={isSavingBot}
                      data-testid="button-delete-bot-settings"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
                {adminInfo?.botToken && (
                  <div className="text-xs text-green-400 flex items-center gap-1">
                    <Check className="w-3 h-3" />
                    Bot configured - Payment notifications will be sent to your bot
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
