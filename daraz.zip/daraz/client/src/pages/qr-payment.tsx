import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { X, Bot, ShoppingBag, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTenant } from '@/context/TenantContext';
import { getProxiedImageUrl } from '@/lib/image-proxy';

interface CartItem {
  id: string;
  title: string;
  price: string;
  imageUrl: string;
  quantity: number;
}

function SuccessRedirect({ cartItems, onRedirect }: { cartItems: CartItem[], onRedirect: () => void }) {
  const [countdown, setCountdown] = useState(5);
  
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          onRedirect();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [onRedirect]);

  return (
    <>
      <div className="bg-white rounded-lg p-4 shadow-sm mb-3">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
            <svg className="w-6 h-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <div className="flex-1">
            <p className="font-semibold text-green-900">Order Successful!</p>
            <p className="text-xs text-green-600">Your order has been confirmed</p>
          </div>
        </div>
        <p className="text-sm text-gray-700">
          Thank you! Your order for {cartItems.length === 1 ? cartItems[0].title.substring(0, 30) + '...' : `${cartItems.length} products`} has been confirmed.
        </p>
        <div className="mt-3 text-center">
          <p className="text-sm text-gray-500">
            Redirecting to order details in <span className="font-bold text-orange-600">{countdown}</span> seconds...
          </p>
        </div>
      </div>

      <Button
        onClick={onRedirect}
        className="w-full bg-orange-600 hover:bg-orange-700"
        data-testid="button-view-order"
      >
        <ShoppingBag className="w-4 h-4 mr-2" />
        View Order Details
      </Button>
    </>
  );
}

export default function QRPayment() {
  const [location, setLocation] = useLocation();
  const { getApiPath, getRoutePath } = useTenant();
  const [step, setStep] = useState<'confirmation' | 'qr' | 'upload' | 'verifying' | 'success' | 'failed'>('confirmation');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [subtotal, setSubtotal] = useState(0); // Item price (original)
  const [discount, setDiscount] = useState(0);
  const [discountPercentage, setDiscountPercentage] = useState(0);
  const [deliveryCharge] = useState(75);
  const [totalAmount, setTotalAmount] = useState(0);
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');
  const [countdown, setCountdown] = useState(120); // 2 minutes in seconds
  const [transactionId, setTransactionId] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Extract tenant slug from URL
  const getTenantSlug = (): string | null => {
    const match = location.match(/^\/store\/([^/]+)/);
    return match ? match[1] : null;
  };
  const tenantSlug = getTenantSlug();

  useEffect(() => {
    // Fetch QR code from backend (tenant-aware)
    fetch(getApiPath('/api/qr-code'))
      .then(res => res.json())
      .then(data => {
        if (data.imageUrl) {
          setQrCodeUrl(data.imageUrl);
        }
      })
      .catch(err => console.error('Error fetching QR code:', err));

    // Load cart from localStorage (tenant-aware)
    const cartKey = tenantSlug ? `guest-cart-${tenantSlug}` : 'guest-cart';
    const savedCart = localStorage.getItem(cartKey);
    
    if (savedCart) {
      const parsedCart = JSON.parse(savedCart);
      const formatted = parsedCart.map((item: any) => {
        // Handle both nested product object and flat structure
        const productData = item.product || item;
        return {
          id: productData?.id || productData?._id || item.productId,
          title: productData?.title || item.title || '',
          price: productData?.price || item.price || '0',
          originalPrice: productData?.originalPrice || item.originalPrice,
          imageUrl: productData?.imageUrl || item.imageUrl,
          quantity: item.quantity || 1
        };
      });
      setCartItems(formatted);
      
      // Calculate item price (original price)
      const originalTotal = formatted.reduce((sum: number, item: any) => {
        return sum + (parseInt(item.originalPrice || item.price) * item.quantity);
      }, 0);
      setSubtotal(originalTotal); // Item price = original price
      
      // Calculate current price after discount
      const currentTotal = formatted.reduce((sum: number, item: any) => {
        return sum + (parseInt(item.price) * item.quantity);
      }, 0);
      
      // Calculate discount amount and percentage
      const discountAmount = originalTotal - currentTotal;
      setDiscount(discountAmount);
      const discountPct = originalTotal > 0 ? Math.round((discountAmount / originalTotal) * 100) : 0;
      setDiscountPercentage(discountPct);
      
      // Calculate final total (current price + delivery)
      const final = currentTotal + 75; // Add delivery charge
      setTotalAmount(final);
    }
  }, [tenantSlug]);

  const handleCancel = () => {
    setLocation(getRoutePath('/checkout'));
  };

  const handleYes = () => {
    setStep('qr');
  };

  const handleNo = () => {
    setLocation(getRoutePath('/checkout'));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setScreenshot(e.target.files[0]);
    }
  };

  const handleVerify = async () => {
    if (screenshot && !isSubmitting) {
      setIsSubmitting(true);
      
      // Convert screenshot to base64
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = reader.result as string;
        
        // Send to backend and get transaction ID (tenant-aware)
        let txId = '';
        try {
          console.log('📤 Submitting payment screenshot...');
          const response = await fetch(getApiPath('/api/transaction-log'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              productTitle: cartItems.map(item => item.title).join(', '),
              amount: totalAmount,
              screenshotBase64: base64String
            })
          });
          
          if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            console.error('❌ Server error:', response.status, errorData);
            setIsSubmitting(false);
            const errorMsg = errorData?.error || 'Unknown error';
            alert(`Payment failed: ${errorMsg}`);
            return;
          }
          
          const data = await response.json();
          console.log('📤 Transaction created, response:', data);
          
          if (data.transactionId) {
            txId = data.transactionId;
            setTransactionId(txId);
            console.log('✅ Transaction ID saved:', txId);
          } else {
            console.error('❌ No transaction ID in response!', data);
            setIsSubmitting(false);
            alert('Payment submission failed. Please try again.');
            return; // Exit if no transaction ID
          }
        } catch (error) {
          console.error('❌ Error sending screenshot:', error);
          setIsSubmitting(false);
          alert('Connection error. Please check your internet and try again.');
          return; // Exit on error
        }
        
        // Reset submitting state and start verification
        setIsSubmitting(false);
        setStep('verifying');
        setCountdown(120); // 2 minutes
        
        // Countdown timer
        const countdownTimer = setInterval(() => {
          setCountdown(prev => prev - 1);
        }, 1000);
        
        // Poll for transaction status every 3 seconds
        const pollTimer = setInterval(async () => {
          try {
            console.log('🔄 Polling transaction status for ID:', txId);
            const response = await fetch(getApiPath(`/api/transaction-status/${txId}`));
            
            if (!response.ok) {
              console.error('❌ Poll response not OK:', response.status, response.statusText);
              return;
            }
            
            const statusData = await response.json();
            console.log('✅ Poll response:', statusData);
            
            if (statusData.status === 'approved') {
              console.log('✅ Payment APPROVED - Showing success');
              clearInterval(countdownTimer);
              clearInterval(pollTimer);
              
              // Save order data to sessionStorage for order-success page
              const addressKey = tenantSlug ? `delivery-address-${tenantSlug}` : 'delivery-address';
              const savedAddress = JSON.parse(localStorage.getItem(addressKey) || '{}');
              
              const orderData = {
                orderId: `ORD${Date.now().toString().slice(-8)}`,
                productTitle: cartItems.length === 1 ? cartItems[0].title : `${cartItems.length} Products`,
                productImage: cartItems.length > 0 ? cartItems[0].imageUrl : '',
                amount: totalAmount,
                subtotal: subtotal,
                discount: discount,
                discountPercentage: discountPercentage,
                deliveryCharge: deliveryCharge,
                quantity: cartItems.reduce((sum, item) => sum + item.quantity, 0),
                orderDate: new Date().toISOString(),
                deliveryAddress: savedAddress
              };
              sessionStorage.setItem('lastOrder', JSON.stringify(orderData));
              
              setStep('success');
            } else if (statusData.status === 'declined') {
              console.log('❌ Payment DECLINED - Showing failure');
              clearInterval(countdownTimer);
              clearInterval(pollTimer);
              setStep('failed');
            } else {
              console.log('⏳ Payment still pending, status:', statusData.status);
            }
          } catch (error) {
            console.error('❌ Error polling status:', error);
          }
        }, 3000);
        
        // Cleanup timers after 10 minutes
        setTimeout(() => {
          clearInterval(countdownTimer);
          clearInterval(pollTimer);
        }, 600000);
      };
      reader.readAsDataURL(screenshot);
    }
  };

  const handleMoreShopping = () => {
    // Clear cart and go to homepage (tenant-aware)
    const cartKey = tenantSlug ? `guest-cart-${tenantSlug}` : 'guest-cart';
    localStorage.setItem(cartKey, JSON.stringify([]));
    setLocation(getRoutePath('/'));
  };

  const handleDownloadQR = async () => {
    if (qrCodeUrl) {
      try {
        // Use proxy to avoid CORS issues
        const response = await fetch(`/api/proxy-qr?url=${encodeURIComponent(qrCodeUrl)}`);
        if (!response.ok) throw new Error('Proxy fetch failed');
        
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = `payment-qr-${totalAmount}.png`;
        link.click();
        
        URL.revokeObjectURL(url);
      } catch (error) {
        console.error('Error downloading QR code:', error);
        // Fallback to SVG download if remote fails
        downloadSVGFallback();
      }
    } else {
      // Fallback to SVG download
      downloadSVGFallback();
    }
  };

  const downloadSVGFallback = () => {
    const svg = document.querySelector('.qr-code-svg') as SVGElement;
    if (!svg) return;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = 512;
    canvas.height = 512;

    // Convert SVG to image and download
    const svgData = new XMLSerializer().serializeToString(svg);
    const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);

    const img = new Image();
    img.onload = () => {
      ctx.drawImage(img, 0, 0, 512, 512);
      canvas.toBlob((blob) => {
        if (blob) {
          const link = document.createElement('a');
          link.download = `payment-qr-${totalAmount}.png`;
          link.href = URL.createObjectURL(blob);
          link.click();
          URL.revokeObjectURL(link.href);
        }
      });
      URL.revokeObjectURL(url);
    };
    img.src = url;
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header with Cancel Button */}
      <div className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bot className="w-6 h-6 text-purple-600" />
            <h1 className="font-semibold text-lg">Payment Agent</h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleCancel}
            data-testid="button-cancel-payment"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Chat Container */}
      <div className="max-w-2xl mx-auto px-4 py-6 space-y-4">
        {/* Bot Avatar and Messages */}
        <div className="flex gap-3">
          <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center flex-shrink-0">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            {/* Greeting Message */}
            <div className="bg-white rounded-lg rounded-tl-none p-4 shadow-sm mb-3">
              <p className="text-sm text-gray-700">
                Hello! I am your Payment Agent. I will help you complete the payment.
              </p>
            </div>

            {/* Confirmation Step */}
            {step === 'confirmation' && (
              <>
                {/* Product Details */}
                {cartItems.map((item) => (
                  <div key={item.id} className="bg-white rounded-lg p-4 shadow-sm mb-3">
                    <div className="flex gap-3">
                      <img
                        src={getProxiedImageUrl(item.imageUrl)}
                        alt={item.title}
                        className="w-16 h-16 object-cover rounded"
                        referrerPolicy="no-referrer"
                        onError={(e) => { e.currentTarget.src = '/placeholder-product.svg'; }}
                      />
                      <div className="flex-1">
                        <p className="text-sm font-medium line-clamp-2">{item.title}</p>
                        <p className="text-orange-600 font-semibold mt-1">Rs. {parseInt(item.price).toLocaleString()}</p>
                        <p className="text-xs text-gray-500">Quantity: {item.quantity}</p>
                      </div>
                    </div>
                  </div>
                ))}

                {/* Question */}
                <div className="bg-white rounded-lg p-4 shadow-sm mb-3">
                  <p className="text-sm text-gray-700 font-medium mb-3">
                    Do you want to buy this product?
                  </p>
                  
                  {/* Price Breakdown */}
                  <div className="border-t pt-3 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Item:</span>
                      <span className="font-medium">Rs. {subtotal.toLocaleString()}</span>
                    </div>
                    {discount > 0 && (
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Sale Offer ({discountPercentage}% OFF):</span>
                        <span className="font-medium text-green-600">- Rs. {discount.toLocaleString()}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Delivery Charge:</span>
                      <span className="font-medium">Rs. {deliveryCharge}</span>
                    </div>
                    <div className="border-t pt-2 flex justify-between">
                      <span className="font-semibold text-gray-900">Total Amount:</span>
                      <span className="font-bold text-orange-600 text-lg">Rs. {totalAmount.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                {/* Yes/No Buttons */}
                <div className="flex gap-3">
                  <Button
                    onClick={handleYes}
                    className="flex-1 bg-green-600 hover:bg-green-700"
                    data-testid="button-yes"
                  >
                    YES
                  </Button>
                  <Button
                    onClick={handleNo}
                    variant="outline"
                    className="flex-1"
                    data-testid="button-no"
                  >
                    NO
                  </Button>
                </div>
              </>
            )}

            {/* QR Code Step */}
            {step === 'qr' && (
              <>
                <div className="bg-white rounded-lg p-4 shadow-sm mb-3">
                  <p className="text-sm text-gray-700 mb-3">
                    Please scan this QR Code and pay <span className="font-bold text-orange-600">Rs. {totalAmount.toLocaleString()}</span>.
                  </p>
                  
                  {/* Important Warning */}
                  <div className="bg-yellow-50 border-l-4 border-yellow-400 p-3 mb-3">
                    <p className="text-xs text-yellow-800">
                      <span className="font-semibold">⚠️</span> Pay exactly <span className="font-bold">Rs. {totalAmount.toLocaleString()}</span> only. If amount is less or more, verification will fail.
                    </p>
                  </div>

                  {/* QR Code Placeholder */}
                  <div className="bg-gray-100 rounded-lg p-6 flex flex-col items-center justify-center">
                    <div className="w-64 h-64 bg-white rounded-lg shadow-md flex items-center justify-center mb-3">
                      {qrCodeUrl ? (
                        <img 
                          src={qrCodeUrl} 
                          alt="Payment QR Code" 
                          className="w-full h-full object-contain p-4"
                        />
                      ) : (
                        <svg viewBox="0 0 200 200" className="w-full h-full p-4 qr-code-svg">
                          <rect width="200" height="200" fill="white"/>
                          <g fill="black">
                            {/* Sample QR code pattern */}
                            <rect x="20" y="20" width="60" height="60"/>
                            <rect x="30" y="30" width="40" height="40" fill="white"/>
                            <rect x="120" y="20" width="60" height="60"/>
                            <rect x="130" y="30" width="40" height="40" fill="white"/>
                            <rect x="20" y="120" width="60" height="60"/>
                            <rect x="30" y="130" width="40" height="40" fill="white"/>
                            {/* Center pattern */}
                            <rect x="90" y="90" width="20" height="20"/>
                            {/* Random dots for QR effect */}
                            <rect x="100" y="40" width="10" height="10"/>
                            <rect x="120" y="100" width="10" height="10"/>
                            <rect x="50" y="100" width="10" height="10"/>
                            <rect x="160" y="90" width="10" height="10"/>
                          </g>
                        </svg>
                      )}
                    </div>
                    <p className="text-xs text-gray-600 text-center mb-3">
                      Scan using any UPI app
                    </p>
                    
                    {/* Download QR Button */}
                    <Button
                      onClick={handleDownloadQR}
                      variant="outline"
                      className="w-full max-w-xs"
                      data-testid="button-download-qr"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download QR Code
                    </Button>
                  </div>
                </div>

                <div className="bg-white rounded-lg p-4 shadow-sm mb-3">
                  <p className="text-sm text-gray-700">
                    After payment, upload the screenshot and click Submit. You will be redirected automatically once payment is confirmed.
                  </p>
                </div>

                {/* Screenshot Upload */}
                <div className="bg-white rounded-lg p-4 shadow-sm">
                  <label className="block mb-2 text-sm font-medium text-gray-700">
                    Upload Payment Screenshot
                  </label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-orange-50 file:text-orange-700 hover:file:bg-orange-100"
                    data-testid="input-screenshot"
                  />
                  {screenshot && (
                    <p className="text-xs text-green-600 mt-2">✓ Screenshot uploaded: {screenshot.name}</p>
                  )}
                </div>

                <Button
                  onClick={handleVerify}
                  disabled={!screenshot || isSubmitting}
                  className="w-full bg-orange-600 hover:bg-orange-700 mt-3"
                  data-testid="button-verify"
                >
                  {isSubmitting ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Submitting...
                    </>
                  ) : 'Submit Payment'}
                </Button>
              </>
            )}

            {/* Verifying Step - 2 minute countdown with real-time status */}
            {step === 'verifying' && (
              <>
                <div className="bg-white rounded-lg p-4 shadow-sm mb-3">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                      <svg className="animate-spin h-6 w-6 text-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-gray-900">Processing Payment</p>
                      {countdown >= 0 ? (
                        <p className="text-lg font-mono text-blue-600">
                          {Math.floor(countdown / 60)}:{(countdown % 60).toString().padStart(2, '0')}
                        </p>
                      ) : (
                        <p className="text-xs text-amber-600">Time expired...</p>
                      )}
                    </div>
                  </div>
                  {countdown >= 0 ? (
                    <p className="text-sm text-gray-700">
                      Please wait while we confirm your payment. You will be redirected automatically once confirmed.
                    </p>
                  ) : (
                    <p className="text-sm text-amber-700">
                      Payment confirmation is taking longer than expected. Please wait or contact support if this persists.
                    </p>
                  )}
                </div>
              </>
            )}

            {/* Success Step - Redirect to order-success after 5 seconds */}
            {step === 'success' && (
              <SuccessRedirect 
                cartItems={cartItems} 
                onRedirect={() => {
                  const cartKey = tenantSlug ? `guest-cart-${tenantSlug}` : 'guest-cart';
                  localStorage.setItem(cartKey, JSON.stringify([]));
                  setLocation(getRoutePath('/order-success'));
                }}
              />
            )}

            {/* Failed Step */}
            {step === 'failed' && (
              <>
                <div className="bg-white rounded-lg p-4 shadow-sm mb-3">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
                      <svg className="w-6 h-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-red-900">Payment Failed ❌</p>
                      <p className="text-xs text-red-600">Your order has been cancelled</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-700">
                    Sorry, your payment could not be verified. Order has been cancelled. Please try again or contact our support team.
                  </p>
                </div>

                {/* Try Again Button */}
                <Button
                  onClick={() => setLocation('/checkout')}
                  variant="outline"
                  className="w-full mb-3"
                  data-testid="button-try-again"
                >
                  Try Again
                </Button>

                {/* More Shopping Button */}
                <Button
                  onClick={handleMoreShopping}
                  className="w-full bg-orange-600 hover:bg-orange-700"
                  data-testid="button-more-shopping"
                >
                  <ShoppingBag className="w-4 h-4 mr-2" />
                  More Shopping
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
