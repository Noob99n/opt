import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { SearchBar } from '@/components/layout/search-bar';
import { Icon } from '@/components/ui/icon';
import { Product } from '@shared/schema';
import { getProxiedImageUrl } from '@/lib/image-proxy';

function SearchResults({ query }: { query: string }) {
  const [, setLocation] = useLocation();
  
  const { data: products = [], isLoading } = useQuery({
    queryKey: ['/api/products/search', query],
    queryFn: async () => {
      const response = await fetch(`/api/products/search/${encodeURIComponent(query)}`);
      if (!response.ok) throw new Error('Failed to search products');
      return response.json() as Promise<Product[]>;
    },
    enabled: !!query,
  });

  if (isLoading) {
    return (
      <div className="px-4 py-6 space-y-4">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="bg-white rounded-lg p-4 flex gap-4 animate-pulse">
            <div className="w-16 h-16 bg-gray-200 rounded"></div>
            <div className="flex-1 space-y-2">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              <div className="h-6 bg-gray-200 rounded w-1/2"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="px-4 py-8">
        <div className="bg-white rounded-lg shadow-card p-8 text-center">
          <div className="text-gray-400 mb-4">
            <Icon name="package" size={64} className="mx-auto" />
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-3">No Results Found</h3>
          <p className="text-gray-600 text-sm">
            Try different keywords or browse categories instead.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 py-6 space-y-4">
      {products.map((product) => (
        <div 
          key={product.id} 
          className="bg-white rounded-lg p-4 flex gap-4 cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => setLocation(`/product/${product.slug || product.id}`)}
        >
          <img 
            src={getProxiedImageUrl(product.imageUrl)} 
            alt={product.title}
            className="w-16 h-16 object-cover rounded"
            referrerPolicy="no-referrer"
            onError={(e) => {
              e.currentTarget.src = '/placeholder-product.svg';
            }}
          />
          <div className="flex-1">
            <h3 className="font-medium text-gray-800 line-clamp-2 mb-1">{product.title}</h3>
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold text-orange-500">₹{product.price}</span>
              {product.originalPrice && parseFloat(product.originalPrice) > parseFloat(product.price) && (
                <span className="text-sm text-gray-500 line-through">₹{product.originalPrice}</span>
              )}
              {product.discount > 0 && (
                <span className="text-xs bg-orange-100 text-orange-600 px-2 py-1 rounded">
                  {product.discount}% OFF
                </span>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default function Search() {
  const [, setLocation] = useLocation();
  const params = new URLSearchParams(window.location.search);
  const query = params.get('q') || '';

  const { data: settings = { script: 'none' } } = useQuery({
    queryKey: ['/api/settings'],
    queryFn: async () => {
      const response = await fetch('/api/settings');
      if (!response.ok) throw new Error('Failed to fetch settings');
      return response.json() as Promise<{ script: string }>;
    },
  });

  const handleSearch = (searchQuery: string) => {
    if (searchQuery.trim()) {
      setLocation(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  const isScriptActive = settings.script !== 'none';

  return (
    <div className="min-h-screen pb-20" style={{ backgroundColor: '#f1f3f6' }}>
      <SearchBar onSearch={handleSearch} placeholder="Search products..." />
      
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-4">
        <h1 className="text-lg font-semibold text-gray-800">
          {query ? `Search results for "${query}"` : 'Search Products'}
        </h1>
      </div>

      {!isScriptActive ? (
        <div className="px-4 py-8">
          <div className="bg-white rounded-lg shadow-card p-8 text-center">
            <div className="text-gray-400 mb-4">
              <Icon name="search" size={64} className="mx-auto" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-3">Search Unavailable</h3>
            <p className="text-gray-600 text-sm">
              No script is active. Search will be available when admin activates a product script.
            </p>
          </div>
        </div>
      ) : query ? (
        <SearchResults query={query} />
      ) : (
        <div className="px-4 py-8">
          <div className="bg-white rounded-lg shadow-card p-8 text-center">
            <div className="text-gray-400 mb-4">
              <Icon name="search" size={48} className="mx-auto" />
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Start Searching</h3>
            <p className="text-gray-600 text-sm">
              Enter keywords to find your desired products.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}