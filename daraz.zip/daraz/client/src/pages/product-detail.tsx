import { useQuery } from '@tanstack/react-query';
import { useLocation, useParams } from 'wouter';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Icon } from '@/components/ui/icon';
import { useCart } from '@/hooks/use-cart';
import { Product } from '@shared/schema';

export default function ProductDetail() {
  const [, setLocation] = useLocation();
  const { id } = useParams<{ id: string }>();
  const { addToCart } = useCart();
  const [activeTab, setActiveTab] = useState('Overview');

  const { data: product, isLoading, error } = useQuery({
    queryKey: ['product', id],
    queryFn: async () => {
      const response = await fetch(`/api/products/${id}`);
      if (!response.ok) throw new Error('Failed to fetch product');
      return response.json();
    },
    enabled: !!id,
    retry: 1,
  });

  const handleAddToCart = () => {
    if (product) {
      addToCart({ productId: product.id, quantity: 1 });
    }
  };

  const handleBuyNow = () => {
    if (product) {
      addToCart({ productId: product.id, quantity: 1 });
      setLocation('/checkout');
    }
  };

  const tabs = ['Overview', 'Ratings', 'Recommendations', 'Details'];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 pb-20">
        <div className="bg-white px-4 py-3 shadow-sm flex items-center justify-between">
          <button onClick={() => setLocation('/')} className="text-gray-600">
            <Icon name="arrow-left" size={20} />
          </button>
          <div className="flex items-center gap-3">
            <Icon name="shopping-cart" size={20} className="text-gray-600" />
            <Icon name="more-vertical" size={20} className="text-gray-600" />
          </div>
        </div>
        <div className="p-4 space-y-4">
          <div className="w-full h-80 bg-gray-200 rounded-lg animate-pulse"></div>
          <div className="space-y-2">
            <div className="h-6 bg-gray-200 rounded animate-pulse"></div>
            <div className="h-4 bg-gray-200 rounded animate-pulse w-2/3"></div>
            <div className="h-8 bg-gray-200 rounded animate-pulse w-1/2"></div>
          </div>
          <div className="text-sm text-gray-500">Loading product...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 pb-20">
        <div className="bg-white px-4 py-3 shadow-sm flex items-center justify-between">
          <button onClick={() => setLocation('/')} className="text-gray-600">
            <Icon name="arrow-left" size={20} />
          </button>
        </div>
        <div className="p-4 text-center">
          <p className="text-red-600">Error loading product</p>
          <button onClick={() => setLocation('/')} className="mt-4 px-4 py-2 bg-blue-500 text-white rounded">
            Go Back
          </button>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 pb-20 flex items-center justify-center">
        <div className="text-center">
          <Icon name="search" size={48} className="text-gray-400 mb-4" />
          <p className="text-gray-600">Product not found</p>
          <button onClick={() => setLocation('/')} className="mt-4 px-4 py-2 bg-blue-500 text-white rounded">
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-white px-4 py-3 shadow-sm flex items-center justify-between">
        <button onClick={() => setLocation('/')} className="text-gray-600">
          <Icon name="arrow-left" size={20} />
        </button>
        <div className="flex items-center gap-3">
          <button onClick={() => setLocation('/cart')} className="text-gray-600">
            <Icon name="shopping-cart" size={20} />
          </button>
          <button className="text-gray-600">
            <Icon name="more-vertical" size={20} />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white px-4 py-2 shadow-sm">
        <div className="flex gap-6">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`pb-2 text-sm font-medium ${
                activeTab === tab
                  ? 'text-primary border-b-2 border-primary'
                  : 'text-gray-500'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Product Image */}
      <div className="relative">
        <div className="w-full h-80 bg-white flex items-center justify-center">
          <img 
            src={product.imageUrl || "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=400&fit=crop"} 
            alt={product.title}
            className="w-full h-full object-contain"
            onError={(e) => {
              e.currentTarget.src = "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=400&fit=crop";
            }}
          />
        </div>
        <div className="absolute bottom-4 right-4 bg-white/80 rounded-full px-3 py-1">
          <span className="text-sm font-medium">1/{product.imageUrl2 || product.imageUrl3 || product.imageUrl4 ? '4' : '1'}</span>
        </div>
      </div>

      {/* Flash Sale Badge */}
      {product.isFlashSale && (
        <div className="mx-4 my-4">
          <div className="bg-gradient-to-r from-purple-600 to-purple-700 rounded-lg px-4 py-2 flex items-center justify-between">
            <span className="text-white font-bold">7.7 MEGA SALE From 7-11 JUNE</span>
            <Badge variant="secondary" className="bg-white text-purple-600 font-bold">
              7.7
            </Badge>
          </div>
        </div>
      )}

      {/* Product Info */}
      <div className="px-4 bg-white">
        <div className="flex items-center gap-4 py-4">
          <div className="text-gray-500 text-sm">Rs. 1,000</div>
          <div className="text-gray-500 text-xs">Starts in 1 day(s) 14:31:16</div>
        </div>
        
        <div className="flex items-center justify-between mb-4">
          <div className="text-primary text-3xl font-bold">
            Rs. {parseFloat(product.price).toLocaleString()}
          </div>
          <div className="flex items-center gap-2">
            <button className="text-gray-400">
              <Icon name="heart" size={20} />
            </button>
            <button className="text-gray-400">
              <Icon name="share" size={20} />
            </button>
          </div>
        </div>
        
        <h1 className="text-lg font-semibold text-gray-800 mb-2">{product.title}</h1>
        
        <div className="flex items-center gap-2 mb-4">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <Icon
                key={i}
                name="star"
                size={16}
                className={`${
                  i < Math.floor(parseFloat(product.rating || '0'))
                    ? 'text-yellow-400 fill-current'
                    : 'text-gray-300'
                }`}
              />
            ))}
          </div>
          <span className="text-sm text-gray-600">
            {product.rating} ({product.reviewCount})
          </span>
        </div>
      </div>

      {/* Product Options */}
      <div className="px-4 py-4 bg-white border-t border-gray-100">
        <div className="flex items-center justify-between">
          <span className="text-gray-600">Product Options</span>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-800">Red</span>
            <Icon name="chevron-right" size={16} className="text-gray-400" />
          </div>
        </div>
        <div className="mt-2">
          <div className="w-12 h-12 bg-red-500 rounded-lg border-2 border-primary"></div>
        </div>
      </div>

      {/* Specifications */}
      <div className="px-4 py-4 bg-white border-t border-gray-100">
        <div className="flex items-center justify-between">
          <span className="text-gray-600">Specifications</span>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-800">Brand, Cable Length, Box Content</span>
            <Icon name="chevron-right" size={16} className="text-gray-400" />
          </div>
        </div>
      </div>

      {/* Delivery Info */}
      <div className="px-4 py-4 bg-white border-t border-gray-100">
        <div className="flex items-center justify-between">
          <span className="text-gray-600">Delivery</span>
          <Icon name="chevron-right" size={16} className="text-gray-400" />
        </div>
        <div className="mt-2 text-sm text-gray-800">
          <div className="flex items-center gap-2">
            <Icon name="map-pin" size={16} className="text-primary" />
            <span>Bagmati, Kathmandu Metro 22 - Newroad Area, Newroad</span>
          </div>
          <div className="mt-1">
            <span className="font-semibold">Standard Delivery</span> - Guaranteed by 7-8 Jul
            <span className="text-primary font-semibold ml-2">Rs. 75</span>
          </div>
        </div>
      </div>

      {/* Service Info */}
      <div className="px-4 py-4 bg-white border-t border-gray-100">
        <div className="flex items-center justify-between">
          <span className="text-gray-600">Service</span>
          <Icon name="chevron-right" size={16} className="text-gray-400" />
        </div>
        <div className="mt-2">
          <div className="flex items-center gap-2 mb-1">
            <Icon name="truck" size={16} className="text-green-600" />
            <span className="text-sm text-gray-800">14 Days Free Returns</span>
          </div>
          <div className="text-xs text-gray-500">Change of mind is not applicable</div>
          <div className="flex items-center gap-2 mt-2">
            <Icon name="shield" size={16} className="text-gray-400" />
            <span className="text-sm text-gray-800">Warranty not available</span>
          </div>
        </div>
      </div>

      {/* Reviews Section */}
      <div className="px-4 py-4 bg-white border-t border-gray-100">
        <div className="flex items-center justify-between">
          <span className="text-gray-600">Ratings and Reviews ({product.reviewCount})</span>
          <Button variant="ghost" className="text-primary text-sm font-medium p-0">
            View All
          </Button>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="fixed bottom-16 left-0 right-0 bg-white border-t border-gray-200 px-4 py-3 z-40">
        <div className="mobile-container flex gap-2">
          <Button variant="outline" size="lg" className="w-12 h-12">
            <Icon name="store" size={20} className="text-gray-600" />
          </Button>
          <Button variant="outline" size="lg" className="w-12 h-12">
            <Icon name="message" size={20} className="text-gray-600" />
          </Button>
          <Button
            size="lg"
            className="flex-1 bg-blue-500 hover:bg-blue-600 text-white"
            onClick={handleBuyNow}
          >
            바로 구매
          </Button>
          <Button
            size="lg"
            className="flex-1 btn-orange"
            onClick={handleAddToCart}
          >
            장바구니 담기
          </Button>
        </div>
      </div>
    </div>
  );
}
