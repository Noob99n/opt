import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Icon } from '@/components/ui/icon';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/hooks/use-cart';
import { getProxiedImageUrl } from '@/lib/image-proxy';
import { useState } from 'react';

export default function Cart() {
  const [, setLocation] = useLocation();
  const { cartItems, cartCount, cartTotal, updateCartItem, removeFromCart, isLoading } = useCart();
  const [selectedItems, setSelectedItems] = useState<number[]>([]);

  const handleQuantityChange = (itemId: number, change: number) => {
    const item = cartItems.find(i => i.id === itemId);
    if (item) {
      const newQuantity = Math.max(1, item.quantity + change);
      updateCartItem({ id: itemId, quantity: newQuantity });
    }
  };

  const handleRemoveItem = (itemId: number) => {
    removeFromCart(itemId);
  };

  const handleCheckout = () => {
    setLocation('/checkout');
  };

  const toggleItemSelection = (itemId: number) => {
    setSelectedItems(prev => 
      prev.includes(itemId) 
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const toggleSelectAll = () => {
    if (selectedItems.length === cartItems.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(cartItems.map(item => item.id));
    }
  };

  const selectedTotal = cartItems
    .filter(item => selectedItems.includes(item.id))
    .reduce((sum, item) => sum + (parseFloat(item.product.price) * item.quantity), 0);

  console.log("Cart Debug:", { cartItems, cartCount, isLoading, cartItemsLength: cartItems?.length });

  if (isLoading) {
    return (
      <div className="bottom-safe-area">
        <div className="bg-white px-4 py-3 shadow-sm flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Icon name="arrow-left" size={20} className="text-gray-600" />
            <h1 className="text-lg font-semibold">My Cart</h1>
          </div>
          <Icon name="trash" size={20} className="text-gray-600" />
        </div>
        <div className="p-4 space-y-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i} className="skeleton">
              <CardContent className="p-4">
                <div className="flex gap-3">
                  <div className="w-20 h-20 bg-gray-200 rounded-lg"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-200 rounded"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                    <div className="h-5 bg-gray-200 rounded w-1/3"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20" style={{ backgroundColor: '#f1f3f6' }}>
      {/* Header */}
      <div className="bg-white px-4 py-3 shadow-sm flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => setLocation('/')} className="text-gray-600">
            <Icon name="arrow-left" size={20} />
          </button>
          <h1 className="text-lg font-semibold">내 장바구니({cartCount})</h1>
        </div>
        <button className="text-gray-600">
          <Icon name="trash" size={20} />
        </button>
      </div>

      {cartItems && cartItems.length > 0 ? (
        <>
          <div className="px-4 py-4 space-y-4">
            {/* Store Section */}
            <Card className="shadow-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-4">
                  <Checkbox
                    checked={selectedItems.length === cartItems.length}
                    onCheckedChange={toggleSelectAll}
                  />
                  <span className="font-semibold text-gray-800">Deal Aayooo</span>
                  <Icon name="chevron-right" size={16} className="text-gray-400" />
                </div>
                
                <div className="space-y-4">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex gap-3">
                      <Checkbox
                        checked={selectedItems.includes(item.id)}
                        onCheckedChange={() => toggleItemSelection(item.id)}
                        className="mt-2"
                      />
                      <div className="flex-1 flex gap-3">
                        <div className="w-20 h-20 bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden">
                          {item.product.imageUrl ? (
                            <img 
                              src={getProxiedImageUrl(item.product.imageUrl)} 
                              alt={item.product.title}
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                              onError={(e) => { e.currentTarget.src = '/placeholder-product.svg'; }}
                            />
                          ) : (
                            <Icon name="smartphone" className="text-gray-400" size={20} />
                          )}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium text-gray-800 mb-1 line-clamp-2">
                            {item.product.title}
                          </h3>
                          <div className="text-gray-500 text-sm mb-2">
                            {item.product.brand || 'No Brand'}
                          </div>
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="text-primary font-bold text-lg">
                                Rs. {parseFloat(item.product.price).toLocaleString()}
                              </div>
                              {item.product.originalPrice && (
                                <div className="text-gray-400 text-sm line-through">
                                  Rs. {parseFloat(item.product.originalPrice).toLocaleString()}
                                </div>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleQuantityChange(item.id, -1)}
                                className="w-8 h-8 rounded-full p-0"
                              >
                                <Icon name="minus" size={16} />
                              </Button>
                              <span className="text-lg font-medium w-8 text-center">
                                {item.quantity}
                              </span>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleQuantityChange(item.id, 1)}
                                className="w-8 h-8 rounded-full p-0"
                              >
                                <Icon name="plus" size={16} />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Fixed bottom checkout bar */}
          <div className="fixed bottom-16 left-0 right-0 bg-white border-t px-4 py-3">
            <div className="max-w-md mx-auto">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Checkbox
                    checked={selectedItems.length === cartItems.length}
                    onCheckedChange={toggleSelectAll}
                  />
                  <span className="text-sm">All ({cartItems.length})</span>
                </div>
                <div className="text-right">
                  <div className="text-xs text-gray-500">총 합계</div>
                  <div className="text-lg font-bold text-primary">
                    Rs. {selectedTotal.toLocaleString()}
                  </div>
                </div>
              </div>
              
              <Button 
                onClick={handleCheckout}
                className="w-full btn-orange"
                disabled={selectedItems.length === 0}
              >
                Checkout ({selectedItems.length})
              </Button>
            </div>
          </div>
        </>
      ) : (
        <div className="flex-1 flex items-center justify-center p-8">
          <div className="text-center">
            <Icon name="shopping-cart" size={64} className="text-gray-400 mb-4" />
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Your cart is empty</h2>
            <p className="text-gray-600 mb-4">Add some products to get started</p>
            <Button onClick={() => setLocation('/')} className="btn-orange">
              Start Shopping
            </Button>
            <div className="text-xs text-gray-400 mt-4">
              Debug: cartItems={cartItems?.length || 0}, isLoading={isLoading ? 'true' : 'false'}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}