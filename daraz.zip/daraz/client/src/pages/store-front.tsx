import { useRoute } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { SearchBar } from '@/components/layout/search-bar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Icon } from '@/components/ui/icon';
import { Card, CardContent } from '@/components/ui/card';
import { AlertCircle, Store, ShoppingBag, Clock } from 'lucide-react';

interface Product {
  _id?: string;
  id?: number;
  title: string;
  price: string;
  originalPrice?: string;
  imageUrl?: string;
  imageUrl2?: string;
  imageUrls?: string[];
  discount?: number;
  isFlashDeal?: boolean;
  slug?: string;
  sold?: number;
}

interface StoreInfo {
  storeName: string;
  storeSlug: string;
  adminUsername: string;
  isActive: boolean;
}

export default function StoreFront() {
  const [, params] = useRoute('/store/:slug');
  const slug = params?.slug || '';
  const [, setLocation] = useLocation();
  const [selectedFilter, setSelectedFilter] = useState('All');
  
  const [offerTimer, setOfferTimer] = useState({ minutes: 10, seconds: 0 });
  
  useEffect(() => {
    const timer = setInterval(() => {
      setOfferTimer(prev => {
        let { minutes, seconds } = prev;
        if (seconds === 0) {
          if (minutes === 0) return { minutes: 10, seconds: 0 };
          minutes--;
          seconds = 59;
        } else {
          seconds--;
        }
        return { minutes, seconds };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const { data: storeInfo, isLoading: isLoadingStore, error: storeError } = useQuery<StoreInfo>({
    queryKey: ['/api/store', slug, 'info'],
    queryFn: async () => {
      const res = await fetch(`/api/store/${slug}/info`);
      if (!res.ok) throw new Error('Store not found');
      return res.json();
    },
    enabled: !!slug,
    retry: false
  });

  const { data: scriptProducts = [], isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ['/api/store', slug, 'products'],
    queryFn: async () => {
      const res = await fetch(`/api/store/${slug}/products`);
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!slug && !!storeInfo
  });

  const handleSearch = (query: string) => {
    if (query.trim()) {
      setLocation(`/store/${slug}/search?q=${encodeURIComponent(query)}`);
    }
  };

  const handleProductClick = (product: Product) => {
    setLocation(`/product/${product._id || product.id}`);
  };

  const categories = [
    { name: 'Electronics', icon: 'smartphone', color: 'from-blue-100 to-blue-200 text-blue-600' },
    { name: 'Fashion', icon: 'user', color: 'from-pink-100 to-pink-200 text-pink-600' },
    { name: 'Home & Living', icon: 'home', color: 'from-green-100 to-green-200 text-green-600' },
    { name: 'Mobiles', icon: 'smartphone', color: 'from-purple-100 to-purple-200 text-purple-600' },
    { name: 'Accessories', icon: 'sparkles', color: 'from-yellow-100 to-yellow-200 text-yellow-600' },
    { name: 'Watches', icon: 'clock', color: 'from-indigo-100 to-indigo-200 text-indigo-600' },
  ];

  const filters = ['All', 'Voucher', 'Discount', 'Free Delivery'];

  if (isLoadingStore) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Store className="w-12 h-12 text-orange-500 mx-auto mb-4 animate-pulse" />
          <p className="text-gray-600">Loading store...</p>
        </div>
      </div>
    );
  }

  if (storeError || !storeInfo) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Store Not Found</h2>
            <p className="text-gray-600 mb-4">
              The store "{slug}" doesn't exist or is no longer active.
            </p>
            <Badge variant="secondary" className="text-sm">
              Please check the URL and try again
            </Badge>
          </CardContent>
        </Card>
      </div>
    );
  }

  const flashProducts = scriptProducts.filter((p: Product) => p.isFlashDeal === true);
  const regularProducts = scriptProducts.filter((p: Product) => p.isFlashDeal !== true);
  const isScriptActive = scriptProducts.length > 0;

  return (
    <div className="min-h-screen pb-20" style={{ backgroundColor: '#f1f3f6' }}>
      <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white py-2 px-4">
        <div className="flex items-center justify-center gap-2">
          <Store className="w-5 h-5" />
          <span className="font-bold text-lg">{storeInfo.storeName}</span>
        </div>
      </div>

      <SearchBar onSearch={handleSearch} />

      {flashProducts.length > 0 && (
        <div className="px-4 mb-6">
          <div className="bg-gradient-to-r from-red-500 to-orange-500 text-white p-4 rounded-lg mb-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold">⚡ Flash महा बचत बजार</h2>
                <p className="text-sm opacity-90">Up to 72% OFF - Limited Time!</p>
              </div>
              <div className="flex items-center gap-1 bg-white/20 px-2 py-1 rounded">
                <Clock className="w-4 h-4" />
                <span className="font-mono font-bold">
                  {String(offerTimer.minutes).padStart(2, '0')}:{String(offerTimer.seconds).padStart(2, '0')}
                </span>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {flashProducts.slice(0, 4).map((product: Product, index: number) => (
              <div 
                key={product._id || index} 
                className="bg-white rounded-lg border shadow-sm p-3 cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => handleProductClick(product)}
                data-testid={`flash-product-${product._id || index}`}
              >
                <div className="relative">
                  <img 
                    src={product.imageUrl || product.imageUrl2 || "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&h=300&fit=crop"} 
                    className="w-full h-28 object-contain rounded mb-2" 
                    alt={product.title}
                    onError={(e) => {
                      e.currentTarget.src = "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&h=300&fit=crop";
                    }}
                  />
                  <div className="absolute top-1 right-1 bg-red-600 text-white text-[10px] px-1.5 py-0.5 rounded flex items-center gap-1">
                    <span>⏰</span>
                    <span>{String(offerTimer.minutes).padStart(2, '0')}:{String(offerTimer.seconds).padStart(2, '0')}</span>
                  </div>
                </div>
                <h4 className="text-sm font-bold text-gray-800 line-clamp-2">{product.title}</h4>
                <div className="flex items-center gap-1 mt-1 flex-wrap">
                  <span className="text-red-600 font-bold text-lg">Rs. {parseFloat(product.price || '0').toLocaleString()}</span>
                  {product.originalPrice && (
                    <span className="text-gray-400 line-through text-xs">Rs. {parseFloat(product.originalPrice).toLocaleString()}</span>
                  )}
                </div>
                {product.discount && product.discount > 0 && (
                  <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full mt-1 inline-block">{product.discount}% OFF</span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
      
      <div className="px-4 mb-6">
        <div className="bg-gradient-to-r from-orange-100 to-orange-200 rounded-lg p-4 text-center">
          <h3 className="text-lg font-bold text-orange-600">Shop by Category</h3>
          <p className="text-sm text-orange-500">Browse our wide selection</p>
        </div>
      </div>

      {!isScriptActive && !isLoadingProducts && (
        <div className="px-4 mb-6">
          <div className="bg-white rounded-lg shadow-card p-6 text-center">
            <ShoppingBag className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-800 mb-2">No Products Available</h3>
            <p className="text-gray-600 text-sm">
              This store hasn't added any products yet
            </p>
          </div>
        </div>
      )}
      
      {isLoadingProducts && (
        <div className="px-4 mb-6">
          <div className="bg-white rounded-lg shadow-card p-6 text-center">
            <div className="animate-pulse">
              <div className="w-12 h-12 bg-gray-200 rounded-full mx-auto mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-32 mx-auto mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-48 mx-auto"></div>
            </div>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between px-4 py-4">
        <h2 className="text-xl font-bold text-gray-800">Categories</h2>
        <Button
          variant="ghost"
          className="text-primary text-sm font-medium p-0"
        >
          Shop More <Icon name="chevron-right" size={16} className="ml-1" />
        </Button>
      </div>

      <div className="px-4 grid grid-cols-3 gap-3 mb-6">
        {categories.map((category, index) => (
          <Card key={index} className="cursor-pointer hover:shadow-md transition-shadow">
            <CardContent className="p-0">
              <div className={`w-full h-16 bg-gradient-to-br ${category.color} flex items-center justify-center rounded-t-lg`}>
                <Icon name={category.icon as any} size={24} />
              </div>
              <div className="p-2">
                <h3 className="font-medium text-gray-800 text-xs text-center">{category.name}</h3>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {isScriptActive && (
        <div className="px-4 mb-6">
          <div className="flex gap-2 overflow-x-auto">
            {filters.map((filter) => (
              <Button
                key={filter}
                variant={selectedFilter === filter ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedFilter(filter)}
                className={`whitespace-nowrap ${
                  selectedFilter === filter ? 'bg-primary text-white' : 'bg-white border-gray-200 text-gray-600'
                }`}
              >
                {filter}
              </Button>
            ))}
          </div>
        </div>
      )}

      {isScriptActive && (
        <>
          <div className="px-4 mb-4">
            <h3 className="text-lg font-bold text-gray-800 mb-2">🔥 All Products</h3>
          </div>
          <div className="px-4 grid grid-cols-2 gap-4">
            {isLoadingProducts ? (
              [...Array(6)].map((_, i) => (
                <Card key={i} className="overflow-hidden">
                  <div className="w-full h-48 bg-gray-200 animate-pulse"></div>
                  <CardContent className="p-3">
                    <div className="h-4 bg-gray-200 rounded mb-1 animate-pulse"></div>
                    <div className="h-5 bg-gray-200 rounded w-1/2 animate-pulse"></div>
                  </CardContent>
                </Card>
              ))
            ) : (
              scriptProducts.slice(0, 40).map((product: Product, index: number) => (
                <Card 
                  key={product._id || index} 
                  className="cursor-pointer hover:shadow-md transition-shadow overflow-hidden"
                  onClick={() => handleProductClick(product)}
                  data-testid={`product-card-${product._id || index}`}
                >
                  <CardContent className="p-0">
                    <div className="relative bg-gray-50 p-2">
                      <img 
                        src={product.imageUrl || product.imageUrl2 || "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&h=300&fit=crop"} 
                        alt={product.title}
                        className="w-full h-44 object-contain"
                        onError={(e) => {
                          e.currentTarget.src = "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&h=300&fit=crop";
                        }}
                      />
                      <div className="absolute top-1 right-1 bg-red-600 text-white text-[10px] px-1.5 py-0.5 rounded flex items-center gap-1">
                        <span>⏰</span>
                        <span>{String(offerTimer.minutes).padStart(2, '0')}:{String(offerTimer.seconds).padStart(2, '0')}</span>
                      </div>
                      {product.discount && product.discount > 0 && (
                        <div className="absolute top-1 left-1 bg-red-500 text-white px-2 py-0.5 rounded text-xs font-bold">
                          {product.discount}% OFF
                        </div>
                      )}
                    </div>
                    <div className="p-3">
                      <h4 className="text-sm font-medium text-gray-800 line-clamp-2 mb-2">
                        {product.title}
                      </h4>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-primary font-bold">
                          Rs. {product.price ? parseFloat(product.price).toLocaleString() : 'N/A'}
                        </span>
                        {product.originalPrice && (
                          <span className="text-gray-400 text-xs line-through">
                            Rs. {parseFloat(product.originalPrice).toLocaleString()}
                          </span>
                        )}
                      </div>
                      {product.sold && product.sold > 0 && (
                        <div className="text-gray-500 text-xs mt-1">
                          {product.sold} sold
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </>
      )}
    </div>
  );
}
