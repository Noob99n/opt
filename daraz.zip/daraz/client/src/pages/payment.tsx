import { useLocation } from 'wouter';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Icon } from '@/components/ui/icon';
import { PaymentMethod } from '@/types';

export default function Payment() {
  const [, setLocation] = useLocation();
  const [selectedPayment, setSelectedPayment] = useState<string>('');

  const subtotal = 439;
  const totalAmount = 439;

  const paymentMethods: PaymentMethod[] = [
    {
      id: 'credit-card',
      name: 'Credit/Debit Card',
      description: 'Credit/Debit Card',
      icon: 'credit-card',
      recommended: true,
    },
    {
      id: 'ime-pay',
      name: 'IME Pay',
      description: 'IME Pay Mobile Wallet',
      icon: 'building',
    },
    {
      id: 'esewa',
      name: 'eSewa Mobile Wallet',
      description: 'eSewa Mobile Wallet',
      icon: 'smartphone',
    },
    {
      id: 'cash-on-delivery',
      name: 'Cash on Delivery',
      description: 'Cash on Delivery',
      icon: 'credit-card',
    },
  ];

  const handlePaymentSelect = (paymentId: string) => {
    setSelectedPayment(paymentId);
    // TODO: Implement payment processing
    console.log('Selected payment method:', paymentId);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-white px-4 py-3 shadow-sm flex items-center">
        <button onClick={() => setLocation('/checkout')} className="text-gray-600 mr-3">
          <Icon name="arrow-left" size={20} />
        </button>
        <h1 className="text-lg font-semibold">Select Payment Method</h1>
      </div>

      {/* Payment Notice */}
      <div className="bg-blue-50 px-4 py-3 border-l-4 border-blue-400">
        <div className="flex items-start gap-2">
          <Icon name="info" size={16} className="text-blue-500 mt-1" />
          <div className="text-sm text-blue-700">
            Ensure you have collected the payment voucher to get Bank and Wallet Discounts. 
            0% EMI available on selected bank partners.
          </div>
        </div>
      </div>

      {/* Recommended Payment */}
      <div className="px-4 py-4">
        <h3 className="text-gray-600 font-medium mb-4">Recommended method(s)</h3>
        
        {paymentMethods
          .filter(method => method.recommended)
          .map((method) => (
            <Card key={method.id} className="shadow-card mb-4 cursor-pointer hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Icon name={method.icon as any} size={20} className="text-blue-600" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-800">{method.name}</div>
                      <div className="text-sm text-gray-600">{method.description}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-6 bg-red-600 rounded flex items-center justify-center">
                      <span className="text-white text-xs font-bold">MC</span>
                    </div>
                    <div className="w-8 h-6 bg-blue-600 rounded flex items-center justify-center">
                      <span className="text-white text-xs font-bold">V</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
      </div>

      {/* Other Payment Methods */}
      <div className="px-4">
        <h3 className="text-gray-600 font-medium mb-4">Other Payment Methods</h3>
        
        <div className="space-y-3">
          {paymentMethods
            .filter(method => !method.recommended)
            .map((method) => (
              <Card key={method.id} className="shadow-card cursor-pointer hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                        method.id === 'ime-pay' ? 'bg-gray-100' :
                        method.id === 'esewa' ? 'bg-green-100' :
                        'bg-blue-100'
                      }`}>
                        <Icon 
                          name={method.icon as any} 
                          size={20} 
                          className={
                            method.id === 'ime-pay' ? 'text-gray-600' :
                            method.id === 'esewa' ? 'text-green-600' :
                            'text-blue-600'
                          } 
                        />
                      </div>
                      <div>
                        <div className="font-semibold text-gray-800">{method.name}</div>
                        <div className="text-sm text-gray-600">{method.description}</div>
                      </div>
                    </div>
                    <Icon name="chevron-right" size={16} className="text-gray-400" />
                  </div>
                </CardContent>
              </Card>
            ))}
        </div>
      </div>

      {/* Payment Security */}
      <div className="px-4 py-6">
        <div className="flex items-center justify-center gap-4 opacity-60">
          <Icon name="shield" size={16} className="text-gray-400" />
          <span className="text-xs text-gray-500">Norton</span>
          <Icon name="lock" size={16} className="text-gray-400" />
          <span className="text-xs text-gray-500">PCI</span>
          <span className="text-xs text-gray-500">Verified by VISA</span>
          <span className="text-xs text-gray-500">Mastercard SecureCode</span>
        </div>
      </div>

      {/* Payment Summary */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-3 shadow-lg z-40">
        <div className="max-w-md mx-auto">
          <div className="flex items-center justify-between mb-2">
            <span className="text-gray-600">Subtotal</span>
            <span className="font-semibold text-gray-800">Rs. {subtotal}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="font-bold text-xl text-gray-800">Total Amount</span>
            <span className="text-orange-600 font-bold text-2xl">Rs. {totalAmount}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
