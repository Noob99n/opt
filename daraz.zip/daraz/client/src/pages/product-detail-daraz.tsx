import { useLocation, useParams } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Icon } from '@/components/ui/icon';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useCart } from '@/hooks/use-cart';
import { useTenant } from '@/context/TenantContext';
import { useState, useEffect } from 'react';

export default function ProductDetailDaraz() {
  const [, setLocation] = useLocation();
  const { id } = useParams<{ id: string }>();
  const { addToCart, clearCart } = useCart();
  const { tenant } = useTenant();
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [touchStart, setTouchStart] = useState(0);
  const [touchEnd, setTouchEnd] = useState(0);
  const [activeTab, setActiveTab] = useState('overview');
  const [isScrolled, setIsScrolled] = useState(false);

  const [timeLeft, setTimeLeft] = useState({ hours: 6, minutes: 18, seconds: 38 });

  // Calculate delivery date (7 days from today)
  const getDeliveryDate = () => {
    const today = new Date();
    const deliveryStart = new Date(today);
    const deliveryEnd = new Date(today);
    
    deliveryStart.setDate(today.getDate() + 7); // 7 days from now
    deliveryEnd.setDate(today.getDate() + 10);  // 10 days from now
    
    const formatDate = (date: Date) => {
      return date.toLocaleDateString('en-GB', { 
        day: '2-digit', 
        month: 'short'
      });
    };
    
    return `${formatDate(deliveryStart)} - ${formatDate(deliveryEnd)}`;
  };

  useEffect(() => {
    if (id) {
      let apiUrl: string;
      
      // Check if we're in a tenant store context
      if (tenant.slug) {
        // Use tenant-specific API
        apiUrl = `/api/store/${tenant.slug}/product/${id}`;
      } else {
        // Use standard API (fallback for non-tenant pages)
        const isNumericId = /^\d+$/.test(id);
        apiUrl = isNumericId ? `/api/products/${id}` : `/api/products/slug/${id}`;
      }
      
      fetch(apiUrl)
        .then(res => {
          if (!res.ok) {
            // If tenant API failed and we're not in tenant context, try standard API fallback
            if (!tenant.slug) {
              const isNumericId = /^\d+$/.test(id);
              if (!isNumericId) {
                return fetch(`/api/products/${id}`);
              }
            }
            throw new Error('Product not found');
          }
          return res;
        })
        .then(res => res.json())
        .then(data => {
          setProduct(data);
          setLoading(false);
        })
        .catch(err => {
          console.error('Error:', err);
          setLoading(false);
        });
    }
  }, [id, tenant.slug]);

  // Flash sale timer effect
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        let { hours, minutes, seconds } = prev;
        seconds--;
        if (seconds < 0) {
          seconds = 59;
          minutes--;
          if (minutes < 0) {
            minutes = 59;
            hours--;
            if (hours < 0) {
              hours = 0;
              minutes = 0;
              seconds = 0;
            }
          }
        }
        return { hours, minutes, seconds };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Scroll detection for floating buttons
  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY;
      setIsScrolled(scrollTop > 200);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);


  const handleAddToCart = () => {
    if (product) {
      addToCart({ productId: product.id || product._id, quantity: 1 });
    }
  };

  const handleBuyNow = async () => {
    // For Buy Now, create fresh cart with only current product
    if (product) {
      const productData = product;
      
      // Create cart with only this product (use tenant-specific cart key)
      const cartKey = tenant.slug ? `guest-cart-${tenant.slug}` : 'guest-cart';
      const singleProductCart = [{
        id: Date.now(),
        productId: productData._id || productData.id,
        quantity: 1,
        userId: 'guest',
        product: {
          id: productData._id || productData.id,
          title: productData.title,
          price: productData.price,
          originalPrice: productData.originalPrice,
          imageUrl: productData.imageUrl,
          rating: productData.rating,
          reviewCount: productData.reviewCount,
          discount: productData.discount,
          brand: productData.brand,
        }
      }];
      
      // Save to tenant-specific localStorage key
      localStorage.setItem(cartKey, JSON.stringify(singleProductCart));
    }
    const addressPath = tenant.slug ? `/store/${tenant.slug}/address` : '/address';
    setLocation(addressPath);
  };
  
  const getHomePath = () => tenant.slug ? `/store/${tenant.slug}` : '/';
  const getCartPath = () => tenant.slug ? `/store/${tenant.slug}/cart` : '/cart';

  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <div className="bg-white px-4 py-3 shadow-sm flex items-center justify-between">
          <button onClick={() => setLocation(getHomePath())} className="text-gray-600">
            <Icon name="arrow-left" size={20} />
          </button>
          <div className="flex items-center gap-3">
            <Icon name="shopping-cart" size={20} className="text-gray-600" />
            <Icon name="more-vertical" size={20} className="text-gray-600" />
          </div>
        </div>
        <div className="p-4 space-y-4">
          <div className="w-full h-96 bg-gray-200 rounded-lg animate-pulse"></div>
          <div className="space-y-2">
            <div className="h-6 bg-gray-200 rounded animate-pulse"></div>
            <div className="h-4 bg-gray-200 rounded animate-pulse w-2/3"></div>
            <div className="h-8 bg-gray-200 rounded animate-pulse w-1/2"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Product not found</h2>
          <Button onClick={() => setLocation(getHomePath())} className="btn-orange">
            Go Back
          </Button>
        </div>
      </div>
    );
  }

  const images = [
    product.imageUrl, 
    product.imageUrl2, 
    product.imageUrl3, 
    product.imageUrl4,
    ...(product.images || [])
  ].filter((img, index, self) => img && self.indexOf(img) === index);

  const hasDiscount = product.originalPrice && parseFloat(product.originalPrice) > parseFloat(product.price);
  const discountPercent = hasDiscount ? Math.round(((parseFloat(product.originalPrice) - parseFloat(product.price)) / parseFloat(product.originalPrice)) * 100) : 0;

  // Swipe handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(0); // Reset touch end
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;

    if (isLeftSwipe && images.length > 1) {
      setCurrentImageIndex(prev => prev < images.length - 1 ? prev + 1 : 0);
    }
    if (isRightSwipe && images.length > 1) {
      setCurrentImageIndex(prev => prev > 0 ? prev - 1 : images.length - 1);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Floating Action Buttons - Real Daraz Style */}
      <div className="fixed top-4 left-0 right-0 z-50 flex justify-between items-center px-4">
        <button 
          onClick={() => setLocation(getHomePath())} 
          className={`w-10 h-10 rounded-full flex items-center justify-center shadow-lg transition-all duration-300 ${
            isScrolled 
              ? 'bg-white border border-gray-300 text-gray-700' 
              : 'bg-black/70 text-white'
          }`}
        >
          <Icon name="home" size={18} />
        </button>
        <div className="flex items-center gap-3">
          <button className={`w-10 h-10 rounded-full flex items-center justify-center shadow-lg transition-all duration-300 ${
            isScrolled 
              ? 'bg-white border border-gray-300 text-gray-700' 
              : 'bg-black/70 text-white'
          }`}>
            <Icon name="shopping-cart" size={18} />
          </button>
          <button className={`w-10 h-10 rounded-full flex items-center justify-center shadow-lg transition-all duration-300 ${
            isScrolled 
              ? 'bg-white border border-gray-300 text-gray-700' 
              : 'bg-black/70 text-white'
          }`}>
            <Icon name="more-vertical" size={18} />
          </button>
        </div>
      </div>

      <div className="bg-white">
        {/* Product Image Section with Carousel */}
        <div className="relative bg-white">
          {/* Main Product Image Carousel */}
          <div className="relative">
            <div 
              className="relative overflow-hidden"
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
            >
              <div 
                className="flex transition-transform duration-300 ease-in-out"
                style={{ transform: `translateX(-${currentImageIndex * 100}%)` }}
              >
                {images.map((image, index) => (
                  <div key={index} className="w-full flex-shrink-0">
                    <img 
                      src={image || '/placeholder-product.jpg'}
                      alt={`${product.title} - Image ${index + 1}`}
                      className="w-full h-96 object-contain bg-gray-50"
                    />
                  </div>
                ))}
              </div>
            </div>
            
            {/* Image Counter - Real Daraz Style */}
            {images.length > 1 && (
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black/70 text-white px-2 py-1 rounded-full text-xs font-medium">
                {currentImageIndex + 1}/{images.length}
              </div>
            )}
          </div>
        </div>

        {/* Flash Sale Banner - Exact Daraz Style */}
        <div className="bg-gradient-to-r from-red-500 to-orange-500 px-4 py-2 flex items-center justify-between text-white">
          <div className="flex items-center gap-2">
            <div className="bg-yellow-400 text-red-600 px-2 py-1 rounded text-sm font-bold">
              ⚡ महा बचत
            </div>
            <span className="text-white font-bold text-sm">FLASH SALE</span>
            <span className="text-white text-sm">LIMITED TIME DEAL</span>
          </div>
          <div className="text-right text-white">
            <div className="text-xs">0 sold</div>
          </div>
        </div>

        {/* Price and Title Section - Exact Daraz Layout */}
        <div className="px-4 py-3 bg-white">
          <div className="mb-3">
            <Badge variant="outline" className="text-xs bg-purple-100 text-purple-700 border-purple-200 px-2 py-1">
              DazFlash
            </Badge>
          </div>

          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="text-2xl font-bold text-red-600">
                Rs. {parseFloat(product?.price || '0').toLocaleString()}
              </div>
              {hasDiscount && (
                <>
                  <div className="text-lg text-gray-400 line-through">
                    Rs. {parseFloat(product?.originalPrice || '0').toLocaleString()}
                  </div>
                  <div className="text-sm text-red-600 font-medium">
                    -{discountPercent}%
                  </div>
                </>
              )}
            </div>
            <div className="flex items-center gap-3">
              <button className="text-gray-400 hover:text-red-500">
                <Icon name="heart" size={20} />
              </button>
              <button className="text-gray-400">
                <Icon name="share" size={20} />
              </button>
            </div>
          </div>

          <div className="mb-3 flex items-center gap-2">
            <span className="text-base font-medium text-gray-800">
              {product?.title || 'Product Title'}
            </span>
          </div>

          {/* Rating */}
          <div className="flex items-center gap-2 mb-4">
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Icon 
                  key={i} 
                  name="star" 
                  size={14} 
                  className="text-yellow-400 fill-current" 
                />
              ))}
            </div>
            <span className="text-sm text-gray-600 font-medium">5 (3)</span>
          </div>

          {/* Product Options */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-gray-700 font-medium text-base">Product Options</span>
              <Icon name="chevron-right" size={16} className="text-gray-400" />
            </div>
            <div className="text-sm text-gray-600 mb-3">{product?.description || 'Product Options'}</div>
            <div className="flex gap-3">
              {[1, 2, 3, 4].map((i) => (
                <button
                  key={i}
                  onClick={() => setCurrentImageIndex(i - 1)}
                  className={`w-14 h-14 border-2 rounded overflow-hidden ${
                    currentImageIndex === i - 1 ? 'border-orange-500' : 'border-gray-200'
                  }`}
                >
                  <img 
                    src={images[i - 1] || product?.imageUrl || '/placeholder-product.jpg'} 
                    alt="variant" 
                    className="w-full h-full object-cover" 
                  />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Content Sections - Vertical Scrollable Layout */}
      <div className="bg-white mt-2">
        {/* Overview Section */}
        <div className="p-4 space-y-0">
          {/* Specifications Summary */}
          <div className="py-4 border-b border-gray-100">
            <div className="flex items-center justify-between">
              <span className="text-gray-800 font-medium text-base">Specifications</span>
              <Icon name="chevron-right" size={16} className="text-gray-400" />
            </div>
            <div className="text-sm text-gray-600 mt-1">
              {product?.brand && `${product.brand}, `}
              {product?.specifications?.display && `${product.specifications.display}, `}
              {product?.specifications?.storage && `${product.specifications.storage}, `}
              {product?.specifications?.color || 'Multiple Colors'}
            </div>
          </div>

          {/* Delivery Info - Dynamic Date + Fixed Rs 75 */}
          <div className="py-4 border-b border-gray-100">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-800 font-medium text-base">Delivery</span>
              <Icon name="chevron-right" size={16} className="text-gray-400" />
            </div>
            <div className="text-sm text-orange-600 mb-1">
              {product?.delivery?.location || 'Bagmati, Kathmandu Metro 22 - Newroad Area, Newroad'}
            </div>
            <div className="text-sm text-gray-600">
              Standard Delivery, Guaranteed by {getDeliveryDate()} &nbsp;&nbsp; Rs. 1,000
            </div>
          </div>

          {/* Service */}
          <div className="py-4 border-b border-gray-100">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-800 font-medium text-base">Service</span>
              <Icon name="chevron-right" size={16} className="text-gray-400" />
            </div>
            <div className="space-y-2">
              <div className="text-sm font-medium text-gray-800">14 Days Free Returns</div>
              <div className="text-xs text-gray-500">Change of mind is not applicable</div>
              <div className="text-sm font-medium text-gray-800 mt-3">2 Years Brand Warranty</div>
            </div>
          </div>
        </div>
      </div>

      {/* Ratings Section */}
      <div className="bg-white mt-2">
        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Ratings and Reviews (3)</h3>
            <button className="text-sm text-orange-500">View All</button>
          </div>
          
          {/* Sample Review */}
          <div className="space-y-4">
            <div className="border-b pb-4">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-sm font-medium">bibish S.</span>
                <span className="text-xs text-gray-500">10 Jun 2025</span>
              </div>
              <div className="flex items-center mb-2">
                {[...Array(5)].map((_, i) => (
                  <Icon key={i} name="star" size={14} className="text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-sm text-gray-700 mb-3">
                Got my phone same day of the order(ordered midnight) genuine phone, genuine seller 👍 definitely go for it!!!
              </p>
              <img src="/api/placeholder/80/80" alt="Review" className="w-20 h-20 object-cover rounded" />
              <div className="text-xs text-gray-500 mt-2">
                Color Family:Natural, RAM Memory:8GB, Storage Capacity:256GB
              </div>
              
              {/* Seller Response */}
              <div className="mt-3 bg-gray-50 p-3 rounded">
                <div className="flex items-center gap-2 mb-1">
                  <Icon name="store" size={16} className="text-orange-500" />
                  <span className="text-sm font-medium text-orange-500">Seller Response</span>
                  <span className="text-xs text-gray-500">1 month ago</span>
                </div>
                <p className="text-sm text-gray-600">Thank you for your feedback! 😊</p>
              </div>
            </div>
          </div>

          {/* Questions Section */}
          <div className="mt-6">
            <h3 className="font-semibold mb-4">Questions about this product (0)</h3>
            <div className="text-center py-8 text-gray-500">
              <div className="text-sm">There are no questions yet.</div>
              <div className="text-sm">ask the seller now and their answer will show here.</div>
            </div>
            <Button className="w-full bg-white border border-orange-500 text-orange-500 hover:bg-orange-50 mt-4">
              ASK QUESTIONS
            </Button>
          </div>
        </div>
      </div>

      {/* Recommendations Section */}
      <div className="bg-white mt-2">
        <div className="p-4">
          {/* Disclaimer */}
          <div className="bg-yellow-50 border border-yellow-200 p-3 rounded mb-4">
            <h4 className="font-medium text-sm mb-2">Disclaimer</h4>
            <p className="text-xs text-gray-600 leading-relaxed">
              The images provided here is only for reference purpose. Actual product packaging 
              and materials may contain more and different information than what is shown on 
              our website. We recommend that you do not rely solely on the information 
              presented here and that you always read labels, warnings, and directions before 
              using or consuming a product.
            </p>
          </div>

          {/* Highlights - Real Product Data */}
          <div className="mb-6">
            <h3 className="font-semibold mb-4">Highlights</h3>
            <div className="space-y-3">
              {/* Show real highlights if available */}
              {product?.highlights && product.highlights.length > 0 ? (
                product.highlights.map((highlight: string, idx: number) => (
                  <div key={idx} className="flex gap-3">
                    <div className="text-sm text-orange-500">•</div>
                    <div className="text-sm text-gray-700">{highlight}</div>
                  </div>
                ))
              ) : (
                <>
                  {/* Fallback: Generate highlights from specifications */}
                  {product?.specifications?.display && (
                    <div className="flex gap-3">
                      <div className="text-sm text-orange-500">•</div>
                      <div className="text-sm text-gray-700">{product.specifications.display} {product.specifications.size && `(${product.specifications.size})`}</div>
                    </div>
                  )}
                  {product?.specifications?.chip && (
                    <div className="flex gap-3">
                      <div className="text-sm text-orange-500">•</div>
                      <div className="text-sm text-gray-700">{product.specifications.chip} Chip</div>
                    </div>
                  )}
                  {product?.specifications?.camera && (
                    <div className="flex gap-3">
                      <div className="text-sm text-orange-500">•</div>
                      <div className="text-sm text-gray-700">{product.specifications.camera} Camera System</div>
                    </div>
                  )}
                  {product?.specifications?.storage && (
                    <div className="flex gap-3">
                      <div className="text-sm text-orange-500">•</div>
                      <div className="text-sm text-gray-700">{product.specifications.storage} Storage</div>
                    </div>
                  )}
                  {product?.specifications?.ram && (
                    <div className="flex gap-3">
                      <div className="text-sm text-orange-500">•</div>
                      <div className="text-sm text-gray-700">{product.specifications.ram} RAM</div>
                    </div>
                  )}
                  {product?.specifications?.waterResistance && (
                    <div className="flex gap-3">
                      <div className="text-sm text-orange-500">•</div>
                      <div className="text-sm text-gray-700">{product.specifications.waterResistance} Water Resistance</div>
                    </div>
                  )}
                  {product?.brand && (
                    <div className="flex gap-3">
                      <div className="text-sm text-orange-500">•</div>
                      <div className="text-sm text-gray-700">Brand: {product.brand}</div>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Details Section */}
      <div className="bg-white mt-2">
        <div className="p-4 space-y-6">
          {/* Product Details - Real Data */}
          <div>
            <h3 className="font-semibold mb-4">Product Details</h3>
            <div className="space-y-3">
              {product?.brand && (
                <div className="flex gap-3">
                  <div className="text-sm text-orange-500">•</div>
                  <div className="text-sm text-gray-700">Brand: {product.brand}</div>
                </div>
              )}
              {product?.model && (
                <div className="flex gap-3">
                  <div className="text-sm text-orange-500">•</div>
                  <div className="text-sm text-gray-700">Model: {product.model}</div>
                </div>
              )}
              {product?.specifications?.operatingSystem && (
                <div className="flex gap-3">
                  <div className="text-sm text-orange-500">•</div>
                  <div className="text-sm text-gray-700">Operating System: {product.specifications.operatingSystem}</div>
                </div>
              )}
              {product?.specifications?.storage && (
                <div className="flex gap-3">
                  <div className="text-sm text-orange-500">•</div>
                  <div className="text-sm text-gray-700">Internal Storage: {product.specifications.storage}</div>
                </div>
              )}
              {product?.specifications?.ram && (
                <div className="flex gap-3">
                  <div className="text-sm text-orange-500">•</div>
                  <div className="text-sm text-gray-700">RAM: {product.specifications.ram}</div>
                </div>
              )}
              {product?.specifications?.color && (
                <div className="flex gap-3">
                  <div className="text-sm text-orange-500">•</div>
                  <div className="text-sm text-gray-700">Color: {product.specifications.color}</div>
                </div>
              )}
              {product?.description && (
                <div className="flex gap-3">
                  <div className="text-sm text-orange-500">•</div>
                  <div className="text-sm text-gray-700">{product.description}</div>
                </div>
              )}
            </div>
          </div>

          {/* Product Description Images */}
          <div className="mt-6">
            <h3 className="font-semibold mb-4">Product Images</h3>
            <div className="space-y-4">
              {/* Display all product images in description section */}
              {images.map((image, index) => (
                <div key={index} className="w-full">
                  <img 
                    src={image || '/placeholder-product.jpg'} 
                    alt={`${product.title} - Detailed View ${index + 1}`}
                    className="w-full object-contain bg-gray-50 rounded-lg border border-gray-200"
                    style={{ minHeight: '400px', maxHeight: '600px' }}
                  />
                </div>
              ))}
            </div>
            
            {/* Product Description Content */}
            <div className="mt-6">
              <h3 className="font-semibold mb-4">Description</h3>
              <div className="prose max-w-none text-sm text-gray-700 leading-relaxed">
                {product.descriptionContent ? (
                  <div>
                    <p className="mb-4">{product.descriptionContent}</p>
                  </div>
                ) : (
                  <div>
                    <p className="mb-4">{product.description || 'Product description not available.'}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {/* Technical Specifications - iPhone Style */}
          <div className="mt-6">
            <h3 className="font-semibold mb-4">Complete Specifications</h3>
            <div className="bg-gray-50 rounded-lg p-4 space-y-0">
              {/* Display Section */}
              {(product?.specifications?.display || product?.specifications?.size || product?.specifications?.resolution) && (
                <div className="border-b border-gray-200 py-3">
                  <h4 className="text-sm font-semibold text-gray-800 mb-2">Display</h4>
                  {product.specifications.display && (
                    <div className="flex justify-between py-1">
                      <span className="text-xs text-gray-500">Type</span>
                      <span className="text-xs text-gray-700">{product.specifications.display}</span>
                    </div>
                  )}
                  {product.specifications.size && (
                    <div className="flex justify-between py-1">
                      <span className="text-xs text-gray-500">Size</span>
                      <span className="text-xs text-gray-700">{product.specifications.size}</span>
                    </div>
                  )}
                  {product.specifications.resolution && (
                    <div className="flex justify-between py-1">
                      <span className="text-xs text-gray-500">Resolution</span>
                      <span className="text-xs text-gray-700">{product.specifications.resolution}</span>
                    </div>
                  )}
                </div>
              )}
              
              {/* Chip/Processor Section */}
              {(product?.specifications?.chip || product?.specifications?.cpu || product?.specifications?.gpu) && (
                <div className="border-b border-gray-200 py-3">
                  <h4 className="text-sm font-semibold text-gray-800 mb-2">Processor</h4>
                  {product.specifications.chip && (
                    <div className="flex justify-between py-1">
                      <span className="text-xs text-gray-500">Chip</span>
                      <span className="text-xs text-gray-700">{product.specifications.chip}</span>
                    </div>
                  )}
                  {product.specifications.cpu && (
                    <div className="flex justify-between py-1">
                      <span className="text-xs text-gray-500">CPU</span>
                      <span className="text-xs text-gray-700">{product.specifications.cpu}</span>
                    </div>
                  )}
                  {product.specifications.gpu && (
                    <div className="flex justify-between py-1">
                      <span className="text-xs text-gray-500">GPU</span>
                      <span className="text-xs text-gray-700">{product.specifications.gpu}</span>
                    </div>
                  )}
                  {product.specifications.neuralEngine && (
                    <div className="flex justify-between py-1">
                      <span className="text-xs text-gray-500">Neural Engine</span>
                      <span className="text-xs text-gray-700">{product.specifications.neuralEngine}</span>
                    </div>
                  )}
                </div>
              )}
              
              {/* Camera Section */}
              {product?.specifications?.camera && (
                <div className="border-b border-gray-200 py-3">
                  <h4 className="text-sm font-semibold text-gray-800 mb-2">Camera</h4>
                  <div className="flex justify-between py-1">
                    <span className="text-xs text-gray-500">Camera System</span>
                    <span className="text-xs text-gray-700">{product.specifications.camera}</span>
                  </div>
                </div>
              )}
              
              {/* Storage & Memory */}
              {(product?.specifications?.storage || product?.specifications?.ram) && (
                <div className="border-b border-gray-200 py-3">
                  <h4 className="text-sm font-semibold text-gray-800 mb-2">Storage & Memory</h4>
                  {product.specifications.storage && (
                    <div className="flex justify-between py-1">
                      <span className="text-xs text-gray-500">Internal Storage</span>
                      <span className="text-xs text-gray-700">{product.specifications.storage}</span>
                    </div>
                  )}
                  {product.specifications.ram && (
                    <div className="flex justify-between py-1">
                      <span className="text-xs text-gray-500">RAM</span>
                      <span className="text-xs text-gray-700">{product.specifications.ram}</span>
                    </div>
                  )}
                </div>
              )}
              
              {/* Other Specs */}
              <div className="py-3">
                <h4 className="text-sm font-semibold text-gray-800 mb-2">Other Features</h4>
                {product?.specifications?.color && (
                  <div className="flex justify-between py-1">
                    <span className="text-xs text-gray-500">Color</span>
                    <span className="text-xs text-gray-700">{product.specifications.color}</span>
                  </div>
                )}
                {product?.specifications?.waterResistance && (
                  <div className="flex justify-between py-1">
                    <span className="text-xs text-gray-500">Water Resistance</span>
                    <span className="text-xs text-gray-700">{product.specifications.waterResistance}</span>
                  </div>
                )}
                {product?.specifications?.operatingSystem && (
                  <div className="flex justify-between py-1">
                    <span className="text-xs text-gray-500">Operating System</span>
                    <span className="text-xs text-gray-700">{product.specifications.operatingSystem}</span>
                  </div>
                )}
                {product?.brand && (
                  <div className="flex justify-between py-1">
                    <span className="text-xs text-gray-500">Brand</span>
                    <span className="text-xs text-gray-700">{product.brand}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* You may also like section */}
      <div className="bg-white mt-2 p-4">
        <div className="text-center mb-4">
          <div className="text-orange-500 font-bold text-lg">⚡⚡⚡ You may also like ⚡⚡⚡</div>
        </div>
      </div>

      {/* Sticky Bottom Bar - Image Based */}
      <div className="fixed bottom-0 left-0 right-0 z-50" onClick={handleBuyNow}>
        <img 
          src="https://res.cloudinary.com/djbiyudvw/image/upload/v1752928473/Screenshot_2025_0719_180343_my5zqo.png" 
          alt="Buy Now"
          className="w-full h-auto cursor-pointer"
          data-testid="button-buy-now"
        />
      </div>
      
      {/* Bottom padding to prevent content from being hidden behind sticky bar */}
      <div className="h-20"></div>
    </div>
  );
}