import { useLocation } from 'wouter';
import { useState } from 'react';
import { ChevronLeft, Camera } from 'lucide-react';

export default function Address() {
  const [location, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    recipientName: '',
    phoneNumber: '',
    region: '',
    address: '',
    landmark: '',
    addressCategory: 'Home'
  });
  const [errors, setErrors] = useState<{[key: string]: string}>({});
  
  // Detect tenant slug from URL for tenant-aware navigation
  const getTenantSlug = (): string | null => {
    const match = location.match(/^\/store\/([^/]+)/);
    return match ? match[1] : null;
  };
  
  const tenantSlug = getTenantSlug();
  
  // Helper to get tenant-aware path
  const getPath = (path: string) => tenantSlug ? `/store/${tenantSlug}${path}` : path;

  const validateForm = () => {
    const newErrors: {[key: string]: string} = {};
    
    if (!formData.recipientName.trim()) {
      newErrors.recipientName = 'Recipient name is required';
    }
    
    if (!formData.phoneNumber.trim()) {
      newErrors.phoneNumber = 'Phone number is required';
    } else if (formData.phoneNumber.length < 10) {
      newErrors.phoneNumber = 'Please enter a valid phone number';
    }
    
    if (!formData.region.trim()) {
      newErrors.region = 'Region/City/District is required';
    }
    
    if (!formData.address.trim()) {
      newErrors.address = 'Address is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSaveAddress = () => {
    if (!validateForm()) {
      return;
    }
    // Save address to localStorage (tenant-aware)
    const addressKey = tenantSlug ? `delivery-address-${tenantSlug}` : 'delivery-address';
    localStorage.setItem(addressKey, JSON.stringify(formData));
    console.log('Saving address:', formData);
    // Use tenant-aware checkout path
    setLocation(getPath('/checkout'));
  };

  return (
    <div className="min-h-screen bg-white pb-24">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-4 flex items-center sticky top-0 z-50">
        <button 
          onClick={() => setLocation(getPath('/'))} 
          className="mr-3"
          data-testid="button-back"
        >
          <ChevronLeft size={24} className="text-gray-800" />
        </button>
        <h1 className="text-lg font-semibold text-gray-900">Add Shipping Address</h1>
      </div>

      {/* Form */}
      <div className="px-4 py-6">
        {/* Recipient's Name */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Recipient's Name <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <input
              type="text"
              placeholder="Input the real name"
              value={formData.recipientName}
              onChange={(e) => {
                setFormData(prev => ({ ...prev, recipientName: e.target.value }));
                if (errors.recipientName) setErrors(prev => ({ ...prev, recipientName: '' }));
              }}
              className={`w-full px-4 py-3 border rounded-lg focus:outline-none text-gray-900 ${errors.recipientName ? 'border-red-500' : 'border-gray-300 focus:border-gray-400'}`}
              data-testid="input-recipient-name"
            />
            <button className="absolute right-3 top-1/2 -translate-y-1/2">
              <Camera size={20} className="text-gray-400" />
            </button>
          </div>
          {errors.recipientName && <p className="text-red-500 text-xs mt-1">{errors.recipientName}</p>}
        </div>

        {/* Phone Number */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Phone Number <span className="text-red-500">*</span>
          </label>
          <input
            type="tel"
            placeholder="Please input Phone Number"
            value={formData.phoneNumber}
            onChange={(e) => {
              setFormData(prev => ({ ...prev, phoneNumber: e.target.value }));
              if (errors.phoneNumber) setErrors(prev => ({ ...prev, phoneNumber: '' }));
            }}
            className={`w-full px-4 py-3 border rounded-lg focus:outline-none text-gray-900 ${errors.phoneNumber ? 'border-red-500' : 'border-gray-300 focus:border-gray-400'}`}
            data-testid="input-phone-number"
          />
          {errors.phoneNumber && <p className="text-red-500 text-xs mt-1">{errors.phoneNumber}</p>}
        </div>

        {/* Region/City/District */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Region/City/District <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            placeholder="Please input Region/City/District"
            value={formData.region}
            onChange={(e) => {
              setFormData(prev => ({ ...prev, region: e.target.value }));
              if (errors.region) setErrors(prev => ({ ...prev, region: '' }));
            }}
            className={`w-full px-4 py-3 border rounded-lg focus:outline-none text-gray-900 ${errors.region ? 'border-red-500' : 'border-gray-300 focus:border-gray-400'}`}
            data-testid="input-region"
          />
          {errors.region && <p className="text-red-500 text-xs mt-1">{errors.region}</p>}
        </div>

        {/* Address */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Address <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            placeholder="House no./building/street/area"
            value={formData.address}
            onChange={(e) => {
              setFormData(prev => ({ ...prev, address: e.target.value }));
              if (errors.address) setErrors(prev => ({ ...prev, address: '' }));
            }}
            className={`w-full px-4 py-3 border rounded-lg focus:outline-none text-gray-900 ${errors.address ? 'border-red-500' : 'border-gray-300 focus:border-gray-400'}`}
            data-testid="input-address"
          />
          {errors.address && <p className="text-red-500 text-xs mt-1">{errors.address}</p>}
        </div>

        {/* Landmark */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Landmark(Optional)
          </label>
          <input
            type="text"
            placeholder="Add Additional Info"
            value={formData.landmark}
            onChange={(e) => setFormData(prev => ({ ...prev, landmark: e.target.value }))}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-gray-400 text-gray-900"
            data-testid="input-landmark"
          />
        </div>

        {/* Address Category */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-900 mb-3">
            Address Category
          </label>
          <div className="flex gap-4">
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="addressCategory"
                value="Home"
                checked={formData.addressCategory === 'Home'}
                onChange={(e) => setFormData(prev => ({ ...prev, addressCategory: e.target.value }))}
                className="w-5 h-5 text-blue-600 border-gray-300 focus:ring-blue-500"
                data-testid="radio-home"
              />
              <span className="ml-2 text-gray-900">Home</span>
            </label>
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="addressCategory"
                value="Office"
                checked={formData.addressCategory === 'Office'}
                onChange={(e) => setFormData(prev => ({ ...prev, addressCategory: e.target.value }))}
                className="w-5 h-5 text-blue-600 border-gray-300 focus:ring-blue-500"
                data-testid="radio-office"
              />
              <span className="ml-2 text-gray-900">Office</span>
            </label>
          </div>
        </div>
      </div>

      {/* Save Button - Fixed at bottom */}
      <div className="fixed bottom-0 left-0 right-0 bg-white px-4 py-3 border-t border-gray-200">
        <button
          onClick={handleSaveAddress}
          className="w-full bg-orange-600 hover:bg-orange-700 text-white py-4 rounded-lg font-medium text-base"
          data-testid="button-save"
        >
          Save
        </button>
      </div>
    </div>
  );
}
