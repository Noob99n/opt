import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { Check, Package, Truck, MapPin, Clock, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTenant } from '@/context/TenantContext';

export default function OrderSuccess() {
  const [, setLocation] = useLocation();
  const [countdown, setCountdown] = useState(5);
  const { getRoutePath } = useTenant();
  
  const orderData = JSON.parse(sessionStorage.getItem('lastOrder') || '{}');
  const orderId = orderData.orderId || `ORD${Date.now().toString().slice(-8)}`;
  const productTitle = orderData.productTitle || 'Your Product';
  const amount = orderData.amount || 0;
  const quantity = orderData.quantity || 1;

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleGoToOrders = () => {
    setLocation(getRoutePath('/my-orders'));
  };

  const handleContinueShopping = () => {
    setLocation(getRoutePath('/'));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-green-500 to-green-600 text-white py-8">
        <div className="max-w-lg mx-auto px-4 text-center">
          <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Check className="w-10 h-10 text-green-500" strokeWidth={3} />
          </div>
          <h1 className="text-2xl font-bold mb-2">Order Placed Successfully!</h1>
          <p className="text-green-100">Thank you for your order</p>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 -mt-4">
        <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-4">
          <div className="p-4 border-b border-gray-100">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-500">Order ID</span>
              <span className="font-mono font-semibold text-orange-600">{orderId}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-500">Placed On</span>
              <span className="text-sm font-medium">{new Date().toLocaleDateString('en-IN', { 
                day: 'numeric', 
                month: 'short', 
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}</span>
            </div>
          </div>

          <div className="p-4 border-b border-gray-100">
            <div className="flex gap-3">
              <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center">
                <Package className="w-8 h-8 text-gray-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-gray-900 line-clamp-2">{productTitle}</p>
                <p className="text-sm text-gray-500">Qty: {quantity}</p>
                <p className="font-bold text-orange-600 mt-1">Rs. {amount.toLocaleString()}</p>
              </div>
            </div>
          </div>

          <div className="p-4">
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <Truck className="w-4 h-4 text-green-600" />
              Delivery Status
            </h3>
            <div className="relative">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                  <Check className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-green-700">Order Confirmed</p>
                  <p className="text-xs text-gray-500">{new Date().toLocaleString('en-IN')}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center">
                  <Clock className="w-4 h-4 text-orange-500" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-700">Processing</p>
                  <p className="text-xs text-gray-500">Your order is being prepared</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 mb-4 opacity-50">
                <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                  <Truck className="w-4 h-4 text-gray-400" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-500">Shipped</p>
                  <p className="text-xs text-gray-400">Pending</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 opacity-50">
                <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                  <MapPin className="w-4 h-4 text-gray-400" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-500">Delivered</p>
                  <p className="text-xs text-gray-400">Expected in 13-15 days</p>
                </div>
              </div>

              <div className="absolute left-4 top-8 bottom-8 w-0.5 bg-gray-200" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-4 mb-4">
          <p className="text-center text-sm text-gray-500 mb-4">
            Redirecting to My Orders in <span className="font-bold text-orange-600">{countdown}</span> seconds...
          </p>
          
          <Button
            onClick={handleGoToOrders}
            className="w-full bg-orange-500 hover:bg-orange-600 text-white mb-3"
            data-testid="button-go-to-orders"
          >
            Go to My Orders
            <ChevronRight className="w-4 h-4 ml-2" />
          </Button>
          
          <Button
            onClick={handleContinueShopping}
            variant="outline"
            className="w-full"
            data-testid="button-continue-shopping"
          >
            Continue Shopping
          </Button>
        </div>

        <div className="text-center text-xs text-gray-400 pb-8">
          <p>Need help? Contact our support team</p>
          <p className="mt-1">support@daraz.com | 1800-123-4567</p>
        </div>
      </div>
    </div>
  );
}
