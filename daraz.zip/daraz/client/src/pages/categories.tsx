import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { useState } from 'react';
import { SearchBar } from '@/components/layout/search-bar';
import { ProductCard } from '@/components/product/product-card';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Icon } from '@/components/ui/icon';
import { useCart } from '@/hooks/use-cart';
import { Product } from '@shared/schema';

export default function Categories() {
  const [, setLocation] = useLocation();
  const { addToCart } = useCart();
  const [selectedFilter, setSelectedFilter] = useState('All');

  const { data: products = [], isLoading } = useQuery({
    queryKey: ['/api/products'],
    queryFn: async () => {
      const response = await fetch('/api/products');
      if (!response.ok) throw new Error('Failed to fetch products');
      return response.json() as Promise<Product[]>;
    },
  });

  const handleSearch = (query: string) => {
    if (query.trim()) {
      setLocation(`/search?q=${encodeURIComponent(query)}`);
    }
  };

  const handleProductClick = (product: Product) => {
    setLocation(`/product/${product.id}`);
  };

  const handleAddToCart = (productId: number) => {
    addToCart({ productId, quantity: 1 });
  };

  const categories = [
    { name: 'Breast Pump...', icon: 'dumbbell', color: 'from-blue-100 to-blue-200 text-blue-600' },
    { name: 'Vinegar & Cooking...', icon: 'sparkles', color: 'from-red-100 to-red-200 text-red-600' },
    { name: 'Folk & World...', icon: 'user', color: 'from-purple-100 to-purple-200 text-purple-600' },
    { name: 'Action Cam...', icon: 'smartphone', color: 'from-green-100 to-green-200 text-green-600' },
    { name: 'Kids Bookcase...', icon: 'book', color: 'from-yellow-100 to-yellow-200 text-yellow-600' },
    { name: 'Toilet Paper', icon: 'home', color: 'from-indigo-100 to-indigo-200 text-indigo-600' },
    { name: 'Hoodies & Sweatshirts', icon: 'user', color: 'from-pink-100 to-pink-200 text-pink-600' },
    { name: 'Habitat Access', icon: 'home', color: 'from-gray-100 to-gray-200 text-gray-600' },
  ];

  const filters = ['All', 'Voucher', 'Daraz', 'Buy Any 3', 'Free'];

  return (
    <div className="min-h-screen pb-20 flex items-center justify-center" style={{ backgroundColor: '#f1f3f6' }}>
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Categories</h2>
        <p className="text-gray-600 mb-6">All categories are now available on the homepage</p>
        <Button
          onClick={() => setLocation('/')}
          className="bg-primary text-white"
        >
          Go to Homepage
        </Button>
      </div>
    </div>
  );
}
