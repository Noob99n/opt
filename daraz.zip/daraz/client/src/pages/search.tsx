import { useQuery } from '@tanstack/react-query';
import { useLocation, useSearch } from 'wouter';
import { SearchBar } from '@/components/layout/search-bar';
import { ProductCard } from '@/components/product/product-card';
import { Button } from '@/components/ui/button';
import { Icon } from '@/components/ui/icon';
import { useCart } from '@/hooks/use-cart';
import { Product } from '@shared/schema';

export default function Search() {
  const [, setLocation] = useLocation();
  const searchParams = new URLSearchParams(useSearch());
  const query = searchParams.get('q') || '';
  const { addToCart } = useCart();

  const { data: searchResults = [], isLoading } = useQuery({
    queryKey: ['/api/products/search', query],
    queryFn: async () => {
      if (!query.trim()) return [];
      const response = await fetch(`/api/products/search/${encodeURIComponent(query)}`);
      if (!response.ok) throw new Error('Failed to search products');
      return response.json() as Promise<Product[]>;
    },
    enabled: !!query.trim(),
  });

  const handleSearch = (newQuery: string) => {
    if (newQuery.trim()) {
      setLocation(`/search?q=${encodeURIComponent(newQuery)}`);
    }
  };

  const handleProductClick = (product: Product) => {
    setLocation(`/product/${product.id}`);
  };

  const handleAddToCart = (productId: number) => {
    addToCart({ productId, quantity: 1 });
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-white px-4 py-3 shadow-sm flex items-center gap-3">
        <button onClick={() => setLocation('/')} className="text-gray-600">
          <Icon name="arrow-left" size={20} />
        </button>
        <div className="flex-1">
          <SearchBar 
            placeholder={query || "Search products..."} 
            onSearch={handleSearch}
            className="shadow-none px-0 py-0"
          />
        </div>
      </div>

      <div className="px-4 py-4">
        {query && (
          <div className="mb-4">
            <h2 className="text-lg font-semibold text-gray-800">
              Search results for "{query}"
            </h2>
            <p className="text-sm text-gray-600">
              {searchResults.length} products found
            </p>
          </div>
        )}

        {isLoading ? (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="bg-white rounded-lg shadow-card p-4">
                <div className="flex gap-3">
                  <div className="w-20 h-20 bg-gray-200 rounded-lg skeleton"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-200 rounded skeleton"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2 skeleton"></div>
                    <div className="h-5 bg-gray-200 rounded w-1/3 skeleton"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : query && searchResults.length === 0 ? (
          <div className="text-center py-12">
            <Icon name="search" size={64} className="text-gray-400 mb-4 mx-auto" />
            <h3 className="text-xl font-semibold text-gray-800 mb-2">No results found</h3>
            <p className="text-gray-600 mb-4">
              We couldn't find any products matching "{query}"
            </p>
            <Button onClick={() => setLocation('/')} className="btn-orange">
              Browse All Products
            </Button>
          </div>
        ) : query ? (
          <div className="space-y-3">
            {searchResults.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                variant="list"
                onProductClick={handleProductClick}
                onAddToCart={handleAddToCart}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Icon name="search" size={64} className="text-gray-400 mb-4 mx-auto" />
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Search Products</h3>
            <p className="text-gray-600">
              Enter a search term to find products
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
