import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { useState, useEffect } from 'react';
import { SearchBar } from '@/components/layout/search-bar';
import { FlashSaleBanner } from '@/components/product/flash-sale-banner';
import { ProductCard } from '@/components/product/product-card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Icon } from '@/components/ui/icon';
import { Card, CardContent } from '@/components/ui/card';
import { getProxiedImageUrl } from '@/lib/image-proxy';
import { useCart } from '@/hooks/use-cart';
// Interface for product data
interface Product {
  id: number;
  title: string;
  price: string;
  originalPrice?: string;
  imageUrl?: string;
  imageUrls?: string[];
  discount?: number;
  isFlashDeal?: boolean;
  slug?: string;
}
import categoryGrid from '@assets/image_1751707197982.png';

export default function Home() {
  const [, setLocation] = useLocation();
  const { addToCart } = useCart();
  const [selectedFilter, setSelectedFilter] = useState('All');
  
  // 10 minute countdown timer - resets on every page load
  const [offerTimer, setOfferTimer] = useState({ minutes: 10, seconds: 0 });
  
  useEffect(() => {
    const timer = setInterval(() => {
      setOfferTimer(prev => {
        let { minutes, seconds } = prev;
        if (seconds === 0) {
          if (minutes === 0) {
            // Reset to 10 minutes when timer ends
            return { minutes: 10, seconds: 0 };
          }
          minutes--;
          seconds = 59;
        } else {
          seconds--;
        }
        return { minutes, seconds };
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);

  // Hard-coded flash sale products for immediate display
  const flashSaleProducts = [
    {
      id: 52,
      title: "Atowak Cobra Luxury Watch - Premium Edition",
      description: "Luxury mechanical watch with automatic movement and sapphire crystal",
      price: "2500.00",
      originalPrice: "4500.00",
      category: "Watches",
      imageUrl: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&h=300&fit=crop",
      rating: "4.9",
      reviewCount: 537,
      isFlashSale: true,
      discount: 44,
      stock: 63,
      sold: 125,
      brand: "Premium"
    },
    {
      id: 53,
      title: "Rolex Submariner Style Watch",
      description: "Professional diving watch with automatic movement",
      price: "3200.00",
      originalPrice: "5800.00",
      category: "Watches",
      imageUrl: "https://images.unsplash.com/photo-1548181048-2aa69ef3ddb0?w=300&h=300&fit=crop",
      rating: "4.7",
      reviewCount: 547,
      isFlashSale: true,
      discount: 45,
      stock: 48,
      sold: 89,
      brand: "Premium"
    },
    {
      id: 54,
      title: "TAG Heuer Formula 1 Inspired",
      description: "Sport chronograph watch with precision timing",
      price: "2800.00",
      originalPrice: "5200.00",
      category: "Watches",
      imageUrl: "https://images.unsplash.com/photo-1594576662903-79f4df9b0f0e?w=300&h=300&fit=crop",
      rating: "4.4",
      reviewCount: 274,
      isFlashSale: true,
      discount: 46,
      stock: 57,
      sold: 67,
      brand: "Premium"
    },
    {
      id: 55,
      title: "Omega Speedmaster Professional",
      description: "Moonwatch replica with chronograph function",
      price: "3500.00",
      originalPrice: "6200.00",
      category: "Watches",
      imageUrl: "https://images.unsplash.com/photo-1509048191080-d2425f1f4157?w=300&h=300&fit=crop",
      rating: "4.4",
      reviewCount: 215,
      isFlashSale: true,
      discount: 43,
      stock: 24,
      sold: 94,
      brand: "Premium"
    },
    {
      id: 56,
      title: "Breitling Navitimer Style",
      description: "Aviation watch with slide rule bezel",
      price: "2900.00",
      originalPrice: "5100.00",
      category: "Watches",
      imageUrl: "https://images.unsplash.com/photo-1533139502658-0198f920d8e8?w=300&h=300&fit=crop",
      rating: "4.6",
      reviewCount: 264,
      isFlashSale: true,
      discount: 43,
      stock: 28,
      sold: 78,
      brand: "Premium"
    },
    {
      id: 57,
      title: "Casio G-Shock Premium Edition",
      description: "Shock-resistant digital watch with multiple functions",
      price: "1800.00",
      originalPrice: "3200.00",
      category: "Watches",
      imageUrl: "https://images.unsplash.com/photo-1606800052052-a08af7148866?w=300&h=300&fit=crop",
      rating: "4.7",
      reviewCount: 155,
      isFlashSale: true,
      discount: 44,
      stock: 52,
      sold: 156,
      brand: "Premium"
    }
  ];
  
  const isFlashLoading = false;

  const { data: settings = { script: 'none' } } = useQuery({
    queryKey: ['/api/settings'],
    queryFn: async () => {
      const response = await fetch('/api/settings');
      if (!response.ok) throw new Error('Failed to fetch settings');
      return response.json() as Promise<{ script: string }>;
    },
  });

  // Fetch all products (from owner's active script or shared catalog)
  const { data: scriptProducts = [], isLoading: scriptLoading } = useQuery({
    queryKey: ['/api/products'],
    queryFn: async () => {
      const response = await fetch('/api/products');
      if (!response.ok) throw new Error('Failed to fetch products');
      return response.json();
    }
  });



  const handleSearch = (query: string) => {
    if (query.trim()) {
      setLocation(`/search?q=${encodeURIComponent(query)}`);
    }
  };

  const handleProductClick = (product: Product) => {
    setLocation(`/product/${product.slug || product.id}`);
  };

  const handleAddToCart = (productId: number) => {
    addToCart({ productId, quantity: 1 });
  };

  const categories = [
    { name: 'Breast Pump...', icon: 'dumbbell', color: 'from-blue-100 to-blue-200 text-blue-600' },
    { name: 'Vinegar & Cooking...', icon: 'sparkles', color: 'from-red-100 to-red-200 text-red-600' },
    { name: 'Folk & World...', icon: 'user', color: 'from-purple-100 to-purple-200 text-purple-600' },
    { name: 'Action Cam...', icon: 'smartphone', color: 'from-green-100 to-green-200 text-green-600' },
    { name: 'Kids Bookcase...', icon: 'book', color: 'from-yellow-100 to-yellow-200 text-yellow-600' },
    { name: 'Toilet Paper', icon: 'home', color: 'from-indigo-100 to-indigo-200 text-indigo-600' },
    { name: 'Hoodies & Sweatshirts', icon: 'user', color: 'from-pink-100 to-pink-200 text-pink-600' },
    { name: 'Habitat Access', icon: 'home', color: 'from-gray-100 to-gray-200 text-gray-600' },
  ];

  const filters = ['All', 'Voucher', 'Daraz', 'Buy Any 3', 'Free'];

  // Check if script is actually active - temporary fix to always show when products available
  const isScriptActive = settings.script !== 'none' || scriptProducts.length > 0;

  return (
    <div className="min-h-screen pb-20" style={{ backgroundColor: '#f1f3f6' }}>
      <SearchBar onSearch={handleSearch} />

      {/* FLASH SALE SECTION - DIRECTLY AFTER SEARCH BAR */}
      <div className="px-4 mb-6">
        <div className="bg-gradient-to-r from-red-500 to-orange-500 text-white p-4 rounded-lg mb-4">
          <h2 className="text-xl font-bold">⌚ 프리미엄 시계 플래시 세일</h2>
          <p className="text-sm opacity-90">최대 72% 할인 - 한정 시간!</p>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-lg border shadow-sm p-3">
            <img src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&h=300&fit=crop" 
                 className="w-full h-24 object-cover rounded mb-2" 
                 alt="Atowak Watch" />
            <h4 className="text-sm font-bold text-gray-800">Atowak Cobra Luxury</h4>
            <div className="flex items-center gap-1 mt-1">
              <span className="text-red-600 font-bold text-lg">Rs. 2,500</span>
              <span className="text-gray-400 line-through text-xs">Rs. 4,500</span>
            </div>
            <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">44% OFF</span>
          </div>
          <div className="bg-white rounded-lg border shadow-sm p-3">
            <img src="https://images.unsplash.com/photo-1548181048-2aa69ef3ddb0?w=300&h=300&fit=crop" 
                 className="w-full h-24 object-cover rounded mb-2" 
                 alt="Rolex Watch" />
            <h4 className="text-sm font-bold text-gray-800">Rolex Submariner Style</h4>
            <div className="flex items-center gap-1 mt-1">
              <span className="text-red-600 font-bold text-lg">Rs. 3,200</span>
              <span className="text-gray-400 line-through text-xs">Rs. 5,800</span>
            </div>
            <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">45% OFF</span>
          </div>
          <div className="bg-white rounded-lg border shadow-sm p-3">
            <img src="https://images.unsplash.com/photo-1594576662903-79f4df9b0f0e?w=300&h=300&fit=crop" 
                 className="w-full h-24 object-cover rounded mb-2" 
                 alt="TAG Heuer Watch" />
            <h4 className="text-sm font-bold text-gray-800">TAG Heuer Formula 1</h4>
            <div className="flex items-center gap-1 mt-1">
              <span className="text-red-600 font-bold text-lg">Rs. 2,800</span>
              <span className="text-gray-400 line-through text-xs">Rs. 5,200</span>
            </div>
            <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">46% OFF</span>
          </div>
          <div className="bg-white rounded-lg border shadow-sm p-3">
            <img src="https://images.unsplash.com/photo-1509048191080-d2425f1f4157?w=300&h=300&fit=crop" 
                 className="w-full h-24 object-cover rounded mb-2" 
                 alt="Omega Watch" />
            <h4 className="text-sm font-bold text-gray-800">Omega Speedmaster</h4>
            <div className="flex items-center gap-1 mt-1">
              <span className="text-red-600 font-bold text-lg">Rs. 3,500</span>
              <span className="text-gray-400 line-through text-xs">Rs. 6,200</span>
            </div>
            <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">43% OFF</span>
          </div>
        </div>
      </div>
      
      {/* Category Grid */}
      <div className="px-4 mb-6">
        <img 
          src={categoryGrid} 
          alt="Daraz Categories" 
          className="w-full cursor-pointer"
          onClick={() => setLocation('/categories')}
        />
      </div>

      {/* Show message if no script is active */}
      {!isScriptActive && (
        <div className="px-4 mb-6">
          <div className="bg-white rounded-lg shadow-card p-6 text-center">
            <div className="text-gray-500 mb-2">
              <Icon name="home" size={48} className="mx-auto text-gray-300 mb-4" />
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">No Active Script</h3>
            <p className="text-gray-600 text-sm">
              Admin needs to activate a script to display products
            </p>
          </div>
        </div>
      )}



      {/* Categories Header */}
      <div className="flex items-center justify-between px-4 py-4">
        <h2 className="text-xl font-bold text-gray-800">카테고리</h2>
        <Button
          variant="ghost"
          className="text-primary text-sm font-medium p-0"
        >
          더 보기 <Icon name="chevron-right" size={16} className="ml-1" />
        </Button>
      </div>

      {/* Category Cards */}
      <div className="px-4 grid grid-cols-2 gap-4 mb-6">
        {categories.map((category, index) => (
          <Card key={index} className="cursor-pointer hover:shadow-md transition-shadow">
            <CardContent className="p-0">
              <div className={`w-full h-32 bg-gradient-to-br ${category.color} flex items-center justify-center rounded-t-lg`}>
                <Icon name={category.icon as any} size={32} />
              </div>
              <div className="p-3">
                <h3 className="font-semibold text-gray-800 text-sm">{category.name}</h3>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* FLASH SALE SECTION - DYNAMIC PRODUCTS */}
      {(scriptProducts.filter((p: any) => p.isFlashDeal === true).length > 0 || !isScriptActive) && (
        <div className="px-4 mb-6">
          <div className="bg-red-500 text-white p-4 rounded-lg mb-4">
            <h2 className="text-xl font-bold">⚡ Flash महा बचत बजार</h2>
            <p className="text-sm">Up to 72% OFF - Limited Time!</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {(scriptProducts.filter((p: any) => p.isFlashDeal === true).length > 0 ? 
              scriptProducts.filter((p: any) => p.isFlashDeal === true) : 
              flashSaleProducts.slice(0, 4)
            ).map((product: any, index: number) => (
              <div key={product.id || index} className="bg-white border rounded-lg overflow-hidden cursor-pointer shadow-sm" 
                   onClick={() => handleProductClick(product)}>
                <div className="bg-gray-50 p-2 relative">
                  <img src={getProxiedImageUrl(product.imageUrl || product.imageUrls?.[0])} 
                       className="w-full h-40 object-contain" 
                       alt={product.title}
                       referrerPolicy="no-referrer"
                       onError={(e) => { e.currentTarget.src = '/placeholder-product.svg'; }} />
                  {/* Urgency Timer */}
                  <div className="absolute top-1 right-1 bg-red-600 text-white text-[10px] px-1.5 py-0.5 rounded flex items-center gap-1">
                    <span>⏰</span>
                    <span>{String(offerTimer.minutes).padStart(2, '0')}:{String(offerTimer.seconds).padStart(2, '0')}</span>
                  </div>
                </div>
                <div className="p-3">
                  <h4 className="text-sm font-bold line-clamp-2 mb-2">{product.title}</h4>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-red-600 font-bold">Rs. {parseFloat(product.price).toLocaleString()}</span>
                    {product.originalPrice && (
                      <span className="text-gray-400 line-through text-xs">Rs. {parseFloat(product.originalPrice).toLocaleString()}</span>
                    )}
                  </div>
                  {product.discount && (
                    <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded mt-1 inline-block">{product.discount}% OFF</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Filters - Only show if script is active */}
      {isScriptActive && (
        <div className="px-4 mb-6">
          <div className="flex gap-2 overflow-x-auto">
            {filters.map((filter) => (
              <Button
                key={filter}
                variant={selectedFilter === filter ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedFilter(filter)}
                className={`whitespace-nowrap ${
                  selectedFilter === filter ? 'bg-primary text-white' : 'bg-white border-gray-200 text-gray-600'
                }`}
              >
                {filter}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Products Section - FORCED TO SHOW */}
      {true && (
        <>
          <div className="px-4 mb-4">
            <h3 className="text-lg font-bold text-gray-800 mb-3">🔥 PRODUCTS SECTION - Total: {scriptProducts.length}</h3>
            <p className="text-sm text-gray-600">Script Active: {isScriptActive ? 'YES' : 'NO'} | Products Available: {scriptProducts.length}</p>
          </div>
          <div className="px-4 grid grid-cols-2 gap-4">
        {scriptLoading ? (
          [...Array(30)].map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <div className="w-full h-48 bg-gray-200 skeleton"></div>
              <CardContent className="p-3">
                <div className="h-4 bg-gray-200 rounded mb-1 skeleton"></div>
                <div className="h-5 bg-gray-200 rounded w-1/2 skeleton"></div>
              </CardContent>
            </Card>
          ))
        ) : (
          // Combine database products and script non-flash products  
          (() => {
            // Show products based on their isFlashDeal status  
            const regularProducts = scriptProducts.filter((p: any) => p.isFlashDeal === false);
            console.log('🟢 All script products:', scriptProducts.length);
            console.log('🔥 Flash products:', scriptProducts.filter((p: any) => p.isFlashDeal === true).length);
            console.log('🛍️ Regular products (false):', scriptProducts.filter((p: any) => p.isFlashDeal === false).length);
            console.log('🛒 Filtered regular products:', regularProducts.length);

            
            // Always show products - remove the empty check
            // if (regularProducts.length === 0) {
            //   return (
            //     <div className="col-span-2 text-center py-8">
            //       <div className="bg-white rounded-lg p-6">
            //         <h4 className="text-lg font-semibold text-gray-800 mb-2">Add More Products</h4>
            //         <p className="text-gray-600 text-sm">Visit admin panel to add regular products</p>
            //       </div>
            //     </div>
            //   );
            // }
            
            console.log('❌ RENDERING:', regularProducts.length, 'products');
            console.log('❌ ALL PRODUCTS DETAILS:', scriptProducts.map((p: any) => ({
              title: p.title?.substring(0, 30),
              isFlashDeal: p.isFlashDeal,
              id: p._id
            })));
            
            // Clean implementation - just show regular products
            console.log('❌ TOTAL PRODUCTS TO RENDER:', regularProducts.length);
            
            // FORCE SHOW - Add test products if no regular products found
            const finalProducts = regularProducts.length > 0 ? regularProducts : [{
              _id: 'emergency-test',
              title: 'EMERGENCY TEST - No Regular Products Found',
              price: '999',
              imageUrl: 'https://via.placeholder.com/300x300',
              isFlashDeal: false
            }];

            return finalProducts.slice(0, 35).map((product: any, index: number) => (
            <Card key={product._id || product.id || index} className="cursor-pointer hover:shadow-md transition-shadow overflow-hidden" onClick={() => handleProductClick(product)}>
              <CardContent className="p-0">
                <div className="relative bg-gray-50 p-2">
                  <img 
                    src={getProxiedImageUrl(product.imageUrl || product.imageUrl2)} 
                    alt={product.title}
                    className="w-full h-44 object-contain"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      e.currentTarget.src = '/placeholder-product.svg';
                    }}
                  />
                  {/* Urgency Timer */}
                  <div className="absolute top-1 right-1 bg-red-600 text-white text-[10px] px-1.5 py-0.5 rounded flex items-center gap-1">
                    <span>⏰</span>
                    <span>{String(offerTimer.minutes).padStart(2, '0')}:{String(offerTimer.seconds).padStart(2, '0')}</span>
                  </div>
                  {product.discount > 0 && (
                    <div className="absolute top-1 left-1 bg-destructive text-white px-2 py-0.5 rounded text-xs font-bold">
                      {product.discount}% OFF
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <h4 className="text-sm font-medium text-gray-800 line-clamp-2 mb-2">
                    {product.title}
                  </h4>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-primary font-bold">
                      Rs. {product.price ? parseFloat(product.price).toLocaleString() : 'N/A'}
                    </span>
                    {product.originalPrice && (
                      <span className="text-gray-400 text-xs line-through">
                        Rs. {parseFloat(product.originalPrice).toLocaleString()}
                      </span>
                    )}
                  </div>
                  {product.sold > 0 && (
                    <div className="text-gray-500 text-xs mt-1">
                      {product.sold} sold
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
            ));
          })()
        )}
          </div>
        </>
      )}

    </div>
  );
}