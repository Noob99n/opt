import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { SearchBar } from '@/components/layout/search-bar';
import { Card, CardContent } from '@/components/ui/card';
import { Icon } from '@/components/ui/icon';

export default function Categories() {
  const [, setLocation] = useLocation();

  const { data: settings = { script: 'none' } } = useQuery({
    queryKey: ['/api/settings'],
    queryFn: async () => {
      const response = await fetch('/api/settings');
      if (!response.ok) throw new Error('Failed to fetch settings');
      return response.json() as Promise<{ script: string }>;
    },
  });

  const handleSearch = (query: string) => {
    if (query.trim()) {
      setLocation(`/search?q=${encodeURIComponent(query)}`);
    }
  };

  const isScriptActive = settings.script !== 'none';

  const { data: categories = [] } = useQuery({
    queryKey: ['/api/categories'],
    queryFn: async () => {
      const response = await fetch('/api/categories');
      if (!response.ok) throw new Error('Failed to fetch categories');
      return response.json();
    },
    enabled: isScriptActive,
  });

  const getIconByName = (name: string) => {
    const iconMap: { [key: string]: string } = {
      'Electronics': 'smartphone',
      'Fashion': 'user',
      'Home & Kitchen': 'home',
      'Sports': 'dumbbell',
      'Books': 'book',
      'Beauty': 'sparkles',
    };
    return iconMap[name] || 'grid-3x3';
  };

  const getColorByName = (name: string) => {
    const colorMap: { [key: string]: string } = {
      'Electronics': 'from-blue-100 to-blue-200 text-blue-600',
      'Fashion': 'from-red-100 to-red-200 text-red-600',
      'Home & Kitchen': 'from-green-100 to-green-200 text-green-600',
      'Sports': 'from-purple-100 to-purple-200 text-purple-600',
      'Books': 'from-yellow-100 to-yellow-200 text-yellow-600',
      'Beauty': 'from-pink-100 to-pink-200 text-pink-600',
    };
    return colorMap[name] || 'from-gray-100 to-gray-200 text-gray-600';
  };

  return (
    <div className="min-h-screen pb-20" style={{ backgroundColor: '#f1f3f6' }}>
      <SearchBar onSearch={handleSearch} />
      
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-4">
        <h1 className="text-xl font-bold text-gray-800">All Categories</h1>
      </div>

      {!isScriptActive ? (
        <div className="px-4 py-8">
          <div className="bg-white rounded-lg shadow-card p-8 text-center">
            <div className="text-gray-400 mb-4">
              <Icon name="grid-3x3" size={64} className="mx-auto" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-3">Categories Unavailable</h3>
            <p className="text-gray-600 text-sm">
              No script is active. Categories will be available when admin activates a product script.
            </p>
          </div>
        </div>
      ) : (
        <div className="px-4 py-6 grid grid-cols-2 gap-4">
          {categories.map((category: any) => (
            <Card 
              key={category.id} 
              className="cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => setLocation(`/category/${encodeURIComponent(category.name)}`)}
            >
              <CardContent className="p-0">
                <div className={`w-full h-32 bg-gradient-to-br ${getColorByName(category.name)} flex items-center justify-center rounded-t-lg`}>
                  <Icon name={getIconByName(category.name) as any} size={32} />
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-gray-800 text-center">{category.name}</h3>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}