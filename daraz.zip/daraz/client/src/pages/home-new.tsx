import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { SearchBar } from '@/components/layout/search-bar';
import { FlashSaleBanner } from '@/components/product/flash-sale-banner';
import { Icon } from '@/components/ui/icon';
import { memo, useEffect } from 'react';
import { ImagePreloader, OptimizedImage } from '@/components/common/ImagePreloader';
import { preloadCriticalResources } from '@/utils/performance';
import categoryGrid from '@assets/image_1751707197982.png';

const Home = memo(function Home() {
  const [, setLocation] = useLocation();

  // Preload critical resources on component mount
  useEffect(() => {
    preloadCriticalResources();
  }, []);

  const { data: settings = { script: 'none' } } = useQuery({
    queryKey: ['/api/settings'],
    queryFn: async () => {
      const response = await fetch('/api/settings');
      if (!response.ok) throw new Error('Failed to fetch settings');
      return response.json() as Promise<{ script: string }>;
    },
  });

  const handleSearch = (query: string) => {
    if (query.trim()) {
      setLocation(`/search?q=${encodeURIComponent(query)}`);
    }
  };

  const isScriptActive = settings.script !== 'none';

  return (
    <div className="min-h-screen pb-20" style={{ backgroundColor: '#f1f3f6' }}>
      <ImagePreloader />
      <SearchBar onSearch={handleSearch} />
      
      <FlashSaleBanner />
      
      {/* Category Grid */}
      <div className="px-4 mb-6">
        <OptimizedImage 
          src={categoryGrid} 
          alt="Daraz Categories" 
          className="w-full cursor-pointer"
          loading="eager"
        />
      </div>

      {/* Show message if no script is active */}
      {!isScriptActive && (
        <div className="px-4 mb-6">
          <div className="bg-white rounded-lg shadow-card p-8 text-center">
            <div className="text-gray-400 mb-4">
              <Icon name="shopping-cart" size={64} className="mx-auto" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-3">No Products Available</h3>
            <p className="text-gray-600 text-sm leading-relaxed">
              No script is currently active. Contact admin to activate a product script to view available items.
            </p>
          </div>
        </div>
      )}
    </div>
  );
});

export default Home;