import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { 
  Lock, Users, FileText, Plus, Trash2, Edit, LogOut, 
  Calendar, User, Key, Bot, Settings, RefreshCw, Check, X,
  ArrowLeft, Package, Save, Play, Square, Store, ExternalLink
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

interface Admin {
  _id: string;
  username: string;
  expiryDate: string;
  isActive: boolean;
  botToken?: string;
  botChatId?: string;
  activeScriptId?: string;
  lastLogin?: string;
  createdAt: string;
}

interface Script {
  _id: string;
  name: string;
  description: string;
  category: string;
  status: string;
  isActive: boolean;
  createdAt: string;
}

interface Product {
  _id: string;
  title: string;
  price: number;
  originalPrice?: number;
  discount?: number;
  description?: string;
  category?: string;
  brand?: string;
  imageUrl?: string;
  images?: string[];
  review?: string;
  highlights?: string[];
  isFlashDeal?: boolean;
}

export default function Owner() {
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  const { toast } = useToast();
  
  const [showAddAdmin, setShowAddAdmin] = useState(false);
  const [showAddScript, setShowAddScript] = useState(false);
  const [selectedScript, setSelectedScript] = useState<Script | null>(null);
  const [deletingAdminId, setDeletingAdminId] = useState<string | null>(null);
  
  const [newAdmin, setNewAdmin] = useState({
    username: '',
    password: '',
    expiryDays: 30,
    botToken: '',
    botChatId: ''
  });
  
  const [newScript, setNewScript] = useState({
    name: '',
    description: '',
    category: 'Other'
  });

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const res = await fetch('/api/owner/check-auth');
      const data = await res.json();
      setIsAuthenticated(data.authenticated);
    } catch (e) {
      setIsAuthenticated(false);
    } finally {
      setIsCheckingAuth(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) {
      toast({ title: "Error", description: "Please enter password", variant: "destructive" });
      return;
    }
    setIsLoading(true);
    try {
      const response = await fetch('/api/owner/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password })
      });
      const data = await response.json();
      if (response.ok) {
        setIsAuthenticated(true);
        toast({ title: "Success", description: "Login successful" });
      } else {
        toast({ title: "Error", description: data.error || "Invalid password", variant: "destructive" });
      }
    } catch (error) {
      toast({ title: "Error", description: "Login failed", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/owner/logout', { method: 'POST' });
      setIsAuthenticated(false);
      setPassword('');
    } catch (e) {
      console.error(e);
    }
  };

  const { data: admins = [], isLoading: adminsLoading } = useQuery<Admin[]>({
    queryKey: ['/api/owner/admins'],
    enabled: isAuthenticated
  });

  const { data: scripts = [], isLoading: scriptsLoading, refetch: refetchScripts } = useQuery<Script[]>({
    queryKey: ['/api/scripts'],
    enabled: isAuthenticated
  });

  const createAdminMutation = useMutation({
    mutationFn: async (data: typeof newAdmin) => {
      const res = await apiRequest('POST', '/api/owner/admins', {
        ...data,
        expiryDays: Number(data.expiryDays)
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/owner/admins'] });
      setShowAddAdmin(false);
      setNewAdmin({ username: '', password: '', expiryDays: 30, botToken: '', botChatId: '' });
      toast({ title: "Success", description: "Admin created successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message || "Failed to create admin", variant: "destructive" });
    }
  });

  const deleteAdminMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest('DELETE', `/api/owner/admins/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/owner/admins'] });
      toast({ title: "Success", description: "Admin deleted" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete admin", variant: "destructive" });
    }
  });

  const toggleAdminMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) => {
      return apiRequest('PATCH', `/api/owner/admins/${id}`, { isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/owner/admins'] });
    }
  });

  const createScriptMutation = useMutation({
    mutationFn: async (data: typeof newScript) => {
      return apiRequest('POST', '/api/scripts', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/scripts'] });
      setShowAddScript(false);
      setNewScript({ name: '', description: '', category: 'Other' });
      toast({ title: "Success", description: "Script created successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message || "Failed to create script", variant: "destructive" });
    }
  });

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const isExpired = (dateStr: string) => new Date(dateStr) < new Date();
  const daysRemaining = (dateStr: string) => {
    const diff = new Date(dateStr).getTime() - new Date().getTime();
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  };

  if (isCheckingAuth) {
    return (
      <div className="fixed inset-0 bg-gray-900 flex items-center justify-center z-50">
        <RefreshCw className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 bg-gray-900 flex items-center justify-center p-4 z-50">
        <Card className="w-full max-w-sm bg-gray-800 border-gray-700">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mb-4">
              <Lock className="w-8 h-8 text-primary" />
            </div>
            <CardTitle className="text-white text-xl">Owner Panel</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <Input
                type="password"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                data-testid="input-owner-password"
              />
              <Button 
                type="submit" 
                className="w-full"
                disabled={isLoading}
                data-testid="button-owner-login"
              >
                {isLoading ? 'Loading...' : 'Unlock'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (selectedScript) {
    return (
      <ScriptPanel 
        script={selectedScript} 
        onBack={() => {
          setSelectedScript(null);
          refetchScripts();
        }}
        onLogout={handleLogout}
      />
    );
  }

  return (
    <div className="fixed inset-0 bg-gray-900 z-50 overflow-hidden">
      <div className="h-full flex flex-col">
        <header className="bg-gray-800 border-b border-gray-700 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
              <Settings className="w-5 h-5 text-primary" />
            </div>
            <h1 className="text-xl font-semibold text-white">Owner Panel</h1>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleLogout}
            className="text-gray-400 hover:text-white"
            data-testid="button-owner-logout"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </header>

        <div className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto">
            <Tabs defaultValue="admins" className="space-y-6">
              <TabsList className="bg-gray-800 border border-gray-700">
                <TabsTrigger value="admins" className="data-[state=active]:bg-gray-700" data-testid="tab-admins">
                  <Users className="w-4 h-4 mr-2" />
                  Admins
                </TabsTrigger>
                <TabsTrigger value="scripts" className="data-[state=active]:bg-gray-700" data-testid="tab-scripts">
                  <FileText className="w-4 h-4 mr-2" />
                  Scripts
                </TabsTrigger>
                <TabsTrigger value="run" className="data-[state=active]:bg-gray-700" data-testid="tab-run">
                  <Play className="w-4 h-4 mr-2" />
                  Run Scripts
                </TabsTrigger>
                <TabsTrigger value="settings" className="data-[state=active]:bg-gray-700" data-testid="tab-settings">
                  <Key className="w-4 h-4 mr-2" />
                  Settings
                </TabsTrigger>
              </TabsList>

              <TabsContent value="admins" className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-medium text-white">Admin Management</h2>
                  <Button onClick={() => setShowAddAdmin(true)} data-testid="button-add-admin">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Admin
                  </Button>
                </div>

                {adminsLoading ? (
                  <div className="text-center py-8 text-gray-400">Loading admins...</div>
                ) : admins.length === 0 ? (
                  <Card className="bg-gray-800 border-gray-700">
                    <CardContent className="py-12 text-center">
                      <Users className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                      <p className="text-gray-400">No admins yet. Click "Add Admin" to create one.</p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid gap-4">
                    {admins.map((admin) => (
                      <Card key={admin._id} className="bg-gray-800 border-gray-700" data-testid={`card-admin-${admin._id}`}>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <div className="w-10 h-10 bg-blue-500/20 rounded-full flex items-center justify-center">
                                <User className="w-5 h-5 text-blue-400" />
                              </div>
                              <div>
                                <h3 className="text-white font-medium">{admin.username}</h3>
                                <div className="flex items-center gap-2 text-sm text-gray-400">
                                  <Calendar className="w-3 h-3" />
                                  <span>Expires: {formatDate(admin.expiryDate)}</span>
                                  {isExpired(admin.expiryDate) ? (
                                    <Badge variant="destructive" className="text-xs">Expired</Badge>
                                  ) : (
                                    <Badge variant="secondary" className="text-xs">{daysRemaining(admin.expiryDate)} days left</Badge>
                                  )}
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              {admin.botToken && (
                                <Badge variant="outline" className="text-green-400 border-green-400/30">
                                  <Bot className="w-3 h-3 mr-1" />
                                  Bot
                                </Badge>
                              )}
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => toggleAdminMutation.mutate({ id: admin._id, isActive: !admin.isActive })}
                                className={admin.isActive ? "text-green-400" : "text-red-400"}
                                data-testid={`button-toggle-admin-${admin._id}`}
                              >
                                {admin.isActive ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => setDeletingAdminId(admin._id)}
                                className="text-red-400 hover:text-red-300"
                                data-testid={`button-delete-admin-${admin._id}`}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="scripts" className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-medium text-white">Script Management</h2>
                  <Button onClick={() => setShowAddScript(true)} data-testid="button-add-script">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Script
                  </Button>
                </div>

                {scriptsLoading ? (
                  <div className="text-center py-8 text-gray-400">Loading scripts...</div>
                ) : scripts.length === 0 ? (
                  <Card className="bg-gray-800 border-gray-700">
                    <CardContent className="py-12 text-center">
                      <FileText className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                      <p className="text-gray-400">No scripts yet. Click "Add Script" to create one.</p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {scripts.map((script) => (
                      <Card 
                        key={script._id} 
                        className="bg-gray-800 border-gray-700 cursor-pointer hover:bg-gray-750 hover:border-primary/50 transition-all"
                        onClick={() => setSelectedScript(script)}
                        data-testid={`card-script-${script._id}`}
                      >
                        <CardContent className="p-5">
                          <div className="flex items-start gap-4">
                            <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                              <FileText className="w-6 h-6 text-purple-400" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <h3 className="text-white font-medium truncate">{script.name}</h3>
                                <Badge 
                                  variant={script.isActive ? "default" : "secondary"}
                                  className={`text-xs flex-shrink-0 ${script.isActive ? "bg-green-500/20 text-green-400" : ""}`}
                                >
                                  {script.isActive ? 'Active' : 'Inactive'}
                                </Badge>
                              </div>
                              <Badge variant="outline" className="text-xs mb-2">{script.category}</Badge>
                              {script.description && (
                                <p className="text-sm text-gray-400 truncate">{script.description}</p>
                              )}
                              <p className="text-xs text-gray-500 mt-2">Click to manage</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="run" className="space-y-4">
                <RunScriptsPanel scripts={scripts} scriptsLoading={scriptsLoading} />
              </TabsContent>

              <TabsContent value="settings" className="space-y-4">
                <h2 className="text-lg font-medium text-white">API Settings</h2>
                <Card className="bg-gray-800 border-gray-700">
                  <CardContent className="p-6">
                    <SettingsPanel />
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>

      <Dialog open={showAddAdmin} onOpenChange={setShowAddAdmin}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Add New Admin</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-gray-300">Username</Label>
              <Input
                value={newAdmin.username}
                onChange={(e) => setNewAdmin({ ...newAdmin, username: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white mt-1"
                placeholder="Enter username"
                data-testid="input-admin-username"
              />
            </div>
            <div>
              <Label className="text-gray-300">Password</Label>
              <Input
                type="password"
                value={newAdmin.password}
                onChange={(e) => setNewAdmin({ ...newAdmin, password: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white mt-1"
                placeholder="Enter password"
                data-testid="input-admin-password"
              />
            </div>
            <div>
              <Label className="text-gray-300">Expiry Days</Label>
              <Input
                type="number"
                value={newAdmin.expiryDays}
                onChange={(e) => setNewAdmin({ ...newAdmin, expiryDays: parseInt(e.target.value) || 30 })}
                className="bg-gray-700 border-gray-600 text-white mt-1"
                min={1}
                max={365}
                data-testid="input-admin-expiry"
              />
            </div>
            <div>
              <Label className="text-gray-300">Bot Token (Optional)</Label>
              <Input
                value={newAdmin.botToken}
                onChange={(e) => setNewAdmin({ ...newAdmin, botToken: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white mt-1"
                placeholder="Telegram bot token"
                data-testid="input-admin-bot-token"
              />
            </div>
            <div>
              <Label className="text-gray-300">Bot Chat ID (Optional)</Label>
              <Input
                value={newAdmin.botChatId}
                onChange={(e) => setNewAdmin({ ...newAdmin, botChatId: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white mt-1"
                placeholder="Telegram chat ID"
                data-testid="input-admin-chat-id"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowAddAdmin(false)}>Cancel</Button>
            <Button 
              onClick={() => createAdminMutation.mutate(newAdmin)}
              disabled={createAdminMutation.isPending}
              data-testid="button-confirm-add-admin"
            >
              {createAdminMutation.isPending ? 'Creating...' : 'Create Admin'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showAddScript} onOpenChange={setShowAddScript}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Add New Script</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-gray-300">Script Name</Label>
              <Input
                value={newScript.name}
                onChange={(e) => setNewScript({ ...newScript, name: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white mt-1"
                placeholder="Enter script name"
                data-testid="input-script-name"
              />
            </div>
            <div>
              <Label className="text-gray-300">Description</Label>
              <Textarea
                value={newScript.description}
                onChange={(e) => setNewScript({ ...newScript, description: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white mt-1"
                placeholder="Enter description"
                data-testid="input-script-description"
              />
            </div>
            <div>
              <Label className="text-gray-300">Category</Label>
              <Select
                value={newScript.category}
                onValueChange={(value) => setNewScript({ ...newScript, category: value })}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white mt-1" data-testid="select-script-category">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="Phone">Phone</SelectItem>
                  <SelectItem value="Accessories">Accessories</SelectItem>
                  <SelectItem value="Electronics">Electronics</SelectItem>
                  <SelectItem value="Fashion">Fashion</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowAddScript(false)}>Cancel</Button>
            <Button 
              onClick={() => createScriptMutation.mutate(newScript)}
              disabled={createScriptMutation.isPending}
              data-testid="button-confirm-add-script"
            >
              {createScriptMutation.isPending ? 'Creating...' : 'Create Script'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deletingAdminId} onOpenChange={(open) => !open && setDeletingAdminId(null)}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
          </DialogHeader>
          <p className="text-gray-300">Are you sure you want to delete this admin? This action cannot be undone.</p>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setDeletingAdminId(null)}>Cancel</Button>
            <Button 
              variant="destructive" 
              onClick={() => {
                if (deletingAdminId) deleteAdminMutation.mutate(deletingAdminId);
                setDeletingAdminId(null);
              }}
            >
              Delete Admin
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function RunScriptsPanel({ scripts, scriptsLoading }: { scripts: Script[]; scriptsLoading: boolean }) {
  const { toast } = useToast();
  const [activeScriptId, setActiveScriptId] = useState<string | null>(null);

  const { data: runStatus, refetch: refetchStatus } = useQuery<{ activeScriptId: string | null }>({
    queryKey: ['/api/owner/run-status'],
  });

  useEffect(() => {
    if (runStatus?.activeScriptId) {
      setActiveScriptId(runStatus.activeScriptId);
    }
  }, [runStatus]);

  const runScriptMutation = useMutation({
    mutationFn: async (scriptId: string | null) => {
      return apiRequest('POST', '/api/owner/run-script', { scriptId });
    },
    onSuccess: (_, scriptId) => {
      setActiveScriptId(scriptId);
      toast({ title: "Success", description: scriptId ? "Script is now running" : "Script stopped" });
      refetchStatus();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update script", variant: "destructive" });
    }
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-medium text-white">Run Scripts</h2>
          <p className="text-sm text-gray-400">Select a script to run on the main store</p>
        </div>
        {activeScriptId && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => window.open('/', '_blank')}
            className="border-green-500/50 text-green-400"
            data-testid="button-view-main-store"
          >
            <Store className="w-4 h-4 mr-2" />
            View Main Store
            <ExternalLink className="w-3 h-3 ml-1" />
          </Button>
        )}
      </div>

      {scriptsLoading ? (
        <div className="text-center py-8 text-gray-400">Loading scripts...</div>
      ) : scripts.length === 0 ? (
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="py-12 text-center">
            <FileText className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">No scripts available. Create one in the Scripts tab first.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {scripts.map((script) => {
            const isActive = activeScriptId === script._id;
            return (
              <Card 
                key={script._id} 
                className={`bg-gray-800 border-gray-700 transition-colors ${isActive ? 'border-green-500/50 bg-green-500/5' : ''}`}
                data-testid={`card-run-script-${script._id}`}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-4 flex-1 min-w-0">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${isActive ? 'bg-green-500/20' : 'bg-purple-500/20'}`}>
                        <FileText className={`w-5 h-5 ${isActive ? 'text-green-400' : 'text-purple-400'}`} />
                      </div>
                      <div className="min-w-0">
                        <h3 className="text-white font-medium flex items-center gap-2 flex-wrap">
                          <span className="truncate">{script.name}</span>
                          {isActive && (
                            <Badge className="bg-green-500/20 text-green-400 text-xs flex-shrink-0">
                              <Check className="w-3 h-3 mr-1" />
                              Running
                            </Badge>
                          )}
                        </h3>
                        <div className="flex items-center gap-2 text-sm text-gray-400">
                          <Badge variant="outline" className="text-xs">{script.category}</Badge>
                          {script.description && (
                            <span className="truncate">{script.description}</span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      {isActive ? (
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => runScriptMutation.mutate(null)}
                          disabled={runScriptMutation.isPending}
                          data-testid={`button-stop-owner-script-${script._id}`}
                        >
                          <Square className="w-4 h-4 mr-2" />
                          Stop
                        </Button>
                      ) : (
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() => runScriptMutation.mutate(script._id)}
                          disabled={runScriptMutation.isPending}
                          data-testid={`button-run-owner-script-${script._id}`}
                        >
                          <Play className="w-4 h-4 mr-2" />
                          Run
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

function SettingsPanel() {
  const { toast } = useToast();
  const [scraperApiKey, setScraperApiKey] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [ownerBotToken, setOwnerBotToken] = useState('');
  const [ownerBotChatId, setOwnerBotChatId] = useState('');
  const [showBotToken, setShowBotToken] = useState(false);
  
  const { data: apiStatus, isLoading, refetch } = useQuery<{ scraperApiConfigured: boolean; maskedKey?: string }>({
    queryKey: ['/api/owner/api-status'],
  });

  const { data: botSettings, refetch: refetchBot } = useQuery<{ botToken?: string; botChatId?: string }>({
    queryKey: ['/api/owner/bot-settings'],
  });

  const saveApiKeyMutation = useMutation({
    mutationFn: async (apiKey: string) => {
      return apiRequest('POST', '/api/owner/settings', { key: 'SCRAPER_API_KEY', value: apiKey });
    },
    onSuccess: () => {
      toast({ title: "Success", description: "API Key saved" });
      setScraperApiKey('');
      refetch();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to save API key", variant: "destructive" });
    }
  });

  const deleteApiKeyMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('DELETE', '/api/owner/settings/SCRAPER_API_KEY');
    },
    onSuccess: () => {
      toast({ title: "Success", description: "API Key removed" });
      refetch();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to remove API key", variant: "destructive" });
    }
  });

  const saveBotSettingsMutation = useMutation({
    mutationFn: async (data: { botToken: string; botChatId: string }) => {
      return apiRequest('POST', '/api/owner/bot-settings', data);
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Bot settings saved securely" });
      setOwnerBotToken('');
      setOwnerBotChatId('');
      refetchBot();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to save bot settings", variant: "destructive" });
    }
  });

  const deleteBotSettingsMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('DELETE', '/api/owner/bot-settings');
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Bot settings removed" });
      refetchBot();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to remove bot settings", variant: "destructive" });
    }
  });

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-white font-medium mb-4">ScraperAPI Configuration</h3>
        <p className="text-sm text-gray-400 mb-4">
          ScraperAPI is used to extract product data from Amazon. Each product extraction uses 1 credit (5000 free credits available).
        </p>
        
        <div className="flex items-center gap-3 p-4 rounded-lg bg-gray-700/50 border border-gray-600 mb-4">
          <div className={`w-3 h-3 rounded-full ${apiStatus?.scraperApiConfigured ? 'bg-green-500' : 'bg-red-500'}`} />
          <div className="flex-1">
            <p className="text-white font-medium">
              {isLoading ? 'Checking...' : apiStatus?.scraperApiConfigured ? 'API Key Configured' : 'API Key Not Set'}
            </p>
            {apiStatus?.maskedKey && (
              <p className="text-xs text-gray-400">Key: {apiStatus.maskedKey}</p>
            )}
          </div>
          {apiStatus?.scraperApiConfigured && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => deleteApiKeyMutation.mutate()}
              className="text-red-400"
              data-testid="button-delete-api-key"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          )}
        </div>

        <div className="space-y-3">
          <Label className="text-gray-300">
            {apiStatus?.scraperApiConfigured ? 'Update API Key' : 'Enter API Key'}
          </Label>
          <div className="flex gap-2">
            <Input
              type={showKey ? "text" : "password"}
              value={scraperApiKey}
              onChange={(e) => setScraperApiKey(e.target.value)}
              className="bg-gray-700 border-gray-600 text-white flex-1"
              placeholder="Enter ScraperAPI key..."
              data-testid="input-scraper-api-key"
            />
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setShowKey(!showKey)}
            >
              {showKey ? <X className="w-4 h-4" /> : <Key className="w-4 h-4" />}
            </Button>
            <Button 
              onClick={() => scraperApiKey && saveApiKeyMutation.mutate(scraperApiKey)}
              disabled={!scraperApiKey || saveApiKeyMutation.isPending}
              data-testid="button-save-api-key"
            >
              {saveApiKeyMutation.isPending ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            </Button>
          </div>
          <p className="text-xs text-gray-500">
            Get your free API key from <a href="https://www.scraperapi.com" target="_blank" rel="noopener noreferrer" className="text-blue-400 underline">scraperapi.com</a> (5000 free requests)
          </p>
        </div>
      </div>

      {/* Owner Bot Settings for Payment */}
      <div className="border-t border-gray-700 pt-6">
        <h3 className="text-white font-medium mb-4 flex items-center gap-2">
          <Bot className="w-5 h-5 text-blue-400" />
          Payment Bot Configuration
        </h3>
        <p className="text-sm text-gray-400 mb-4">
          Configure your Telegram bot for payment verification on the main store. This bot will receive payment screenshots and manage orders.
        </p>
        
        <div className="flex items-center gap-3 p-4 rounded-lg bg-gray-700/50 border border-gray-600 mb-4">
          <div className={`w-3 h-3 rounded-full ${botSettings?.botToken ? 'bg-green-500' : 'bg-yellow-500'}`} />
          <div className="flex-1">
            <p className="text-white font-medium">
              {botSettings?.botToken ? 'Bot Configured' : 'Bot Not Configured'}
            </p>
            {botSettings?.botChatId && (
              <p className="text-xs text-gray-400">Chat ID: {botSettings.botChatId}</p>
            )}
          </div>
          {botSettings?.botToken && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => deleteBotSettingsMutation.mutate()}
              className="text-red-400"
              data-testid="button-delete-bot-settings"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          )}
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="text-gray-300">Bot Token</Label>
            <div className="flex gap-2">
              <Input
                type={showBotToken ? "text" : "password"}
                value={ownerBotToken}
                onChange={(e) => setOwnerBotToken(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white flex-1"
                placeholder="Enter Telegram bot token..."
                data-testid="input-owner-bot-token"
              />
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setShowBotToken(!showBotToken)}
              >
                {showBotToken ? <X className="w-4 h-4" /> : <Key className="w-4 h-4" />}
              </Button>
            </div>
            <p className="text-xs text-gray-500">Get from @BotFather on Telegram</p>
          </div>
          
          <div className="space-y-2">
            <Label className="text-gray-300">Chat ID</Label>
            <Input
              value={ownerBotChatId}
              onChange={(e) => setOwnerBotChatId(e.target.value)}
              className="bg-gray-700 border-gray-600 text-white"
              placeholder="Enter your Telegram chat ID..."
              data-testid="input-owner-bot-chat-id"
            />
            <p className="text-xs text-gray-500">Get from @userinfobot on Telegram</p>
          </div>

          <Button 
            onClick={() => ownerBotToken && ownerBotChatId && saveBotSettingsMutation.mutate({ botToken: ownerBotToken, botChatId: ownerBotChatId })}
            disabled={!ownerBotToken || !ownerBotChatId || saveBotSettingsMutation.isPending}
            className="w-full"
            data-testid="button-save-bot-settings"
          >
            {saveBotSettingsMutation.isPending ? (
              <RefreshCw className="w-4 h-4 animate-spin mr-2" />
            ) : (
              <Save className="w-4 h-4 mr-2" />
            )}
            Save Bot Settings
          </Button>
        </div>
      </div>
    </div>
  );
}

const emptyProductForm = {
  title: '',
  price: '',
  originalPrice: '',
  discount: '',
  description: '',
  category: '',
  brand: '',
  imageUrl: '',
  image2: '',
  image3: '',
  image4: '',
  review: '',
  highlights: '',
  isFlashDeal: false,
};

function ScriptPanel({ script, onBack, onLogout }: { script: Script; onBack: () => void; onLogout: () => void }) {
  const { toast } = useToast();
  const [editingScript, setEditingScript] = useState<Script>(script);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [url, setUrl] = useState('');
  const [isExtracting, setIsExtracting] = useState(false);
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [productForm, setProductForm] = useState(emptyProductForm);
  const [deletingProductId, setDeletingProductId] = useState<string | null>(null);

  const { data: products = [], isLoading: productsLoading, refetch: refetchProducts } = useQuery<Product[]>({
    queryKey: [`/api/owner/scripts/${script._id}/products`],
  });

  const updateScriptMutation = useMutation({
    mutationFn: async (data: Partial<Script>) => {
      return apiRequest('PATCH', `/api/scripts/${script._id}`, data);
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Script updated" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update script", variant: "destructive" });
    }
  });

  const deleteScriptMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('DELETE', `/api/scripts/${script._id}`);
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Script deleted" });
      onBack();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete script", variant: "destructive" });
    }
  });

  const addProductMutation = useMutation({
    mutationFn: async (productData: any) => {
      return apiRequest('POST', `/api/owner/scripts/${script._id}/products`, productData);
    },
    onSuccess: () => {
      refetchProducts();
      setUrl('');
      setProductForm(emptyProductForm);
      setShowProductForm(false);
      setEditingProductId(null);
      toast({ title: "Success", description: "Product saved" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message || "Failed to save product", variant: "destructive" });
    }
  });

  const updateProductMutation = useMutation({
    mutationFn: async ({ productId, data }: { productId: string; data: any }) => {
      return apiRequest('PATCH', `/api/owner/scripts/${script._id}/products/${productId}`, data);
    },
    onSuccess: () => {
      refetchProducts();
      setProductForm(emptyProductForm);
      setShowProductForm(false);
      setEditingProductId(null);
      toast({ title: "Success", description: "Product updated" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update product", variant: "destructive" });
    }
  });

  const deleteProductMutation = useMutation({
    mutationFn: async (productId: string) => {
      return apiRequest('DELETE', `/api/owner/scripts/${script._id}/products/${productId}`);
    },
    onSuccess: () => {
      refetchProducts();
      toast({ title: "Success", description: "Product removed" });
    }
  });

  const handleExtract = async () => {
    if (!url.trim()) return;
    setIsExtracting(true);
    try {
      const res = await fetch('/api/extract-amazon-product', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });
      const data = await res.json();
      if (res.ok) {
        const images = data.images || [];
        const highlightsArray = data.highlights || [];
        setProductForm({
          title: data.title || '',
          price: data.price?.toString() || '',
          originalPrice: data.originalPrice?.toString() || '',
          discount: data.discount?.toString() || '',
          description: data.description || '',
          category: data.category || '',
          brand: data.brand || '',
          imageUrl: data.imageUrl || images[0] || '',
          image2: images[1] || '',
          image3: images[2] || '',
          image4: images[3] || '',
          review: data.review || '',
          highlights: Array.isArray(highlightsArray) ? highlightsArray.join('\n') : '',
          isFlashDeal: false,
        });
        setShowProductForm(true);
        setEditingProductId(null);
        toast({ title: "Extracted!", description: "Review and edit details below" });
      } else {
        toast({ title: "Extraction Failed", description: data.error, variant: "destructive" });
      }
    } catch (e) {
      toast({ title: "Error", description: "Failed to extract product", variant: "destructive" });
    } finally {
      setIsExtracting(false);
    }
  };

  const handleSaveProduct = () => {
    if (!productForm.title.trim() || !productForm.price.trim()) {
      toast({ title: "Error", description: "Title and Price are required", variant: "destructive" });
      return;
    }
    const images = [productForm.imageUrl, productForm.image2, productForm.image3, productForm.image4].filter(Boolean);
    const highlightsArray = productForm.highlights.split('\n').map(h => h.trim()).filter(Boolean);
    const price = parseFloat(productForm.price) || 0;
    const original = parseFloat(productForm.originalPrice) || price;
    const autoDiscount = original > 0 && price < original ? Math.round(((original - price) / original) * 100) : 0;
    const productData = {
      title: productForm.title,
      price,
      originalPrice: original,
      discount: productForm.discount ? parseInt(productForm.discount) : autoDiscount,
      description: productForm.description,
      category: productForm.category,
      brand: productForm.brand,
      imageUrl: productForm.imageUrl || images[0] || '',
      images,
      review: productForm.review,
      highlights: highlightsArray,
      isFlashDeal: productForm.isFlashDeal
    };

    if (editingProductId) {
      updateProductMutation.mutate({ productId: editingProductId, data: productData });
    } else {
      addProductMutation.mutate(productData);
    }
  };

  const handleEditProduct = (product: Product) => {
    const images = product.images || [];
    setProductForm({
      title: product.title || '',
      price: product.price?.toString() || '',
      originalPrice: product.originalPrice?.toString() || '',
      discount: product.discount?.toString() || '',
      description: Array.isArray(product.description) ? product.description.join('\n') : (product.description || ''),
      category: product.category || '',
      brand: product.brand || '',
      imageUrl: product.imageUrl || images[0] || '',
      image2: images[1] || '',
      image3: images[2] || '',
      image4: images[3] || '',
      review: product.review || '',
      highlights: Array.isArray(product.highlights) ? product.highlights.join('\n') : '',
      isFlashDeal: product.isFlashDeal || false,
    });
    setEditingProductId(product._id);
    setShowProductForm(true);
  };

  const handleAddManually = () => {
    setProductForm(emptyProductForm);
    setEditingProductId(null);
    setShowProductForm(true);
  };

  const handleCancelProductForm = () => {
    setShowProductForm(false);
    setProductForm(emptyProductForm);
    setEditingProductId(null);
  };

  const handleSaveScript = () => {
    updateScriptMutation.mutate({
      name: editingScript.name,
      description: editingScript.description,
      category: editingScript.category
    });
  };

  return (
    <div className="fixed inset-0 bg-gray-900 z-50 overflow-hidden">
      <div className="h-full flex flex-col">
        <header className="bg-gray-800 border-b border-gray-700 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onBack}
              className="text-gray-400 hover:text-white"
              data-testid="button-back"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
              <FileText className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-white">{script.name}</h1>
              <Badge variant="outline" className="text-xs">{script.category}</Badge>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onLogout}
            className="text-gray-400 hover:text-white"
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </header>

        <div className="flex-1 overflow-auto p-6">
          <div className="max-w-6xl mx-auto space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
                <CardTitle className="text-white text-lg flex items-center gap-2">
                  <Settings className="w-5 h-5 text-gray-400" />
                  Script Settings
                </CardTitle>
                <Button 
                  variant="destructive" 
                  size="sm"
                  onClick={() => setShowDeleteConfirm(true)}
                  data-testid="button-delete-script"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete Script
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-gray-300">Script Name</Label>
                    <Input
                      value={editingScript.name}
                      onChange={(e) => setEditingScript({ ...editingScript, name: e.target.value })}
                      className="bg-gray-700 border-gray-600 text-white mt-1"
                      data-testid="input-script-name"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Category</Label>
                    <Select
                      value={editingScript.category}
                      onValueChange={(value) => setEditingScript({ ...editingScript, category: value })}
                    >
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-700">
                        <SelectItem value="Phone">Phone</SelectItem>
                        <SelectItem value="Accessories">Accessories</SelectItem>
                        <SelectItem value="Electronics">Electronics</SelectItem>
                        <SelectItem value="Fashion">Fashion</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-end">
                    <Button 
                      onClick={handleSaveScript} 
                      disabled={updateScriptMutation.isPending}
                      className="w-full"
                      data-testid="button-save-script"
                    >
                      {updateScriptMutation.isPending ? <RefreshCw className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                      Save Changes
                    </Button>
                  </div>
                </div>
                <div>
                  <Label className="text-gray-300">Description</Label>
                  <Textarea
                    value={editingScript.description}
                    onChange={(e) => setEditingScript({ ...editingScript, description: e.target.value })}
                    className="bg-gray-700 border-gray-600 text-white mt-1"
                    rows={2}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
                <CardTitle className="text-white text-lg flex items-center gap-2">
                  <Package className="w-5 h-5 text-gray-400" />
                  Products ({products.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {!showProductForm ? (
                  <>
                    <div className="flex gap-2 mb-4">
                      <Input 
                        placeholder="Paste product URL (Daraz, Amazon, etc.)" 
                        value={url}
                        onChange={(e) => setUrl(e.target.value)}
                        className="bg-gray-700 border-gray-600 text-white flex-1"
                        data-testid="input-product-url"
                      />
                      <Button onClick={handleExtract} disabled={isExtracting || !url.trim()} data-testid="button-extract">
                        {isExtracting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
                        Extract
                      </Button>
                      <Button variant="outline" onClick={handleAddManually} data-testid="button-add-manually">
                        Add Manually
                      </Button>
                    </div>

                    <div className="space-y-2 max-h-96 overflow-auto">
                      {productsLoading ? (
                        <div className="text-center py-8 text-gray-400">Loading products...</div>
                      ) : products.length === 0 ? (
                        <div className="text-center py-8 text-gray-500 italic">No products yet. Extract from URL or add manually.</div>
                      ) : (
                        products.map((product) => (
                          <div key={product._id} className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg border border-gray-600" data-testid={`product-${product._id}`}>
                            <div className="flex items-center gap-3 overflow-hidden flex-1">
                              <img src={product.imageUrl} alt="" className="w-14 h-14 object-cover rounded bg-gray-600 flex-shrink-0" />
                              <div className="overflow-hidden">
                                <p className="text-sm font-medium text-white truncate">{product.title}</p>
                                <p className="text-xs text-gray-400">Rs. {product.price}</p>
                                {product.brand && <Badge variant="outline" className="text-xs mt-1">{product.brand}</Badge>}
                                {product.isFlashDeal && <Badge className="bg-orange-500/20 text-orange-400 text-[10px] ml-2 border-orange-500/30">Flash Sale</Badge>}
                              </div>
                            </div>
                            <div className="flex items-center gap-2 flex-shrink-0">
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => handleEditProduct(product)}
                                className="text-blue-400 hover:text-blue-300"
                                data-testid={`button-edit-product-${product._id}`}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => setDeletingProductId(product._id)}
                                className="text-red-400 hover:text-red-300"
                                data-testid={`button-delete-product-${product._id}`}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-white font-medium">{editingProductId ? 'Edit Product' : 'Add New Product'}</h3>
                      <Button variant="ghost" size="sm" onClick={handleCancelProductForm}>
                        <X className="w-4 h-4 mr-2" />
                        Cancel
                      </Button>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="col-span-2">
                        <label className="text-sm text-gray-400 mb-1 block">Title *</label>
                        <Input 
                          value={productForm.title}
                          onChange={(e) => setProductForm(p => ({ ...p, title: e.target.value }))}
                          className="bg-gray-700 border-gray-600 text-white"
                          placeholder="Product title"
                          data-testid="input-product-title"
                        />
                      </div>
                      <div>
                        <label className="text-sm text-gray-400 mb-1 block">Price (Rs.) *</label>
                        <Input 
                          type="number"
                          value={productForm.price}
                          onChange={(e) => setProductForm(p => ({ ...p, price: e.target.value }))}
                          className="bg-gray-700 border-gray-600 text-white"
                          placeholder="1299"
                          data-testid="input-product-price"
                        />
                      </div>
                      <div>
                        <label className="text-sm text-gray-400 mb-1 block">Original Price (Rs.)</label>
                        <Input 
                          type="number"
                          value={productForm.originalPrice}
                          onChange={(e) => {
                            const originalVal = e.target.value;
                            const discount = parseFloat(productForm.discount) || 0;
                            if (discount > 0 && originalVal) {
                              const originalNum = parseFloat(originalVal) || 0;
                              const newPrice = Math.round(originalNum * (1 - discount / 100));
                              setProductForm(p => ({ ...p, originalPrice: originalVal, price: newPrice.toString() }));
                            } else {
                              setProductForm(p => ({ ...p, originalPrice: originalVal }));
                            }
                          }}
                          className="bg-gray-700 border-gray-600 text-white"
                          placeholder="1999"
                        />
                      </div>
                      <div>
                        <label className="text-sm text-gray-400 mb-1 block">Discount (%)</label>
                        <Input 
                          type="number"
                          value={productForm.discount}
                          onChange={(e) => {
                            const discountVal = e.target.value;
                            const original = parseFloat(productForm.originalPrice) || 0;
                            if (original > 0 && discountVal) {
                              const discountNum = parseFloat(discountVal) || 0;
                              const newPrice = Math.round(original * (1 - discountNum / 100));
                              setProductForm(p => ({ ...p, discount: discountVal, price: newPrice.toString() }));
                            } else {
                              setProductForm(p => ({ ...p, discount: discountVal }));
                            }
                          }}
                          className="bg-gray-700 border-gray-600 text-white"
                          placeholder="10"
                        />
                        {(() => {
                          const price = parseFloat(productForm.price) || 0;
                          const original = parseFloat(productForm.originalPrice) || 0;
                          if (original > 0 && price < original && !productForm.discount) {
                            const autoDiscount = Math.round(((original - price) / original) * 100);
                            return <span className="text-xs text-gray-500 mt-1">Auto: {autoDiscount}% OFF</span>;
                          }
                          return null;
                        })()}
                      </div>
                      <div>
                        <label className="text-sm text-gray-400 mb-1 block">Category</label>
                        <Input 
                          value={productForm.category}
                          onChange={(e) => setProductForm(p => ({ ...p, category: e.target.value }))}
                          className="bg-gray-700 border-gray-600 text-white"
                          placeholder="Electronics"
                        />
                      </div>
                      <div>
                        <label className="text-sm text-gray-400 mb-1 block">Brand</label>
                        <Input 
                          value={productForm.brand}
                          onChange={(e) => setProductForm(p => ({ ...p, brand: e.target.value }))}
                          className="bg-gray-700 border-gray-600 text-white"
                          placeholder="Samsung"
                        />
                      </div>
                      <div className="flex items-center gap-3 pt-2">
                        <Switch 
                          id="product-flash-sale"
                          checked={productForm.isFlashDeal}
                          onCheckedChange={(checked) => setProductForm(p => ({ ...p, isFlashDeal: checked }))}
                        />
                        <Label htmlFor="product-flash-sale" className="text-gray-300 cursor-pointer">Flash Sale Product</Label>
                      </div>
                    </div>

                    <div className="border-t border-gray-600 pt-4">
                      <label className="text-sm text-gray-400 mb-2 block">Product Images (4 photos)</label>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {['imageUrl', 'image2', 'image3', 'image4'].map((key, idx) => (
                          <div key={key} className="space-y-1">
                            <span className="text-xs text-gray-500">Image {idx + 1}{idx === 0 ? ' (Main)' : ''}</span>
                            <Input 
                              value={productForm[key as keyof typeof productForm]}
                              onChange={(e) => setProductForm(p => ({ ...p, [key]: e.target.value }))}
                              className="bg-gray-700 border-gray-600 text-white text-sm"
                              placeholder="https://..."
                            />
                            {productForm[key as keyof typeof productForm] && (
                              <img 
                                src={productForm[key as keyof typeof productForm]} 
                                alt="" 
                                className="w-full h-20 object-cover rounded bg-gray-600"
                                onError={(e) => (e.currentTarget.style.display = 'none')}
                              />
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="border-t border-gray-600 pt-4">
                      <label className="text-sm text-gray-400 mb-1 block">Review</label>
                      <Textarea 
                        value={productForm.review}
                        onChange={(e) => setProductForm(p => ({ ...p, review: e.target.value }))}
                        className="bg-gray-700 border-gray-600 text-white"
                        placeholder="Customer review or product summary..."
                        rows={3}
                      />
                    </div>

                    <div className="border-t border-gray-600 pt-4">
                      <label className="text-sm text-gray-400 mb-1 block">Highlights (each line = one bullet point)</label>
                      <Textarea 
                        value={productForm.highlights}
                        onChange={(e) => setProductForm(p => ({ ...p, highlights: e.target.value }))}
                        className="bg-gray-700 border-gray-600 text-white"
                        placeholder="Feature 1&#10;Feature 2&#10;Feature 3"
                        rows={4}
                      />
                    </div>

                    <div className="border-t border-gray-600 pt-4">
                      <label className="text-sm text-gray-400 mb-1 block">Description</label>
                      <Textarea 
                        value={productForm.description}
                        onChange={(e) => setProductForm(p => ({ ...p, description: e.target.value }))}
                        className="bg-gray-700 border-gray-600 text-white"
                        placeholder="Product description..."
                        rows={3}
                      />
                    </div>

                    <div className="flex gap-2 pt-4 border-t border-gray-600">
                      <Button variant="ghost" onClick={handleCancelProductForm}>Cancel</Button>
                      <Button 
                        onClick={handleSaveProduct} 
                        disabled={addProductMutation.isPending || updateProductMutation.isPending}
                        data-testid="button-save-product"
                      >
                        {(addProductMutation.isPending || updateProductMutation.isPending) ? (
                          <RefreshCw className="w-4 h-4 animate-spin mr-2" />
                        ) : (
                          <Save className="w-4 h-4 mr-2" />
                        )}
                        {editingProductId ? 'Update Product' : 'Save Product'}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Dialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Delete Script?</DialogTitle>
          </DialogHeader>
          <p className="text-gray-300">Are you sure you want to delete "{script.name}"? All products in this script will also be deleted. This cannot be undone.</p>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowDeleteConfirm(false)}>Cancel</Button>
            <Button 
              variant="destructive" 
              onClick={() => deleteScriptMutation.mutate()}
              disabled={deleteScriptMutation.isPending}
            >
              {deleteScriptMutation.isPending ? 'Deleting...' : 'Delete Script'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deletingProductId} onOpenChange={(open) => !open && setDeletingProductId(null)}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Delete Product?</DialogTitle>
          </DialogHeader>
          <p className="text-gray-300">Are you sure you want to delete this product? This cannot be undone.</p>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setDeletingProductId(null)}>Cancel</Button>
            <Button 
              variant="destructive" 
              onClick={() => {
                if (deletingProductId) deleteProductMutation.mutate(deletingProductId);
                setDeletingProductId(null);
              }}
            >
              Delete Product
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
