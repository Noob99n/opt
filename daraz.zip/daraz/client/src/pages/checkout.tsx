import { useLocation } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { X, CreditCard, Smartphone, Wallet, Info, ChevronRight, Shield, Lock } from 'lucide-react';
import { useState, useEffect } from 'react';

interface CartItem {
  id: string;
  title: string;
  price: string;
  originalPrice?: string;
  imageUrl?: string;
  quantity: number;
  brand?: string;
}

interface PaymentMethod {
  id: string;
  name: string;
  subtitle: string;
  icon: 'credit-card' | 'qr' | 'esewa' | 'cash';
  iconBg: string;
  iconColor: string;
  recommended?: boolean;
  disabled?: boolean;
  disabledMessage?: string;
  comingSoon?: boolean;
}

export default function Checkout() {
  const [location, setLocation] = useLocation();
  const [selectedPayment, setSelectedPayment] = useState<string>('');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  
  // Detect tenant slug from URL
  const getTenantSlug = (): string | null => {
    const match = location.match(/^\/store\/([^/]+)/);
    return match ? match[1] : null;
  };
  
  const tenantSlug = getTenantSlug();
  
  // Load cart from localStorage
  useEffect(() => {
    try {
      // Use tenant-specific cart key if in tenant store
      const cartKey = tenantSlug ? `guest-cart-${tenantSlug}` : 'guest-cart';
      const cartData = localStorage.getItem(cartKey);
      
      if (cartData) {
        const items = JSON.parse(cartData);
        
        const cartItemsFormatted = items.map((item: any) => {
          // Handle both nested product object and flat structure
          const productData = item.product || item;
          return {
            id: productData?.id || productData?._id || item.productId,
            title: productData?.title || item.title || '',
            price: productData?.price || item.price || '0',
            originalPrice: productData?.originalPrice || item.originalPrice,
            imageUrl: productData?.imageUrl || item.imageUrl,
            quantity: item.quantity || 1,
            brand: productData?.brand || item.brand
          };
        });
        
        setCartItems(cartItemsFormatted);
      }
    } catch (error) {
      console.error('Error loading cart:', error);
    }
  }, [tenantSlug]);
  
  // Calculate item price (original price)
  const itemPrice = cartItems.reduce((sum, item) => {
    const original = item.originalPrice ? parseFloat(item.originalPrice) : parseFloat(item.price);
    return sum + (original * item.quantity);
  }, 0);
  
  // Calculate current price after discount
  const currentPrice = cartItems.reduce((sum, item) => sum + (parseFloat(item.price) * item.quantity), 0);
  
  // Calculate discount amount and percentage
  const discountAmount = itemPrice - currentPrice;
  const discountPercentage = itemPrice > 0 ? Math.round((discountAmount / itemPrice) * 100) : 0;
  
  // Delivery charge
  const deliveryCharge = 75;
  
  // Calculate total (current price + delivery)
  const totalAmount = currentPrice + deliveryCharge;

  const paymentMethods: PaymentMethod[] = [
    {
      id: 'credit-card',
      name: 'Credit/Debit Card',
      subtitle: 'Credit/Debit Card',
      icon: 'credit-card',
      iconBg: 'bg-blue-100',
      iconColor: 'text-blue-600',
      recommended: true,
      comingSoon: true,
    },
    {
      id: 'pay-on-qr',
      name: 'Pay on QR',
      subtitle: 'Scan & Pay with any app',
      icon: 'qr',
      iconBg: 'bg-purple-50',
      iconColor: 'text-purple-600',
    },
    {
      id: 'esewa',
      name: 'eSewa Mobile Wallet',
      subtitle: 'Not available for this product',
      icon: 'esewa',
      iconBg: 'bg-green-100',
      iconColor: 'text-green-600',
      disabled: true,
      disabledMessage: 'Not available for this product',
    },
    {
      id: 'cash-on-delivery',
      name: 'Cash on Delivery',
      subtitle: 'Not available for this product',
      icon: 'cash',
      iconBg: 'bg-blue-100',
      iconColor: 'text-blue-600',
      disabled: true,
      disabledMessage: 'Not available for this product',
    },
  ];

  const handlePaymentSelect = (paymentId: string) => {
    const method = paymentMethods.find(m => m.id === paymentId);
    if (method?.disabled || method?.comingSoon) return;
    setSelectedPayment(paymentId);
    console.log('Selected payment method:', paymentId);
    
    // Navigate to QR payment page for QR payment option (tenant-aware)
    if (paymentId === 'pay-on-qr') {
      const qrPath = tenantSlug ? `/store/${tenantSlug}/qr-payment` : '/qr-payment';
      setLocation(qrPath);
    }
  };

  const renderPaymentIcon = (method: PaymentMethod) => {
    switch (method.icon) {
      case 'credit-card':
        return <CreditCard size={24} className={method.iconColor} />;
      case 'qr':
        return (
          <svg className={`w-6 h-6 ${method.iconColor}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <rect x="3" y="3" width="7" height="7" strokeWidth="2" strokeLinecap="round"/>
            <rect x="14" y="3" width="7" height="7" strokeWidth="2" strokeLinecap="round"/>
            <rect x="3" y="14" width="7" height="7" strokeWidth="2" strokeLinecap="round"/>
            <path d="M16 16h2m0 0h2m-2 0v2m0-2v-2" strokeWidth="2" strokeLinecap="round"/>
          </svg>
        );
      case 'esewa':
        return <Smartphone size={24} className={method.iconColor} />;
      case 'cash':
        return <Wallet size={24} className={method.iconColor} />;
      default:
        return <CreditCard size={24} className={method.iconColor} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-32">
      {/* Header */}
      <div className="bg-white px-4 py-4 shadow-sm flex items-center justify-between sticky top-0 z-50">
        <h1 className="text-lg font-semibold text-gray-900">Select Payment Method</h1>
        <button 
          onClick={() => setLocation('/')} 
          className="text-gray-600 hover:text-gray-900"
          data-testid="button-close-payment"
        >
          <X size={24} />
        </button>
      </div>

      {/* Info Banner */}
      <div className="bg-blue-50 border-l-4 border-blue-500 px-4 py-3 mx-4 mt-4 rounded">
        <div className="flex items-start gap-3">
          <Info size={20} className="text-blue-600 mt-0.5 flex-shrink-0" />
          <p className="text-sm text-blue-800 leading-relaxed">
            Ensure you have collected the payment voucher to get Bank and Wallet Discounts. 0% EMI available on selected bank partners.
          </p>
        </div>
      </div>

      {/* Recommended Payment Methods */}
      <div className="px-4 mt-6">
        <h3 className="text-base font-semibold text-gray-900 mb-4">Recommended method(s)</h3>
        
        {paymentMethods
          .filter(method => method.recommended)
          .map((method) => (
            <Card 
              key={method.id} 
              className="mb-3 relative overflow-hidden border border-gray-200"
              data-testid={`payment-method-${method.id}`}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-14 h-14 ${method.iconBg} rounded-lg flex items-center justify-center flex-shrink-0`}>
                      {renderPaymentIcon(method)}
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900 text-base">{method.name}</div>
                      <div className="text-sm text-gray-600 mt-0.5">{method.subtitle}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0 ml-4">
                    <div className="w-10 h-7 bg-red-600 rounded flex items-center justify-center">
                      <span className="text-white text-xs font-bold">MC</span>
                    </div>
                    <div className="w-10 h-7 bg-blue-600 rounded flex items-center justify-center">
                      <span className="text-white text-xs font-bold">V</span>
                    </div>
                  </div>
                </div>
              </CardContent>
              
              {/* Half Blur Overlay for Coming Soon */}
              {method.comingSoon && (
                <div className="absolute inset-0 bg-white/60 backdrop-blur-sm flex items-center justify-center">
                  <span className="text-sm font-semibold text-gray-700 bg-white px-4 py-1.5 rounded-full border border-gray-300 shadow-sm">
                    Coming soon
                  </span>
                </div>
              )}
            </Card>
          ))}
      </div>

      {/* Other Payment Methods */}
      <div className="px-4 mt-6">
        <h3 className="text-base font-semibold text-gray-900 mb-4">Other Payment Methods</h3>
        
        <div className="space-y-3">
          {paymentMethods
            .filter(method => !method.recommended)
            .map((method) => (
              <Card 
                key={method.id} 
                className={`border border-gray-200 ${method.disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:shadow-md transition-shadow'}`}
                onClick={() => !method.disabled && handlePaymentSelect(method.id)}
                data-testid={`payment-method-${method.id}`}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`w-14 h-14 ${method.iconBg} rounded-lg flex items-center justify-center flex-shrink-0`}>
                        {renderPaymentIcon(method)}
                      </div>
                      <div>
                        <div className="font-semibold text-gray-900 text-base">{method.name}</div>
                        <div className={`text-sm mt-0.5 ${method.disabled ? 'text-red-600' : 'text-gray-600'}`}>
                          {method.subtitle}
                        </div>
                      </div>
                    </div>
                    {method.disabled ? (
                      <svg className="w-5 h-5 text-gray-300 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    ) : (
                      <ChevronRight size={20} className="text-gray-400 flex-shrink-0" />
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
        </div>
      </div>

      {/* Security Badges */}
      <div className="px-4 mt-8 mb-6">
        <div className="flex items-center justify-center gap-4 flex-wrap opacity-50">
          <div className="flex items-center gap-1">
            <Shield size={14} className="text-gray-500" />
            <span className="text-xs text-gray-500 font-medium">Norton</span>
          </div>
          <div className="flex items-center gap-1">
            <Lock size={14} className="text-gray-500" />
            <span className="text-xs text-gray-500 font-medium">McAfee Secure</span>
          </div>
          <div className="flex items-center gap-1">
            <Shield size={14} className="text-gray-500" />
            <span className="text-xs text-gray-500 font-medium">PCI DSS</span>
          </div>
        </div>
      </div>

      {/* Price Summary */}
      <div className="fixed bottom-16 left-0 right-0 bg-white border-t border-gray-200 px-4 py-3 shadow-lg">
        <div className="max-w-md mx-auto space-y-2">
          {/* Item Price (Original) */}
          <div className="flex justify-between items-center text-sm">
            <span className="text-gray-600">Item</span>
            <span className="font-medium text-gray-900" data-testid="text-item-price">Rs. {itemPrice.toLocaleString()}</span>
          </div>
          
          {/* Sale Offer Discount (if applicable) */}
          {discountAmount > 0 && (
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-600">Sale Offer ({discountPercentage}% OFF)</span>
              <span className="font-medium text-green-600" data-testid="text-discount">- Rs. {discountAmount.toLocaleString()}</span>
            </div>
          )}
          
          {/* Delivery Charge */}
          <div className="flex justify-between items-center text-sm">
            <span className="text-gray-600">Delivery Charge</span>
            <span className="font-medium text-gray-900" data-testid="text-delivery">Rs. {deliveryCharge.toLocaleString()}</span>
          </div>
          
          {/* Total Amount */}
          <div className="flex justify-between items-center pt-2 border-t border-gray-200">
            <span className="text-base font-semibold text-gray-900">Total Amount</span>
            <span className="text-lg font-bold text-orange-600" data-testid="text-total-amount">Rs. {totalAmount.toLocaleString()}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
