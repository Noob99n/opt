import { useLocation } from 'wouter';
import { SearchBar } from '@/components/layout/search-bar';
import { FlashSaleBanner } from '@/components/product/flash-sale-banner';
import categoryGrid from '@assets/image_1751707197982.png';

export default function HomeSimple() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen pb-20" style={{ backgroundColor: '#f1f3f6' }}>
      <SearchBar onSearch={() => {}} />
      
      <FlashSaleBanner />

      {/* Category Grid Image */}
      <div className="px-4 mb-6">
        <img 
          src={categoryGrid} 
          alt="Daraz Categories" 
          className="w-full cursor-pointer"
          onClick={() => setLocation('/categories')}
        />
      </div>

      {/* FLASH SALE SECTION - DARAZ STYLE */}
      <div className="mb-6">
        {/* Flash Sale Header */}
        <div className="bg-gradient-to-r from-orange-500 to-red-600 px-4 py-3">
          <div className="flex items-center justify-between text-white">
            <div className="flex items-center gap-2">
              <span className="text-2xl">⚡</span>
              <div>
                <h2 className="text-lg font-bold">Flash Sale</h2>
                <p className="text-xs opacity-90">On Sale Now</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold">72%</div>
              <div className="text-xs">OFF</div>
            </div>
          </div>
        </div>
        
        {/* Flash Sale Products */}
        <div className="bg-white px-4 py-3">
          <div className="grid grid-cols-3 gap-3">
            <div className="relative">
              <img src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&h=300&fit=crop" 
                   className="w-full h-20 object-cover rounded-lg mb-2" 
                   alt="Atowak Watch" />
              <div className="absolute top-1 left-1 bg-red-500 text-white text-xs px-1 py-0.5 rounded">
                44% OFF
              </div>
            </div>
            <h4 className="text-xs font-semibold text-gray-800 mb-1 line-clamp-2">Atowak Cobra Luxury</h4>
            <div className="flex items-center justify-between">
              <span className="text-red-600 font-bold text-sm">₹2,500</span>
              <span className="text-gray-400 line-through text-xs">₹4,500</span>
            </div>
          </div>
          <div className="relative">
            <img src="https://images.unsplash.com/photo-1548181048-2aa69ef3ddb0?w=300&h=300&fit=crop" 
                 className="w-full h-20 object-cover rounded-lg mb-2" 
                 alt="Rolex Watch" />
            <div className="absolute top-1 left-1 bg-red-500 text-white text-xs px-1 py-0.5 rounded">
              45% OFF
            </div>
            <h4 className="text-xs font-semibold text-gray-800 mb-1 line-clamp-2">Rolex Submariner Style</h4>
            <div className="flex items-center justify-between">
              <span className="text-red-600 font-bold text-sm">₹3,200</span>
              <span className="text-gray-400 line-through text-xs">₹5,800</span>
            </div>
          </div>
          <div className="relative">
            <img src="https://images.unsplash.com/photo-1594576662903-79f4df9b0f0e?w=300&h=300&fit=crop" 
                 className="w-full h-20 object-cover rounded-lg mb-2" 
                 alt="TAG Heuer Watch" />
            <div className="absolute top-1 left-1 bg-red-500 text-white text-xs px-1 py-0.5 rounded">
              46% OFF
            </div>
            <h4 className="text-xs font-semibold text-gray-800 mb-1 line-clamp-2">TAG Heuer Formula 1</h4>
            <div className="flex items-center justify-between">
              <span className="text-red-600 font-bold text-sm">₹2,800</span>
              <span className="text-gray-400 line-through text-xs">₹5,200</span>
            </div>
          </div>
          <div className="relative">
            <img src="https://images.unsplash.com/photo-1509048191080-d2425f1f4157?w=300&h=300&fit=crop" 
                 className="w-full h-20 object-cover rounded-lg mb-2" 
                 alt="Omega Watch" />
            <div className="absolute top-1 left-1 bg-red-500 text-white text-xs px-1 py-0.5 rounded">
              43% OFF
            </div>
            <h4 className="text-xs font-semibold text-gray-800 mb-1 line-clamp-2">Omega Speedmaster</h4>
            <div className="flex items-center justify-between">
              <span className="text-red-600 font-bold text-sm">₹3,500</span>
              <span className="text-gray-400 line-through text-xs">₹6,200</span>
            </div>
          </div>
          <div className="relative">
            <img src="https://images.unsplash.com/photo-1533139502658-0198f920d8e8?w=300&h=300&fit=crop" 
                 className="w-full h-20 object-cover rounded-lg mb-2" 
                 alt="Breitling Watch" />
            <div className="absolute top-1 left-1 bg-red-500 text-white text-xs px-1 py-0.5 rounded">
              43% OFF
            </div>
            <h4 className="text-xs font-semibold text-gray-800 mb-1 line-clamp-2">Breitling Navitimer Style</h4>
            <div className="flex items-center justify-between">
              <span className="text-red-600 font-bold text-sm">₹2,900</span>
              <span className="text-gray-400 line-through text-xs">₹5,100</span>
            </div>
          </div>
          <div className="relative">
            <img src="https://images.unsplash.com/photo-1606800052052-a08af7148866?w=300&h=300&fit=crop" 
                 className="w-full h-20 object-cover rounded-lg mb-2" 
                 alt="Casio Watch" />
            <div className="absolute top-1 left-1 bg-red-500 text-white text-xs px-1 py-0.5 rounded">
              44% OFF
            </div>
            <h4 className="text-xs font-semibold text-gray-800 mb-1 line-clamp-2">Casio G-Shock Premium</h4>
            <div className="flex items-center justify-between">
              <span className="text-red-600 font-bold text-sm">₹1,800</span>
              <span className="text-gray-400 line-through text-xs">₹3,200</span>
            </div>
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="px-4 mb-6">
        <h2 className="text-xl font-bold text-gray-800 mb-4">Categories</h2>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-lg p-4 text-center">
            <h3 className="font-semibold">Electronics</h3>
          </div>
          <div className="bg-white rounded-lg p-4 text-center">
            <h3 className="font-semibold">Fashion</h3>
          </div>
        </div>
      </div>
    </div>
  );
}