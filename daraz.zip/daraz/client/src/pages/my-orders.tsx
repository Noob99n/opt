import { useState } from 'react';
import { useLocation } from 'wouter';
import { ArrowLeft, Package, Truck, Check, Clock, ChevronRight, Star, MapPin, Phone, HelpCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTenant } from '@/context/TenantContext';

interface DeliveryAddress {
  recipientName?: string;
  phoneNumber?: string;
  region?: string;
  address?: string;
  landmark?: string;
  addressCategory?: string;
}

interface Order {
  id: string;
  productTitle: string;
  productImage?: string;
  amount: number;
  subtotal: number;
  discount: number;
  discountPercentage: number;
  deliveryCharge: number;
  quantity: number;
  status: 'confirmed' | 'processing' | 'shipped' | 'delivered';
  orderDate: Date;
  deliveryDate?: Date;
  trackingId?: string;
  deliveryAddress?: DeliveryAddress;
}

export default function MyOrders() {
  const [, setLocation] = useLocation();
  const { getRoutePath } = useTenant();
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  
  const orderData = JSON.parse(sessionStorage.getItem('lastOrder') || '{}');
  
  const orders: Order[] = [
    {
      id: orderData.orderId || `ORD${Date.now().toString().slice(-8)}`,
      productTitle: orderData.productTitle || 'Apple iPhone 17 Pro Max - 256GB - Natural Titanium',
      productImage: orderData.productImage || '',
      amount: orderData.amount || 249999,
      subtotal: orderData.subtotal || orderData.amount || 249999,
      discount: orderData.discount || 0,
      discountPercentage: orderData.discountPercentage || 0,
      deliveryCharge: orderData.deliveryCharge || 75,
      quantity: orderData.quantity || 1,
      status: 'processing',
      orderDate: new Date(),
      trackingId: `TRK${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
      deliveryAddress: orderData.deliveryAddress || {}
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'text-blue-600 bg-blue-50';
      case 'processing': return 'text-orange-600 bg-orange-50';
      case 'shipped': return 'text-purple-600 bg-purple-50';
      case 'delivered': return 'text-green-600 bg-green-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'confirmed': return <Check className="w-4 h-4" />;
      case 'processing': return <Clock className="w-4 h-4" />;
      case 'shipped': return <Truck className="w-4 h-4" />;
      case 'delivered': return <Package className="w-4 h-4" />;
      default: return <Package className="w-4 h-4" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'confirmed': return 'Order Confirmed';
      case 'processing': return 'Processing';
      case 'shipped': return 'Shipped';
      case 'delivered': return 'Delivered';
      default: return status;
    }
  };

  if (selectedOrder) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="bg-white border-b sticky top-0 z-10">
          <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
            <button onClick={() => setSelectedOrder(null)} className="p-1" data-testid="button-back-orders">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="font-semibold">Order Details</h1>
          </div>
        </div>

        <div className="max-w-lg mx-auto px-4 py-4">
          <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-4">
            <div className="p-4 border-b">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-500">Order ID</span>
                <span className="font-mono font-semibold text-orange-600">{selectedOrder.id}</span>
              </div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-500">Order Date</span>
                <span className="text-sm">{selectedOrder.orderDate.toLocaleDateString('en-IN', {
                  day: 'numeric',
                  month: 'short',
                  year: 'numeric'
                })}</span>
              </div>
              {selectedOrder.trackingId && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Tracking ID</span>
                  <span className="font-mono text-sm text-blue-600">{selectedOrder.trackingId}</span>
                </div>
              )}
            </div>

            <div className="p-4 border-b">
              <div className="flex gap-3">
                {selectedOrder.productImage ? (
                  <img 
                    src={selectedOrder.productImage} 
                    alt={selectedOrder.productTitle}
                    className="w-20 h-20 object-cover rounded-lg"
                  />
                ) : (
                  <div className="w-20 h-20 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg flex items-center justify-center">
                    <Package className="w-10 h-10 text-gray-400" />
                  </div>
                )}
                <div className="flex-1">
                  <p className="font-medium text-gray-900 line-clamp-2 mb-1">{selectedOrder.productTitle}</p>
                  <p className="text-sm text-gray-500">Quantity: {selectedOrder.quantity}</p>
                  <p className="font-bold text-orange-600 text-lg mt-1">Rs. {selectedOrder.amount.toLocaleString()}</p>
                </div>
              </div>
            </div>

            <div className="p-4">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Truck className="w-4 h-4 text-orange-500" />
                Order Timeline
              </h3>
              
              <div className="space-y-4">
                <div className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                      <Check className="w-4 h-4 text-white" />
                    </div>
                    <div className="w-0.5 h-8 bg-green-300" />
                  </div>
                  <div className="flex-1 pb-2">
                    <p className="font-medium text-green-700">Order Placed</p>
                    <p className="text-xs text-gray-500">{selectedOrder.orderDate.toLocaleString('en-IN')}</p>
                    <p className="text-sm text-gray-600 mt-1">Your order has been confirmed</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                      <Check className="w-4 h-4 text-white" />
                    </div>
                    <div className="w-0.5 h-8 bg-orange-300" />
                  </div>
                  <div className="flex-1 pb-2">
                    <p className="font-medium text-green-700">Payment Verified</p>
                    <p className="text-xs text-gray-500">{new Date(selectedOrder.orderDate.getTime() + 60000).toLocaleString('en-IN')}</p>
                    <p className="text-sm text-gray-600 mt-1">Payment has been verified successfully</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full bg-orange-500 flex items-center justify-center animate-pulse">
                      <Clock className="w-4 h-4 text-white" />
                    </div>
                    <div className="w-0.5 h-8 bg-gray-200" />
                  </div>
                  <div className="flex-1 pb-2">
                    <p className="font-medium text-orange-600">Processing</p>
                    <p className="text-xs text-gray-500">In Progress</p>
                    <p className="text-sm text-gray-600 mt-1">Your order is being prepared for shipment</p>
                  </div>
                </div>

                <div className="flex gap-3 opacity-50">
                  <div className="flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                      <Truck className="w-4 h-4 text-gray-400" />
                    </div>
                    <div className="w-0.5 h-8 bg-gray-200" />
                  </div>
                  <div className="flex-1 pb-2">
                    <p className="font-medium text-gray-500">Shipped</p>
                    <p className="text-xs text-gray-400">Pending</p>
                    <p className="text-sm text-gray-400 mt-1">Your package will be handed over to courier</p>
                  </div>
                </div>

                <div className="flex gap-3 opacity-50">
                  <div className="flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                      <MapPin className="w-4 h-4 text-gray-400" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-500">Delivered</p>
                    <p className="text-xs text-gray-400">Expected: 13-15 days</p>
                    <p className="text-sm text-gray-400 mt-1">Package will be delivered to your address</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-4 mb-4">
            <h3 className="font-semibold mb-3">Delivery Address</h3>
            <div className="flex gap-3">
              <MapPin className="w-5 h-5 text-gray-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium">{selectedOrder.deliveryAddress?.addressCategory || 'Home'}</p>
                <p className="text-sm text-gray-600">
                  {selectedOrder.deliveryAddress?.recipientName && `${selectedOrder.deliveryAddress.recipientName}, `}
                  {selectedOrder.deliveryAddress?.address || 'Address not provided'}
                  {selectedOrder.deliveryAddress?.landmark && `, Near ${selectedOrder.deliveryAddress.landmark}`}
                </p>
                <p className="text-sm text-gray-600">
                  {selectedOrder.deliveryAddress?.region || 'Region not specified'}
                </p>
                {selectedOrder.deliveryAddress?.phoneNumber && (
                  <p className="text-sm text-gray-500 flex items-center gap-1 mt-1">
                    <Phone className="w-3 h-3" /> {selectedOrder.deliveryAddress.phoneNumber}
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-4 mb-4">
            <h3 className="font-semibold mb-3">Order Summary</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Item Price</span>
                <span>Rs. {selectedOrder.subtotal.toLocaleString()}</span>
              </div>
              {selectedOrder.discount > 0 && (
                <div className="flex justify-between">
                  <span className="text-gray-500">Sale Offer ({selectedOrder.discountPercentage}% OFF)</span>
                  <span className="text-green-600">- Rs. {selectedOrder.discount.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-gray-500">Delivery Charge</span>
                <span>Rs. {selectedOrder.deliveryCharge}</span>
              </div>
              <div className="border-t pt-2 flex justify-between font-bold">
                <span>Total</span>
                <span className="text-orange-600">Rs. {selectedOrder.amount.toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div className="flex gap-3 mb-8">
            <Button variant="outline" className="flex-1" data-testid="button-need-help">
              <HelpCircle className="w-4 h-4 mr-2" />
              Need Help?
            </Button>
            <Button className="flex-1 bg-orange-500 hover:bg-orange-600" data-testid="button-track-order">
              <Truck className="w-4 h-4 mr-2" />
              Track Order
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => setLocation(getRoutePath('/'))} className="p-1" data-testid="button-back-home">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-semibold">My Orders</h1>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 py-4">
        {orders.length === 0 ? (
          <div className="text-center py-12">
            <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">No orders yet</p>
            <Button 
              className="mt-4 bg-orange-500 hover:bg-orange-600"
              onClick={() => setLocation(getRoutePath('/'))}
              data-testid="button-start-shopping"
            >
              Start Shopping
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order) => (
              <div 
                key={order.id}
                className="bg-white rounded-xl shadow-sm overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => setSelectedOrder(order)}
                data-testid={`order-card-${order.id}`}
              >
                <div className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1 ${getStatusColor(order.status)}`}>
                        {getStatusIcon(order.status)}
                        {getStatusText(order.status)}
                      </span>
                    </div>
                    <span className="text-xs text-gray-500">{order.orderDate.toLocaleDateString('en-IN')}</span>
                  </div>
                  
                  <div className="flex gap-3">
                    {order.productImage ? (
                      <img 
                        src={order.productImage} 
                        alt={order.productTitle}
                        className="w-16 h-16 object-cover rounded-lg flex-shrink-0"
                      />
                    ) : (
                      <div className="w-16 h-16 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Package className="w-8 h-8 text-gray-400" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 line-clamp-2 text-sm">{order.productTitle}</p>
                      <p className="text-xs text-gray-500 mt-1">Qty: {order.quantity}</p>
                      <p className="font-bold text-orange-600 mt-1">Rs. {order.amount.toLocaleString()}</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-400 flex-shrink-0 self-center" />
                  </div>
                </div>
                
                <div className="bg-gray-50 px-4 py-2 flex items-center justify-between text-xs">
                  <span className="text-gray-500">Order ID: <span className="font-mono">{order.id}</span></span>
                  <span className="text-blue-600 font-medium">View Details</span>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-8 p-4 bg-orange-50 rounded-xl">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0">
              <Star className="w-5 h-5 text-orange-500" />
            </div>
            <div>
              <p className="font-medium text-orange-800">Rate your experience</p>
              <p className="text-sm text-orange-600 mt-1">Help us improve by rating your recent orders</p>
              <div className="flex gap-1 mt-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button key={star} className="text-orange-400 hover:text-orange-500" data-testid={`star-${star}`}>
                    <Star className="w-6 h-6" fill={star <= 4 ? 'currentColor' : 'none'} />
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
