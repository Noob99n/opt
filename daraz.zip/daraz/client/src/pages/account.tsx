import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Icon } from '@/components/ui/icon';
import { Badge } from '@/components/ui/badge';

export default function Account() {
  const [, setLocation] = useLocation();

  const menuItems = [
    {
      icon: 'shopping-bag',
      label: 'My Orders',
      description: 'Track and manage your orders',
      action: () => console.log('Navigate to orders'),
    },
    {
      icon: 'heart',
      label: 'Wishlist',
      description: 'Your saved items',
      action: () => console.log('Navigate to wishlist'),
    },
    {
      icon: 'map-pin',
      label: 'Addresses',
      description: 'Manage delivery addresses',
      action: () => setLocation('/address'),
    },
    {
      icon: 'credit-card',
      label: 'Payment Methods',
      description: 'Manage your payment options',
      action: () => setLocation('/payment'),
    },
    {
      icon: 'user',
      label: 'Profile Settings',
      description: 'Update your account information',
      action: () => console.log('Navigate to profile'),
    },
    {
      icon: 'shield',
      label: 'Privacy & Security',
      description: 'Manage your privacy settings',
      action: () => console.log('Navigate to privacy'),
    },
    {
      icon: 'info',
      label: 'Help & Support',
      description: 'Get help and contact support',
      action: () => console.log('Navigate to help'),
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-primary text-white px-4 py-6">
        <div className="flex items-center gap-4">
          <Avatar className="w-16 h-16">
            <AvatarFallback className="bg-white text-primary text-xl font-bold">
              MK
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h1 className="text-xl font-bold">Munna Kumar</h1>
            <p className="text-orange-100">+977 9855595067</p>
            <div className="flex items-center gap-2 mt-2">
              <Badge variant="secondary" className="bg-white/20 text-white">
                Premium Member
              </Badge>
            </div>
          </div>
          <button className="text-white">
            <Icon name="more-vertical" size={20} />
          </button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="px-4 py-4">
        <div className="grid grid-cols-3 gap-4">
          <Card className="shadow-card">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary mb-1">5</div>
              <div className="text-sm text-gray-600">Orders</div>
            </CardContent>
          </Card>
          <Card className="shadow-card">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary mb-1">12</div>
              <div className="text-sm text-gray-600">Wishlist</div>
            </CardContent>
          </Card>
          <Card className="shadow-card">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary mb-1">₹2.5K</div>
              <div className="text-sm text-gray-600">Saved</div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Menu Items */}
      <div className="px-4 space-y-3">
        {menuItems.map((item, index) => (
          <Card key={index} className="shadow-card cursor-pointer hover:shadow-md transition-shadow">
            <CardContent className="p-4" onClick={item.action}>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                  <Icon name={item.icon as any} size={20} className="text-gray-600" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-800">{item.label}</h3>
                  <p className="text-sm text-gray-600">{item.description}</p>
                </div>
                <Icon name="chevron-right" size={16} className="text-gray-400" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Promotional Banner */}
      <div className="px-4 py-4">
        <Card className="bg-gradient-to-r from-purple-600 to-purple-700 text-white overflow-hidden">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h3 className="font-bold text-lg mb-1">Unlock Premium Benefits</h3>
                <p className="text-purple-100 text-sm mb-3">
                  Get free shipping, exclusive deals, and priority support
                </p>
                <Button variant="secondary" size="sm" className="bg-white text-purple-600 hover:bg-gray-100">
                  Upgrade Now
                </Button>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold opacity-20">🎁</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Settings */}
      <div className="px-4 pb-4">
        <Card className="shadow-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Icon name="info" size={20} className="text-gray-600" />
                <div>
                  <h3 className="font-semibold text-gray-800">App Version</h3>
                  <p className="text-sm text-gray-600">v2.1.0</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Logout Button */}
      <div className="px-4 pb-6">
        <Button 
          variant="outline" 
          className="w-full border-red-200 text-red-600 hover:bg-red-50"
          onClick={() => console.log('Logout')}
        >
          <Icon name="x" size={16} className="mr-2" />
          Logout
        </Button>
      </div>
    </div>
  );
}
