import { useEffect, useState } from 'react';
import { useLocation, useParams } from 'wouter';
import { Button } from '@/components/ui/button';
import { useCart } from '@/hooks/use-cart';
import { getProxiedImageUrl } from '@/lib/image-proxy';

export default function ProductSimple() {
  const [, setLocation] = useLocation();
  const { id } = useParams<{ id: string }>();
  const { addToCart } = useCart();
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      // Check if id is numeric (old style) or slug (new style)
      const isNumericId = /^\d+$/.test(id);
      const apiUrl = isNumericId ? `/api/products/${id}` : `/api/products/slug/${id}`;
      
      fetch(apiUrl)
        .then(res => {
          if (!res.ok) {
            // If slug fails, try ID as fallback
            if (!isNumericId) {
              return fetch(`/api/products/${id}`);
            }
            throw new Error('Product not found');
          }
          return res;
        })
        .then(res => res.json())
        .then(data => {
          setProduct(data);
          setLoading(false);
        })
        .catch(err => {
          console.error('Error:', err);
          setLoading(false);
        });
    }
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 pb-20 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-orange-200 border-t-orange-500 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading product...</p>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 pb-20 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Product not found</p>
          <Button onClick={() => setLocation('/')} className="mt-4">
            Go Back
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header - Daraz Style */}
      <div className="bg-white px-4 py-3 shadow-sm flex items-center justify-between">
        <button onClick={() => setLocation('/')} className="text-gray-600 p-1">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="m15 18-6-6 6-6"/>
          </svg>
        </button>
        <div className="flex items-center gap-4">
          <button onClick={() => setLocation('/cart')} className="text-gray-600 p-1">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="8" cy="21" r="1"/>
              <circle cx="19" cy="21" r="1"/>
              <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57L22 5H5.12"/>
            </svg>
          </button>
          <button className="text-gray-600 p-1">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="1"/>
              <circle cx="12" cy="5" r="1"/>
              <circle cx="12" cy="19" r="1"/>
            </svg>
          </button>
        </div>
      </div>

      {/* Product Images - Multiple Images Support */}
      <div className="relative bg-white">
        <div className="w-full h-80 flex items-center justify-center overflow-hidden">
          <img 
            src={getProxiedImageUrl(product.imageUrl || product.imageUrl2 || product.imageUrl3 || product.imageUrl4)} 
            alt={product.title}
            className="w-full h-full object-contain"
            referrerPolicy="no-referrer"
            onError={(e) => {
              e.currentTarget.src = '/placeholder-product.svg';
            }}
          />
        </div>
        
        {/* Image Indicators */}
        {(product.imageUrl2 || product.imageUrl3 || product.imageUrl4) && (
          <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 flex gap-1">
            {[product.imageUrl, product.imageUrl2, product.imageUrl3, product.imageUrl4]
              .filter(Boolean)
              .map((_, index) => (
                <div key={index} className="w-2 h-2 bg-white/60 rounded-full"></div>
              ))
            }
          </div>
        )}
      </div>

      {/* Product Info */}
      <div className="px-4 bg-white py-4">
        <div className="flex items-center justify-between mb-4">
          <div className="text-orange-600 text-3xl font-bold">
            Rs. {parseFloat(product.price).toLocaleString()}
          </div>
          {product.originalPrice && (
            <div className="text-gray-400 line-through text-lg">
              Rs. {parseFloat(product.originalPrice).toLocaleString()}
            </div>
          )}
        </div>
        
        <h1 className="text-lg font-semibold text-gray-800 mb-2">{product.title}</h1>
        
        {product.discount && (
          <div className="mb-4">
            <span className="bg-red-500 text-white px-2 py-1 rounded text-sm font-bold">
              {product.discount}% OFF
            </span>
          </div>
        )}

        {product.description && (
          <div className="mb-4">
            <h3 className="font-semibold mb-2">Description</h3>
            <p className="text-gray-600 text-sm">{product.description}</p>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="fixed bottom-20 left-0 right-0 bg-white border-t p-4">
        <div className="max-w-md mx-auto flex gap-4">
          <Button
            onClick={() => {
              console.log('Adding to cart:', product.id);
              addToCart({ productId: product.id, quantity: 1 });
            }}
            className="flex-1 bg-orange-500 hover:bg-orange-600 text-white"
          >
            Add to Cart
          </Button>
          <Button
            onClick={() => {
              addToCart({ productId: product.id, quantity: 1 });
              setLocation('/checkout');
            }}
            className="flex-1 bg-red-500 hover:bg-red-600 text-white"
          >
            Buy Now
          </Button>
        </div>
      </div>
    </div>
  );
}