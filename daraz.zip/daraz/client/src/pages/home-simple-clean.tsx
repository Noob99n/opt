import { useMemo, useState, useEffect, createContext, useContext } from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { SearchBar } from '@/components/layout/search-bar';
import { BannerCarousel } from '@/components/layout/banner-carousel';
import { useTenant } from '@/context/TenantContext';
import type { ScriptProduct, ScriptProductsResponse } from '@/types/product';
import { Zap, Clock, Star } from 'lucide-react';
import { getProxiedImageUrl } from '@/lib/image-proxy';

// Timer Context for sharing timer state
const TimerContext = createContext({ minutes: 10, seconds: 0 });

// Helper function to safely convert price to number
const toPrice = (value: string | number | undefined): number => {
  if (value === undefined) return 0;
  return typeof value === 'number' ? value : parseFloat(value);
};

// Function to get larger image URL (double size)
const getLargerImageUrl = (url: string): string => {
  if (!url) return url;
  
  // Cloudinary - add width transformation for 2x size
  if (url.includes('cloudinary.com')) {
    return url.replace('/upload/', '/upload/w_800,h_800,c_fit/');
  }
  
  // Apple CDN - increase size parameter
  if (url.includes('apple.com')) {
    return url
      .replace(/wid=\d+/, 'wid=800')
      .replace(/hei=\d+/, 'hei=800')
      .replace(/width=\d+/, 'width=800')
      .replace(/height=\d+/, 'height=800');
  }
  
  // Daraz/Lazada CDN - get high res version
  if (url.includes('lazcdn.com') || url.includes('lzd-img')) {
    return url
      .replace(/_80x80/, '_800x800')
      .replace(/_120x120/, '_800x800')
      .replace(/_200x200/, '_800x800')
      .replace(/_300x300/, '_800x800')
      .replace(/_400x400/, '_800x800');
  }
  
  // Amazon images - increase size
  if (url.includes('amazon') || url.includes('media-amazon')) {
    return url
      .replace(/\._[A-Z]+\d+_/, '._SL800_')
      .replace(/\._SS\d+_/, '._SL800_');
  }
  
  return url;
};

export default function HomeSimpleClean() {
  const [, setLocation] = useLocation();
  const { tenant, getApiPath, getRoutePath } = useTenant();
  
  // 10 minute countdown timer - resets on every page load for urgency effect
  const [offerTimer, setOfferTimer] = useState({ minutes: 10, seconds: 0 });
  
  useEffect(() => {
    const timer = setInterval(() => {
      setOfferTimer(prev => {
        let { minutes, seconds } = prev;
        if (seconds === 0) {
          if (minutes === 0) {
            // Reset to 10 minutes when timer ends
            return { minutes: 10, seconds: 0 };
          }
          minutes--;
          seconds = 59;
        } else {
          seconds--;
        }
        return { minutes, seconds };
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);

  // Fetch flash sale products - ultra fast with aggressive caching
  const flashSaleApiPath = getApiPath('/api/flash-sale');
  const { data: flashSaleProducts = [], isLoading: isLoadingFlash } = useQuery<ScriptProductsResponse>({
    queryKey: [flashSaleApiPath], 
    queryFn: () => fetch(flashSaleApiPath).then(res => res.json())
  });



  return (
    <div className="min-h-screen pb-20">
      {/* Top Section with Light Gray Background */}
      <div style={{ 
        minHeight: '50vh',
        position: 'relative',
        backgroundColor: '#f8f9fa'
      }}>
        
        {/* App Logo Banner with White Background */}
        <div className="bg-white border-b border-gray-100 pt-1 pb-1 px-4">
          <div className="download-banner">
            <img 
              src="https://res.cloudinary.com/djbiyudvw/image/upload/v1752394198/IMG_20250713_104903_jursux.png" 
              alt="Daraz App Logo" 
              className="w-full h-16 object-cover"
              style={{ 
                objectPosition: 'center',
                imageRendering: 'crisp-edges',
                filter: 'contrast(1.1) saturate(1.1)'
              }}
            />
          </div>
        </div>

        <SearchBar onSearch={() => {}} />

        {/* 7 Slide Banners Carousel - Right after search like real Daraz */}
        <div className="px-4 mt-4">
          <BannerCarousel />
        </div>

        {/* Category Grid Image */}
        <div className="px-4">
          <img 
            src="https://res.cloudinary.com/djbiyudvw/image/upload/v1764077993/Picsart_25-11-25_17-33-35-261_a6foo4.png" 
            alt="Daraz Categories" 
            className="w-full cursor-pointer"
            onClick={() => setLocation(getRoutePath('/categories'))}
          />
        </div>
      </div>

      {/* FLASH SALE SECTION - After categories like real Daraz */}
      <div className="mb-6 bg-white rounded-2xl mx-4 shadow-sm overflow-hidden">
        {/* Flash Sale Header - With Hindi text and Timer */}
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="text-red-500 text-[6px] font-bold leading-tight text-center">
              <div>महाबचत</div>
              <div className="ml-2">बजार</div>
            </div>
            <div className="flex items-center">
              <span className="font-bold text-lg">Flas</span>
              <Zap className="w-4 h-4 text-orange-500 fill-orange-500" />
              <span className="font-bold text-lg">h Sale</span>
            </div>
            {/* Timer after Flash Sale text */}
            <div className="bg-red-600 text-white text-xs px-2 py-1 rounded flex items-center gap-1 shadow-sm">
              <Clock className="w-3 h-3" />
              <span className="font-bold">{String(offerTimer.minutes).padStart(2, '0')}:{String(offerTimer.seconds).padStart(2, '0')}</span>
            </div>
          </div>
          <button className="text-orange-500 text-sm font-medium">SHOP MORE ›</button>
        </div>
        
        {/* Flash Sale Products - Horizontal Scroll */}
        <div className="px-4 pb-4">
          {isLoadingFlash ? (
            <div className="flex gap-3 overflow-x-auto scrollbar-hide">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="flex-shrink-0 w-32">
                  <div className="w-full h-24 bg-gray-200 rounded-lg mb-2 animate-pulse"></div>
                  <div className="mb-2">
                    <div className="h-4 bg-gray-200 rounded mb-1 animate-pulse"></div>
                    <div className="h-3 bg-gray-200 rounded animate-pulse"></div>
                  </div>
                  <div className="h-6 bg-gray-200 rounded animate-pulse"></div>
                </div>
              ))}
            </div>
          ) : flashSaleProducts.length > 0 ? (
            <div className="flex gap-3 overflow-x-auto scrollbar-hide">
              {flashSaleProducts.slice(0, 5).map((product: ScriptProduct) => (
                <div key={product._id || product.id} className="flex-shrink-0 w-32" onClick={() => setLocation(getRoutePath(`/product/${product.slug || product._id || product.id}`))}>
                  <div className="cursor-pointer" style={{ height: '96px' }}>
                    <img 
                      src={getProxiedImageUrl(product.imageUrl)} 
                      className="w-full h-full object-contain rounded-lg bg-white" 
                      alt={product.title}
                      loading="eager"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        const target = e.currentTarget;
                        if (!target.dataset.fallback) {
                          target.dataset.fallback = "true";
                          target.src = '/placeholder-product.svg';
                        }
                      }}
                    />
                  </div>
                  <div className="mb-2 bg-white p-1 rounded">
                    <div className="flex items-center gap-1">
                      <span className="text-red-600 font-bold">Rs. {toPrice(product.price).toLocaleString()}</span>
                      <span className="bg-orange-100 text-orange-600 text-[10px] px-1 py-0.5 rounded font-medium">-{product.discount}%</span>
                    </div>
                    {product.originalPrice && (
                      <div className="text-gray-400 line-through text-xs">Rs. {toPrice(product.originalPrice).toLocaleString()}</div>
                    )}
                  </div>
                  <div className="bg-red-500 text-white text-xs px-2 py-1 rounded-full text-center">
                    {(product.stock && product.stock > 100) ? "In Stock" : `${product.stock || 0} left`}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500 bg-white rounded-lg">
              <p>No flash sale products available</p>
              <p className="text-sm">Activate a script from admin panel to show products</p>
            </div>
          )}
        </div>
      </div>

      {/* BANNER IMAGE SECTION */}
      <div className="mb-6 mx-4">
        <img 
          src="https://res.cloudinary.com/djbiyudvw/image/upload/v1752898189/Screenshot_2025_0719_093936_iphiqd.png"
          alt="Promotional Banner"
          className="w-full h-auto rounded-2xl shadow-sm object-cover"
          onError={(e) => {
            e.currentTarget.style.display = 'none';
          }}
        />
      </div>

      {/* REGULAR PRODUCTS SECTION - Like in real Daraz */}
      <div className="mb-6 mx-4">
        <TimerContext.Provider value={offerTimer}>
          <RegularProductsSection />
        </TimerContext.Provider>
      </div>
    </div>
  );
}

// Regular Products Section Component
function RegularProductsSection() {
  const offerTimer = useContext(TimerContext);
  const { getApiPath, getRoutePath } = useTenant();
  const [, setLocation] = useLocation();
  
  const productsApiPath = getApiPath('/api/script-products');
  const { data: products = [], isLoading } = useQuery<ScriptProductsResponse>({
    queryKey: [productsApiPath],
    queryFn: () => fetch(productsApiPath).then(res => res.json())
  });

  // Memoize filtered products to avoid recalculation on every render
  const regularProducts = useMemo(() => 
    products
      .filter((product: ScriptProduct) => product.isFlashDeal === false),
    [products]
  );

  if (isLoading) {
    return (
      <div className="bg-white rounded-2xl p-4 shadow-sm">
        <div className="grid grid-cols-2 gap-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="animate-pulse">
              <div className="bg-gray-200 rounded-lg mb-2" style={{ paddingBottom: '100%' }}></div>
              <div className="bg-gray-200 h-4 rounded mb-1"></div>
              <div className="bg-gray-200 h-4 rounded w-3/4"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (regularProducts.length === 0) {
    return (
      <div className="bg-white rounded-2xl p-6 shadow-sm text-center">
        <p className="text-gray-500">No regular products available</p>
        <p className="text-sm text-gray-400">Add products from admin panel and select 'Regular Products Section'</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
      {/* Products Grid */}
      <div className="p-4">
        <div className="grid grid-cols-2 gap-4">
          {regularProducts.map((product: ScriptProduct) => (
            <div 
              key={product._id || product.id} 
              className="cursor-pointer"
              onClick={() => setLocation(getRoutePath(`/product/${product.slug || product._id || product.id}`))}
            >
              <div className="relative w-full" style={{ paddingBottom: '100%' }}>
                <img 
                  src={getProxiedImageUrl(product.imageUrl)} 
                  className="absolute top-0 left-0 w-full h-full object-contain rounded-lg bg-gray-100"
                  alt={product.title}
                  loading="eager"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (!target.dataset.fallback) {
                      target.dataset.fallback = "true";
                      target.src = '/placeholder-product.svg';
                    }
                  }}
                />
              </div>
              
              <div className="space-y-1">
                <h3 className="text-sm font-medium text-gray-800 line-clamp-2 leading-tight">
                  {product.title}
                </h3>
                
                <div className="flex items-center gap-1 flex-wrap">
                  <span className="text-lg font-bold text-orange-500">
                    Rs. {toPrice(product.price).toLocaleString()}
                  </span>
                  {product.discount > 0 && (
                    <span className="bg-orange-100 text-orange-600 text-[10px] px-1 py-0.5 rounded font-medium">-{product.discount}%</span>
                  )}
                </div>
                {product.originalPrice && toPrice(product.originalPrice) > toPrice(product.price) && (
                  <div className="text-sm text-gray-400 line-through">
                    Rs. {toPrice(product.originalPrice).toLocaleString()}
                  </div>
                )}
                
                {product.rating && toPrice(product.rating) > 0 && (
                  <div className="flex items-center space-x-1">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`w-3 h-3 ${i < Math.floor(toPrice(product.rating)) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                        />
                      ))}
                    </div>
                    <span className="text-xs text-gray-500">
                      ({product.reviewCount || 0})
                    </span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}