export function getProxiedImageUrl(url: string | null | undefined): string {
  if (!url) return '/placeholder-product.svg';
  if (url.startsWith('/') || url.startsWith('data:')) return url;
  return `/api/img-proxy?url=${encodeURIComponent(url)}`;
}
