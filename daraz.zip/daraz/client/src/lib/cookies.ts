// Cookie storage utility for persistent data across sessions

interface CookieOptions {
  expires?: number; // Days until expiry
  path?: string;
  secure?: boolean;
  sameSite?: 'Strict' | 'Lax' | 'None';
}

// Set a cookie
export function setCookie(name: string, value: string, options: CookieOptions = {}): void {
  const { expires = 365, path = '/', secure = false, sameSite = 'Lax' } = options;
  
  const date = new Date();
  date.setTime(date.getTime() + (expires * 24 * 60 * 60 * 1000));
  
  let cookieString = `${encodeURIComponent(name)}=${encodeURIComponent(value)}`;
  cookieString += `; expires=${date.toUTCString()}`;
  cookieString += `; path=${path}`;
  cookieString += `; SameSite=${sameSite}`;
  if (secure) cookieString += '; Secure';
  
  document.cookie = cookieString;
}

// Get a cookie value
export function getCookie(name: string): string | null {
  const nameEQ = encodeURIComponent(name) + '=';
  const cookies = document.cookie.split(';');
  
  for (let cookie of cookies) {
    cookie = cookie.trim();
    if (cookie.indexOf(nameEQ) === 0) {
      return decodeURIComponent(cookie.substring(nameEQ.length));
    }
  }
  return null;
}

// Delete a cookie
export function deleteCookie(name: string, path: string = '/'): void {
  document.cookie = `${encodeURIComponent(name)}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=${path}`;
}

// Check if cookie exists
export function hasCookie(name: string): boolean {
  return getCookie(name) !== null;
}

// Set JSON data as cookie
export function setCookieJSON<T>(name: string, value: T, options: CookieOptions = {}): void {
  setCookie(name, JSON.stringify(value), options);
}

// Get JSON data from cookie
export function getCookieJSON<T>(name: string): T | null {
  const value = getCookie(name);
  if (!value) return null;
  try {
    return JSON.parse(value) as T;
  } catch {
    return null;
  }
}

// Get all cookies as object
export function getAllCookies(): Record<string, string> {
  const cookies: Record<string, string> = {};
  document.cookie.split(';').forEach(cookie => {
    const [name, value] = cookie.trim().split('=');
    if (name && value) {
      cookies[decodeURIComponent(name)] = decodeURIComponent(value);
    }
  });
  return cookies;
}

// Clear all cookies
export function clearAllCookies(): void {
  const cookies = getAllCookies();
  for (const name in cookies) {
    deleteCookie(name);
  }
}

// Storage wrapper that uses cookies with localStorage fallback
export const cookieStore = {
  set: (key: string, value: any, expiresDays: number = 365) => {
    setCookieJSON(key, value, { expires: expiresDays });
  },
  
  get: <T>(key: string): T | null => {
    return getCookieJSON<T>(key);
  },
  
  remove: (key: string) => {
    deleteCookie(key);
  },
  
  has: (key: string): boolean => {
    return hasCookie(key);
  },
  
  clear: () => {
    clearAllCookies();
  }
};

export default cookieStore;
