import { Switch, Route, useLocation, useRoute } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { TenantProvider } from "@/context/TenantContext";

// Pages - keeping eager load for compatibility with wouter
import HomeSimpleClean from "@/pages/home-simple-clean";
import Categories from "@/pages/categories-optimized";
import ProductDetail from "@/pages/product-detail-daraz";
import Cart from "@/pages/cart";
import Checkout from "@/pages/checkout";
import Address from "@/pages/address";
import Payment from "@/pages/payment";
import QRPayment from "@/pages/qr-payment";
import Search from "@/pages/search-optimized";
import Account from "@/pages/account";
import Owner from "@/pages/owner";
import AdminPanel from "@/pages/admin-panel";
import OrderSuccess from "@/pages/order-success";
import MyOrders from "@/pages/my-orders";
// TenantHome replaced by HomeSimpleClean which is now tenant-aware
import NotFound from "@/pages/not-found";

function TenantWrapper({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const slugMatch = location.match(/^\/store\/([^\/]+)/);
  const slug = slugMatch ? slugMatch[1] : '';
  
  return <TenantProvider slug={slug}>{children}</TenantProvider>;
}

function TenantProductDetail() {
  return <TenantWrapper><ProductDetail /></TenantWrapper>;
}

function TenantCategories() {
  return <TenantWrapper><Categories /></TenantWrapper>;
}

function TenantCart() {
  return <TenantWrapper><Cart /></TenantWrapper>;
}

function TenantCheckout() {
  return <TenantWrapper><Checkout /></TenantWrapper>;
}

function TenantAddress() {
  return <TenantWrapper><Address /></TenantWrapper>;
}

function TenantPayment() {
  return <TenantWrapper><Payment /></TenantWrapper>;
}

function TenantQRPayment() {
  return <TenantWrapper><QRPayment /></TenantWrapper>;
}

function TenantSearch() {
  return <TenantWrapper><Search /></TenantWrapper>;
}

function TenantAccount() {
  return <TenantWrapper><Account /></TenantWrapper>;
}

function TenantOrderSuccess() {
  return <TenantWrapper><OrderSuccess /></TenantWrapper>;
}

function TenantMyOrders() {
  return <TenantWrapper><MyOrders /></TenantWrapper>;
}

function TenantHomeWrapper() {
  return <TenantWrapper><HomeSimpleClean /></TenantWrapper>;
}

function Router() {
  const [location] = useLocation();
  const isTenantStore = location.startsWith('/store/');
  
  // Hide bottom navigation on specific pages
  const showBottomNav = !location.startsWith('/product') && 
                        !location.startsWith('/address') && 
                        !location.startsWith('/checkout') && 
                        !location.startsWith('/payment') &&
                        !location.startsWith('/qr-payment') &&
                        !location.startsWith('/owner') &&
                        !location.startsWith('/admin') &&
                        !(isTenantStore && (
                          location.includes('/product/') ||
                          location.includes('/address') ||
                          location.includes('/checkout') ||
                          location.includes('/payment') ||
                          location.includes('/qr-payment')
                        ));

  return (
    <div className="mobile-container">
      <Switch>
        {/* Main site routes */}
        <Route path="/" component={HomeSimpleClean} />
        <Route path="/categories" component={Categories} />
        <Route path="/product/:id" component={ProductDetail} />
        <Route path="/product/:slug" component={ProductDetail} />
        <Route path="/cart" component={Cart} />
        <Route path="/checkout" component={Checkout} />
        <Route path="/address" component={Address} />
        <Route path="/payment" component={Payment} />
        <Route path="/qr-payment" component={QRPayment} />
        <Route path="/order-success" component={OrderSuccess} />
        <Route path="/my-orders" component={MyOrders} />
        <Route path="/search" component={Search} />
        <Route path="/account" component={Account} />
        <Route path="/owner" component={Owner} />
        <Route path="/admin" component={AdminPanel} />
        
        {/* Tenant store routes - order matters: more specific first */}
        <Route path="/store/:slug/product/:id" component={TenantProductDetail} />
        <Route path="/store/:slug/categories" component={TenantCategories} />
        <Route path="/store/:slug/cart" component={TenantCart} />
        <Route path="/store/:slug/checkout" component={TenantCheckout} />
        <Route path="/store/:slug/address" component={TenantAddress} />
        <Route path="/store/:slug/payment" component={TenantPayment} />
        <Route path="/store/:slug/qr-payment" component={TenantQRPayment} />
        <Route path="/store/:slug/order-success" component={TenantOrderSuccess} />
        <Route path="/store/:slug/my-orders" component={TenantMyOrders} />
        <Route path="/store/:slug/search" component={TenantSearch} />
        <Route path="/store/:slug/account" component={TenantAccount} />
        <Route path="/store/:slug" component={TenantHomeWrapper} />
        
        <Route component={NotFound} />
      </Switch>
      {showBottomNav && <BottomNavigation />}
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
