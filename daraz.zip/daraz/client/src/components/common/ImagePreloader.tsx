import { useEffect } from 'react';

// Preload critical images for faster loading
const CRITICAL_IMAGES = [
  '/api/placeholder/200/200',
  // Add other common image URLs
];

export const ImagePreloader = () => {
  useEffect(() => {
    // Preload critical images
    CRITICAL_IMAGES.forEach(src => {
      const img = new Image();
      img.src = src;
    });
  }, []);

  return null;
};

// Optimized image component with lazy loading
interface OptimizedImageProps {
  src: string;
  alt: string;
  className?: string;
  loading?: 'lazy' | 'eager';
}

export const OptimizedImage = ({ src, alt, className, loading = 'lazy' }: OptimizedImageProps) => {
  return (
    <img 
      src={src} 
      alt={alt} 
      className={className}
      loading={loading}
      decoding="async"
      style={{ contentVisibility: 'auto' }}
    />
  );
};