export function FlashSaleBanner() {
  return (
    <div className="bg-gradient-to-r from-red-500 to-orange-500 text-white px-4 py-2">
      <div className="flex items-center justify-between">
        <span className="font-bold">⚡ Flash Sale</span>
        <span className="text-sm">Limited Time Offer!</span>
      </div>
    </div>
  );
}