import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Icon } from '@/components/ui/icon';
import { Product } from '@shared/schema';

interface ProductCardProps {
  product: Product;
  onProductClick?: (product: Product) => void;
  onAddToCart?: (productId: number) => void;
  variant?: 'default' | 'grid' | 'list';
}

export function ProductCard({ 
  product, 
  onProductClick, 
  onAddToCart,
  variant = 'default' 
}: ProductCardProps) {
  const discount = product.discount || 0;
  const hasDiscount = discount > 0;
  
  const handleClick = () => {
    onProductClick?.(product);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart?.(product.id);
  };

  if (variant === 'grid') {
    return (
      <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={handleClick}>
        <CardContent className="p-3">
          <div className="mb-3">
            {product.imageUrl?.startsWith('http') ? (
              <img 
                src={product.imageUrl} 
                alt={product.title}
                className="w-full h-32 object-cover rounded-lg"
              />
            ) : (
              <div className="w-full h-24 bg-gray-100 rounded-lg flex items-center justify-center">
                <Icon name="smartphone" className="text-gray-400" size={32} />
              </div>
            )}
          </div>
          
          <div className="space-y-1">
            <h4 className="text-xs font-medium text-gray-800 line-clamp-2 min-h-[2rem]">
              {product.title}
            </h4>
            <div className="flex items-center gap-1">
              <span className="text-primary font-bold text-sm">
                Rs. {parseFloat(product.price).toLocaleString()}
              </span>
              {hasDiscount && (
                <span className="bg-orange-100 text-orange-600 text-[10px] px-1 py-0.5 rounded font-medium">-{discount}%</span>
              )}
            </div>
            {product.originalPrice && (
              <div className="text-gray-400 text-xs line-through">
                Rs. {parseFloat(product.originalPrice).toLocaleString()}
              </div>
            )}
            {product.isFlashSale && (
              <div className="bg-pink-100 text-pink-600 text-xs px-2 py-1 rounded-full text-center">
                {product.sold} sold
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={handleClick}>
      <CardContent className="p-4">
        <div className="flex gap-3">
          <div>
            <div className="w-20 h-20 bg-gray-100 rounded-lg flex items-center justify-center">
              <Icon name="smartphone" className="text-gray-400" size={24} />
            </div>
          </div>
          
          <div className="flex-1">
            <h3 className="font-medium text-gray-800 mb-1 line-clamp-2">
              {product.title}
            </h3>
            {product.brand && (
              <div className="text-gray-500 text-sm mb-2">{product.brand}</div>
            )}
            
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-1">
                  <span className="text-primary font-bold text-lg">
                    Rs. {parseFloat(product.price).toLocaleString()}
                  </span>
                  {hasDiscount && (
                    <span className="bg-orange-100 text-orange-600 text-[10px] px-1 py-0.5 rounded font-medium">-{discount}%</span>
                  )}
                </div>
                {product.originalPrice && (
                  <div className="text-gray-400 text-sm line-through">
                    Rs. {parseFloat(product.originalPrice).toLocaleString()}
                  </div>
                )}
              </div>
              
              <div className="flex items-center gap-2">
                <div className="flex items-center">
                  <Icon name="star" className="text-yellow-400 fill-current" size={16} />
                  <span className="text-sm text-gray-600 ml-1">
                    {product.rating} ({product.reviewCount})
                  </span>
                </div>
                
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleAddToCart}
                  className="btn-orange"
                >
                  <Icon name="plus" size={16} />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
