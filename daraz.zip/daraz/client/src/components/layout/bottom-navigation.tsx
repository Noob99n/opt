import { useLocation } from 'wouter';
import { useCart } from '@/hooks/use-cart';
import { Icon } from '@/components/ui/icon';
import { Badge } from '@/components/ui/badge';
// Using updated Cloudinary images for navigation icons
const homeIcon = 'https://res.cloudinary.com/djbiyudvw/image/upload/v1752391344/5_6312329571123336925_z1pkin.jpg';
const categoriesIcon = 'https://res.cloudinary.com/djbiyudvw/image/upload/v1752391387/5_6312329571123336926_g0oq7t.jpg';
const cartIcon = 'https://res.cloudinary.com/djbiyudvw/image/upload/v1752391422/5_6312329571123336927_euvcse.jpg';
const accountIcon = 'https://res.cloudinary.com/djbiyudvw/image/upload/v1752391443/5_6312329571123336928_sqvrvj.jpg';

export function BottomNavigation() {
  const [location, setLocation] = useLocation();
  const { cartCount } = useCart();

  const navItems = [
    { path: '/', icon: 'home', label: 'Home' },
    { path: '/categories', icon: 'grid', label: 'Categories' },
    { path: '/cart', icon: 'shopping-cart', label: 'Cart' },
    { path: '/account', icon: 'user', label: 'Account' },
  ];

  const isActive = (path: string) => {
    if (path === '/') return location === '/';
    return location.startsWith(path);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white z-50 -mb-1">
      <div className="max-w-md mx-auto -my-1">
        <div className="flex">
          {navItems.map((item) => (
            <button
              key={item.path}
              onClick={() => {
                // Only Home button works, others are disabled
                if (item.path === '/') {
                  setLocation(item.path);
                }
              }}
              className={`flex-1 flex flex-col items-center justify-center py-1 px-1 relative ${
                isActive(item.path) ? 'text-primary' : 'text-gray-400'
              }`}
            >
              {(() => {
                let iconSrc;
                switch (item.icon) {
                  case 'home':
                    iconSrc = homeIcon;
                    break;
                  case 'grid':
                    iconSrc = categoriesIcon;
                    break;
                  case 'shopping-cart':
                    iconSrc = cartIcon;
                    break;
                  case 'user':
                    iconSrc = accountIcon;
                    break;
                  default:
                    iconSrc = null;
                }
                
                return iconSrc ? (
                  <img 
                    src={iconSrc} 
                    alt={item.label} 
                    className={`${item.icon === 'grid' ? 'w-[62px] h-[62px]' : 'w-14 h-14'} navigation-icon mb-1 ${isActive(item.path) ? 'opacity-100' : 'opacity-70'}`}
                  />
                ) : (
                  <>
                    <Icon name={item.icon as any} size={24} className="mb-1" />
                    <span className="text-xs font-medium">{item.label}</span>
                  </>
                );
              })()}

            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
