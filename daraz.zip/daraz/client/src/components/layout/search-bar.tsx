import { useState, useEffect } from 'react';
import { Search } from 'lucide-react';

interface SearchBarProps {
  onSearch: (query: string) => void;
  placeholder?: string;
  className?: string;
}

const searchKeywords = [
  "mobile phones", "laptops", "shoes", "clothing", "headphones", "watches", 
  "cameras", "books", "makeup", "skincare", "bags", "jewelry", "electronics",
  "home decor", "furniture", "kitchen items", "sports equipment", "toys",
  "gaming", "fitness", "beauty products", "perfumes", "sunglasses", "speakers",
  "tablets", "smartwatch", "earbuds", "fashion", "accessories", "gadgets"
];

export function SearchBar({ onSearch, placeholder = "Search for products, brands and more", className = "" }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [currentPlaceholder, setCurrentPlaceholder] = useState('');
  const [keywordIndex, setKeywordIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const [isTyping, setIsTyping] = useState(true);

  const handleSearch = () => {
    onSearch(query);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  useEffect(() => {
    const currentKeyword = searchKeywords[keywordIndex];
    
    const timer = setTimeout(() => {
      if (isTyping) {
        if (charIndex < currentKeyword.length) {
          setCurrentPlaceholder(currentKeyword.slice(0, charIndex + 1));
          setCharIndex(charIndex + 1);
        } else {
          // Wait 3 seconds then start erasing
          setTimeout(() => {
            setIsTyping(false);
          }, 3000);
        }
      } else {
        if (charIndex > 0) {
          setCurrentPlaceholder(currentKeyword.slice(0, charIndex - 1));
          setCharIndex(charIndex - 1);
        } else {
          // Move to next keyword
          setKeywordIndex((keywordIndex + 1) % searchKeywords.length);
          setIsTyping(true);
        }
      }
    }, isTyping ? 100 : 50); // Typing speed: 100ms, Erasing speed: 50ms

    return () => clearTimeout(timer);
  }, [charIndex, keywordIndex, isTyping]);

  return (
    <div className={`bg-white px-4 py-1.5 ${className}`}>
      <div className="flex items-center gap-1 bg-gray-50 rounded-2xl border border-gray-200 p-1">
        <div className="flex items-center flex-1 px-3 py-1">
          <Search size={16} className="text-gray-400 mr-2" />
          <input
            type="text"
            placeholder={query ? placeholder : currentPlaceholder}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyPress={handleKeyPress}
            className="w-full bg-transparent focus:outline-none text-gray-700 placeholder-gray-400 text-sm"
          />
        </div>
        <button
          onClick={handleSearch}
          className="bg-orange-500 hover:bg-orange-600 text-white px-3 py-1 rounded-xl text-sm font-medium transition-colors mr-1"
        >
          Search
        </button>
      </div>
    </div>
  );
}