import { useState, useEffect } from 'react';
import { 
  Carousel, 
  CarouselContent, 
  CarouselItem, 
  CarouselNext, 
  CarouselPrevious,
  type CarouselApi
} from '@/components/ui/carousel';

interface Banner {
  id: number;
  imageUrl: string;
  title: string;
  link?: string;
}

export function BannerCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [api, setApi] = useState<CarouselApi>();

  // 7 Slide Banners - Real banner images
  const banners: Banner[] = [
    {
      id: 1,
      imageUrl: "https://res.cloudinary.com/djbiyudvw/image/upload/v1755102091/a9a4dd322b9233f7f40daed5fe0b7109.jpg_2200x2200q80.jpg__cedh6h.webp",
      title: "Banner 1",
      link: "/categories/home"
    },
    {
      id: 2, 
      imageUrl: "https://res.cloudinary.com/djbiyudvw/image/upload/v1755102091/d06095e470fd299d15f888799c0d8db6.png_2200x2200q80.png__waxu2l.webp",
      title: "Banner 2", 
      link: "/categories/electronics"
    },
    {
      id: 3,
      imageUrl: "https://res.cloudinary.com/djbiyudvw/image/upload/v1755102091/cfbe1cd5aefc93c50648d60ad4150a14.png_2200x2200q80.png__nisl3e.webp", 
      title: "Banner 3",
      link: "/categories/brands"
    },
    {
      id: 4,
      imageUrl: "https://res.cloudinary.com/djbiyudvw/image/upload/v1755102091/f8f6c1df13c26f64431ef7058839f9f6.jpg_2200x2200q80.jpg__dfsiyl.webp",
      title: "Banner 4",
      link: "/flash-sale"
    },
    {
      id: 5,
      imageUrl: "https://res.cloudinary.com/djbiyudvw/image/upload/v1755102092/b2f2a11836d9d970a2d3490834af58e0.png_2200x2200q80.png__icqwzz.webp", 
      title: "Banner 5", 
      link: "/categories/banking"
    },
    {
      id: 6,
      imageUrl: "https://res.cloudinary.com/djbiyudvw/image/upload/v1755102092/256dd69ececbfc373287f4519fbf14ef.png_2200x2200q80.png__tfgpxh.webp",
      title: "Banner 6",
      link: "/categories/mega-deals"
    },
    {
      id: 7,
      imageUrl: "https://res.cloudinary.com/djbiyudvw/image/upload/v1755102092/32a30c86d3aa48266133e7a5a7bab615.png_2200x2200q80.png__l05wpj.webp",
      title: "Banner 7",
      link: "/flash-sale"
    }
  ];

  // Auto-slide functionality - Every 4 seconds with smooth animation
  useEffect(() => {
    if (!api) return;

    const interval = setInterval(() => {
      api.scrollNext();
    }, 4000); // Change slide every 4 seconds

    return () => clearInterval(interval);
  }, [api]);

  // Track current slide and handle user interaction
  useEffect(() => {
    if (!api) return;

    const handleSelect = () => {
      setCurrentSlide(api.selectedScrollSnap());
    };

    api.on("select", handleSelect);
    
    return () => {
      api.off("select", handleSelect);
    };
  }, [api]);

  return (
    <div className="relative w-full mb-4 group rounded-xl overflow-hidden">
      <Carousel 
        className="w-full" 
        setApi={setApi} 
        opts={{ 
          loop: true,
          align: "start",
          skipSnaps: false,
          dragFree: false
        }}
      >
        <CarouselContent className="-ml-2 md:-ml-4">
          {banners.map((banner, index) => (
            <CarouselItem key={banner.id} className="pl-2 md:pl-4">
              <div className="relative w-full bg-white">
                <img
                  src={banner.imageUrl}
                  alt={banner.title}
                  className="w-full h-auto"
                  style={{
                    aspectRatio: 'auto',
                    objectFit: 'cover',
                    width: '100%',
                    maxHeight: '140px'
                  }}
                  onError={(e) => {
                    // Fallback to a default Daraz-style banner
                    e.currentTarget.src = `https://via.placeholder.com/800x200/FF6B35/FFFFFF?text=${encodeURIComponent(banner.title)}`;
                  }}
                />
                {/* Remove overlay text since images already have text */}
              </div>
            </CarouselItem>
          ))}
        </CarouselContent>
        
        {/* Navigation Arrows - Show on hover/touch with smooth animation */}
        <CarouselPrevious className="absolute left-2 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 group-active:opacity-100 transition-all duration-300 ease-in-out transform -translate-x-2 group-hover:translate-x-0 group-active:translate-x-0 bg-white/90 hover:bg-white border-0 shadow-lg h-10 w-10 backdrop-blur-sm" />
        <CarouselNext className="absolute right-2 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 group-active:opacity-100 transition-all duration-300 ease-in-out transform translate-x-2 group-hover:translate-x-0 group-active:translate-x-0 bg-white/90 hover:bg-white border-0 shadow-lg h-10 w-10 backdrop-blur-sm" />
        
        {/* Custom Navigation Dots - Simple Style */}
        <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 flex gap-2">
          {banners.map((_, index) => (
            <button
              key={index}
              className={`w-2 h-2 rounded-full transition-colors duration-300 ${
                currentSlide === index ? 'bg-white' : 'bg-white/50'
              }`}
              onClick={() => {
                if (api) {
                  api.scrollTo(index);
                  setCurrentSlide(index);
                }
              }}
            />
          ))}
        </div>
      </Carousel>
    </div>
  );
}