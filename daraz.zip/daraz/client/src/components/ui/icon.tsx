import { 
  Search, 
  Home, 
  Grid3X3, 
  ShoppingCart, 
  User, 
  ArrowLeft, 
  Heart, 
  Share2, 
  Star, 
  Plus, 
  Minus, 
  MapPin, 
  Phone, 
  Building, 
  Truck, 
  CreditCard, 
  Smartphone, 
  Eye, 
  ShoppingBag, 
  Clock, 
  Gamepad2, 
  Sparkles, 
  Dumbbell, 
  Book, 
  Briefcase, 
  ChevronRight, 
  ChevronDown, 
  ChevronLeft,
  Info, 
  Shield, 
  Lock, 
  Percent, 
  Trash2, 
  MoreVertical,
  Store,
  MessageCircle,
  FileText,
  Menu,
  X
} from 'lucide-react';

const iconMap = {
  search: Search,
  home: Home,
  grid: Grid3X3,
  'shopping-cart': ShoppingCart,
  user: User,
  'arrow-left': ArrowLeft,
  heart: Heart,
  share: Share2,
  star: Star,
  plus: Plus,
  minus: Minus,
  'map-pin': MapPin,
  phone: Phone,
  building: Building,
  truck: Truck,
  'credit-card': CreditCard,
  smartphone: Smartphone,
  eye: Eye,
  'shopping-bag': ShoppingBag,
  clock: Clock,
  gamepad: Gamepad2,
  sparkles: Sparkles,
  dumbbell: Dumbbell,
  book: Book,
  briefcase: Briefcase,
  'chevron-right': ChevronRight,
  'chevron-down': ChevronDown,
  'chevron-left': ChevronLeft,
  info: Info,
  shield: Shield,
  lock: Lock,
  percent: Percent,
  trash: Trash2,
  'more-vertical': MoreVertical,
  store: Store,
  message: MessageCircle,
  file: FileText,
  menu: Menu,
  x: X,
};

export type IconName = keyof typeof iconMap;

interface IconProps {
  name: IconName;
  className?: string;
  size?: number;
}

export function Icon({ name, className, size = 24 }: IconProps) {
  const IconComponent = iconMap[name];
  
  if (!IconComponent) {
    console.warn(`Icon "${name}" not found`);
    return null;
  }
  
  return <IconComponent size={size} className={className} />;
}
