# 🚀 Production Deployment Notes

## ⚠️ Critical: QR Code Storage Limitation

### Current Implementation (Demo/MVP)
The Telegram bot stores QR codes using **Telegram's CDN URLs**, which are **temporary and will expire**.

**Issue:** When admin uploads a new QR code via `/change` command:
- QR is stored as: `https://api.telegram.org/file/bot{TOKEN}/{file_path}`
- **These URLs expire after a short period** (days to weeks)
- Once expired, users will see broken QR codes on the website

### Production-Ready Solution Required

Before deploying to production, implement permanent storage:

#### Option 1: Cloudinary (Recommended)
```javascript
// Install: npm install cloudinary
import { v2 as cloudinary } from 'cloudinary';

async function handleQRUpload(chatId, fileId) {
  // 1. Download from Telegram
  const file = await bot.getFile(fileId);
  const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
  const response = await fetch(fileUrl);
  const buffer = await response.buffer();
  
  // 2. Upload to Cloudinary
  const result = await cloudinary.uploader.upload_stream({
    folder: 'qr-codes',
    public_id: `payment-qr-${Date.now()}`
  }, buffer);
  
  // 3. Store permanent URL
  await QRCode.findOneAndUpdate({}, {
    imageUrl: result.secure_url, // Permanent Cloudinary URL
    updatedAt: new Date(),
    updatedBy: 'admin'
  }, { upsert: true });
}
```

#### Option 2: AWS S3
```javascript
// Install: npm install @aws-sdk/client-s3
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';

async function uploadToS3(buffer, filename) {
  const command = new PutObjectCommand({
    Bucket: process.env.S3_BUCKET,
    Key: `qr-codes/${filename}`,
    Body: buffer,
    ContentType: 'image/png'
  });
  
  await s3Client.send(command);
  return `https://${process.env.S3_BUCKET}.s3.amazonaws.com/qr-codes/${filename}`;
}
```

#### Option 3: Replit Object Storage
```javascript
// Use Replit's built-in object storage (if available)
// Provides durable, permanent file storage
```

### Implementation Checklist

- [ ] Choose storage provider (Cloudinary/S3/Replit)
- [ ] Set up account and get credentials
- [ ] Add credentials to Replit Secrets
- [ ] Update `handleQRUpload()` to download and re-upload
- [ ] Test QR persistence after 24+ hours
- [ ] Update documentation

## Screenshot Handling

### Current Status: ✅ Production Ready
- Validation: Format, size, dimensions
- Error handling: Graceful failures
- Telegram forwarding: Non-blocking async
- Transaction logging: Always successful

### Enhancements for Scale

#### 1. Screenshot Storage
Consider storing screenshots for audit trail:
```javascript
// Store in same permanent storage as QR codes
const screenshotUrl = await uploadToCloudinary(screenshotBuffer);
await TransactionLog.create({
  ...data,
  screenshotUrl: screenshotUrl // Permanent URL
});
```

#### 2. Retry Logic
Add retry for Telegram failures:
```javascript
import pRetry from 'p-retry';

await pRetry(() => forwardScreenshotToAdmin(data), {
  retries: 3,
  onFailedAttempt: error => {
    console.log(`Attempt ${error.attemptNumber} failed. Retrying...`);
  }
});
```

#### 3. Admin Alerts
Notify admin of failures:
```javascript
if (telegramForwardFailed) {
  await bot.sendMessage(ADMIN_USER_ID, 
    `⚠️ Failed to forward screenshot for ${productTitle}. Check logs.`
  );
}
```

## Database Considerations

### MongoDB Atlas (Current)
- ✅ Free tier sufficient for demo/MVP
- ⚠️ Upgrade to paid tier for production traffic
- ⚠️ Enable authentication and IP whitelist
- ⚠️ Set up automated backups

### Transaction Log Retention
```javascript
// Add index for auto-cleanup (optional)
transactionLogSchema.index({ timestamp: 1 }, { 
  expireAfterSeconds: 7776000 // 90 days
});
```

## Security Hardening

### 1. Rate Limiting
```javascript
import rateLimit from 'express-rate-limit';

const transactionLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // limit each IP to 10 requests per window
  message: 'Too many transaction attempts'
});

app.post('/api/transaction-log', transactionLimiter, ...);
```

### 2. CORS Configuration
```javascript
import cors from 'cors';

app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || '*',
  credentials: true
}));
```

### 3. Input Sanitization
Already implemented ✅:
- Zod validation
- Base64 format checking
- Image size limits
- Data type enforcement

## Monitoring & Logging

### Recommended Tools
1. **Sentry** - Error tracking
2. **LogRocket** - Session replay
3. **MongoDB Atlas Monitoring** - DB performance
4. **Telegram Bot Analytics** - Bot usage stats

### Key Metrics to Track
- Transaction success rate
- Telegram forward failures
- Screenshot upload failures
- QR code fetch errors
- API response times

## Deployment Checklist

### Pre-Production
- [ ] Implement permanent QR storage
- [ ] Set up monitoring (Sentry/LogRocket)
- [ ] Configure rate limiting
- [ ] Enable MongoDB authentication
- [ ] Set up automated database backups
- [ ] Test with high-resolution real screenshots
- [ ] Verify Telegram bot with real payment QR codes
- [ ] Load test transaction endpoints

### Production
- [ ] Use production MongoDB cluster
- [ ] Enable HTTPS only (disable HTTP)
- [ ] Set strong session secrets
- [ ] Configure proper CORS origins
- [ ] Enable API request logging
- [ ] Set up automated health checks
- [ ] Configure uptime monitoring
- [ ] Document incident response procedures

### Post-Deployment
- [ ] Monitor error rates (first 24hrs)
- [ ] Verify Telegram bot responsiveness
- [ ] Check QR code loading times
- [ ] Test screenshot uploads from mobile devices
- [ ] Verify transaction log accuracy
- [ ] Test admin bot commands

## Performance Optimization

### Image Optimization
```javascript
// Compress screenshots before forwarding
import sharp from 'sharp';

const compressed = await sharp(buffer)
  .resize(1200, 1200, { fit: 'inside' })
  .jpeg({ quality: 80 })
  .toBuffer();
```

### Caching
```javascript
// Cache QR code in Redis for fast access
import Redis from 'ioredis';
const redis = new Redis(process.env.REDIS_URL);

// GET /api/qr-code with caching
const cached = await redis.get('qr:current');
if (cached) return res.json({ imageUrl: cached });

const qr = await storage.getQRCode();
await redis.set('qr:current', qr, 'EX', 3600); // 1 hour cache
```

## Cost Estimates (Monthly)

### MVP/Demo (Current Setup)
- MongoDB Atlas: **Free**
- Telegram Bot: **Free**
- Replit Hosting: **Free tier**
- **Total: $0/month**

### Production (Recommended)
- MongoDB Atlas (M10): **$57/month**
- Cloudinary (Free tier): **$0** (up to 25GB, 25k transformations)
- Replit Deployment: **$20-40/month**
- Monitoring (Sentry): **Free tier**
- **Total: ~$77-97/month**

### High Traffic
- MongoDB Atlas (M30): **$282/month**
- Cloudinary (Advanced): **$99/month**
- Redis Cache (Upstash): **$10/month**
- Replit (Reserved): **$70/month**
- **Total: ~$461/month**

## Support & Maintenance

### Weekly Tasks
- Check Telegram bot health
- Review transaction logs export
- Monitor error rates
- Verify QR code accessibility

### Monthly Tasks
- Database backup verification
- Update dependencies (security patches)
- Review storage costs
- Clean old transaction logs

### Quarterly Tasks
- Security audit
- Performance optimization review
- User feedback analysis
- Telegram bot enhancements

---

## Quick Start Production Deployment

### 1. Set Up Cloudinary (5 minutes)
```bash
# 1. Create account: cloudinary.com
# 2. Get credentials from dashboard
# 3. Add to Replit Secrets:
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
```

### 2. Update QR Upload Handler
```javascript
// server/telegram-bot.ts
import { v2 as cloudinary } from 'cloudinary';

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

async function handleQRUpload(chatId, fileId) {
  const file = await bot.getFile(fileId);
  const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
  
  // Download from Telegram
  const response = await fetch(fileUrl);
  const buffer = Buffer.from(await response.arrayBuffer());
  
  // Upload to Cloudinary
  const result = await new Promise((resolve, reject) => {
    cloudinary.uploader.upload_stream(
      { folder: 'qr-codes' },
      (error, result) => {
        if (error) reject(error);
        else resolve(result);
      }
    ).end(buffer);
  });
  
  // Save permanent URL
  await QRCode.findOneAndUpdate({}, {
    imageUrl: result.secure_url,
    updatedAt: new Date()
  }, { upsert: true });
  
  await bot.sendMessage(chatId, '✅ QR code uploaded and saved permanently!');
}
```

### 3. Test & Deploy
```bash
# 1. Test QR upload via Telegram bot
# 2. Verify QR displays on website
# 3. Check QR URL is cloudinary.com (not telegram.org)
# 4. Publish to Replit deployment
```

---

**Status:** 
- ✅ **Demo/MVP:** Ready to use
- ⚠️ **Production:** Requires QR storage upgrade
- 📋 **Estimated Time:** 1-2 hours to implement Cloudinary

**Priority:** HIGH - Implement before long-term deployment
