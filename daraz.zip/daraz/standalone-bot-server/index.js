require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const TelegramBot = require('node-telegram-bot-api');
const cloudinary = require('cloudinary').v2;

const app = express();
const PORT = process.env.PORT || 4000;

// Configure Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME || 'djbiyudvw',
  api_key: process.env.CLOUDINARY_API_KEY || '237276653695988',
  api_secret: process.env.CLOUDINARY_API_SECRET || 'Bdy4aNMX6iknWhvD89YrJZsrvZw'
});

// MongoDB Schemas
const transactionSchema = new mongoose.Schema({
  productTitle: String,
  amount: Number,
  userId: String,
  status: { type: String, enum: ['pending', 'approved', 'declined'], default: 'pending' },
  screenshotUrl: String,
  timestamp: { type: Date, default: Date.now },
  adminId: String,
  storeSlug: String
});

const qrCodeSchema = new mongoose.Schema({
  imageUrl: String,
  cloudinaryPublicId: String,
  adminId: String,
  storeSlug: String,
  updatedAt: { type: Date, default: Date.now },
  updatedBy: String
});

const adminSchema = new mongoose.Schema({
  username: String,
  passwordHash: String,
  storeSlug: String,
  botToken: String,
  botChatId: String,
  isActive: { type: Boolean, default: true },
  expiryDate: Date,
  createdAt: { type: Date, default: Date.now }
});

const botSettingsSchema = new mongoose.Schema({
  admins: [{
    userId: Number,
    username: String,
    addedAt: { type: Date, default: Date.now }
  }]
});

const settingsSchema = new mongoose.Schema({
  key: { type: String, unique: true },
  value: mongoose.Schema.Types.Mixed
});

const TransactionLog = mongoose.model('TransactionLog', transactionSchema);
const QRCode = mongoose.model('QRCode', qrCodeSchema);
const Admin = mongoose.model('Admin', adminSchema);
const BotSettings = mongoose.model('BotSettings', botSettingsSchema);
const Settings = mongoose.model('Setting', settingsSchema);

// Bot registries
const adminBots = new Map();
let ownerBot = null;
let ownerBotToken = '';
const deleteConfirmation = new Map();

// Helper: Upload QR to Cloudinary
async function uploadQRToCloudinary(imageUrl, folder) {
  try {
    const result = await cloudinary.uploader.upload(imageUrl, {
      folder: folder,
      resource_type: 'image'
    });
    return { url: result.secure_url, publicId: result.public_id };
  } catch (error) {
    console.error('Cloudinary upload error:', error);
    throw error;
  }
}

// Helper: Delete from Cloudinary
async function deleteFromCloudinary(publicId) {
  try {
    await cloudinary.uploader.destroy(publicId);
    console.log('Deleted from Cloudinary:', publicId);
  } catch (error) {
    console.error('Cloudinary delete error:', error);
  }
}

// Owner Bot Functions
async function isOwnerAdmin(userId) {
  try {
    const settings = await BotSettings.findOne();
    if (!settings || !settings.admins || settings.admins.length === 0) {
      return userId === parseInt(process.env.OWNER_CHAT_ID);
    }
    return settings.admins.some(admin => admin.userId === userId);
  } catch (error) {
    return userId === parseInt(process.env.OWNER_CHAT_ID);
  }
}

async function getAllOwnerAdminIds() {
  try {
    const settings = await BotSettings.findOne();
    if (!settings || !settings.admins || settings.admins.length === 0) {
      return [parseInt(process.env.OWNER_CHAT_ID)];
    }
    return settings.admins.map(admin => admin.userId);
  } catch (error) {
    return [parseInt(process.env.OWNER_CHAT_ID)];
  }
}

function initOwnerBot(token) {
  if (!token) {
    console.log('⚠️ No owner bot token provided');
    return null;
  }

  try {
    ownerBotToken = token;
    ownerBot = new TelegramBot(token, { polling: true });
    console.log('✅ Owner bot initialized');

    ownerBot.on('message', async (msg) => {
      const chatId = msg.chat.id;
      const userId = msg.from?.id || 0;
      const text = msg.text || '';

      const isAdmin = await isOwnerAdmin(userId);
      if (!isAdmin) {
        await ownerBot.sendMessage(chatId, '❌ You are not authorized to use this bot.');
        return;
      }

      if (text === '/start') {
        await ownerBot.sendMessage(chatId, `
🤖 *Welcome Owner Admin!*

Available Commands:
/status - Today's payment statistics
/status_all - Export all transactions
/approve_all - Approve all pending
/decline_all - Decline all pending
/change - Upload new QR code
/delete - Delete all logs

Send a QR image to update the payment QR.
        `, { parse_mode: 'Markdown' });
      } else if (text === '/status') {
        await handleOwnerStatus(chatId);
      } else if (text === '/status_all') {
        await handleOwnerStatusAll(chatId);
      } else if (text === '/change') {
        await ownerBot.sendMessage(chatId, '📷 Send a new QR code image to update.', { parse_mode: 'Markdown' });
      } else if (text === '/delete') {
        await handleOwnerDelete(chatId, userId);
      } else if (text.startsWith('/delete_confirm_')) {
        const step = parseInt(text.replace('/delete_confirm_', ''));
        await handleOwnerDeleteConfirm(chatId, userId, step);
      } else if (text === '/approve_all') {
        await handleOwnerApproveAll(chatId);
      } else if (text === '/decline_all') {
        await handleOwnerDeclineAll(chatId);
      } else if (text.startsWith('/approve_')) {
        const txId = text.replace('/approve_', '');
        await handleOwnerApprove(chatId, txId);
      } else if (text.startsWith('/decline_')) {
        const txId = text.replace('/decline_', '');
        await handleOwnerDecline(chatId, txId);
      } else if (msg.photo && msg.photo.length > 0) {
        await handleOwnerQRUpload(chatId, msg.photo[msg.photo.length - 1].file_id);
      }
    });

    ownerBot.on('callback_query', async (query) => {
      const chatId = query.message?.chat.id;
      const userId = query.from.id;
      const isAdmin = await isOwnerAdmin(userId);

      if (!chatId || !isAdmin) {
        await ownerBot.answerCallbackQuery(query.id, { text: '❌ Not authorized' });
        return;
      }

      const data = query.data;
      if (data?.startsWith('approve_')) {
        await handleOwnerApprove(chatId, data.replace('approve_', ''), query.id);
      } else if (data?.startsWith('decline_')) {
        await handleOwnerDecline(chatId, data.replace('decline_', ''), query.id);
      }
    });

    return ownerBot;
  } catch (error) {
    console.error('❌ Failed to init owner bot:', error);
    return null;
  }
}

async function handleOwnerStatus(chatId) {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const transactions = await TransactionLog.find({
      adminId: null,
      timestamp: { $gte: today }
    });

    const approved = transactions.filter(t => t.status === 'approved');
    const declined = transactions.filter(t => t.status === 'declined');
    const pending = transactions.filter(t => t.status === 'pending');
    const approvedAmount = approved.reduce((sum, t) => sum + t.amount, 0);

    await ownerBot.sendMessage(chatId, `
📊 *Today's Statistics*

💰 Total: ${transactions.length}
✅ Approved: ${approved.length}
❌ Declined: ${declined.length}
⏳ Pending: ${pending.length}

💵 Collected: Rs. ${approvedAmount.toLocaleString()}
    `, { parse_mode: 'Markdown' });
  } catch (error) {
    await ownerBot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

async function handleOwnerStatusAll(chatId) {
  try {
    const transactions = await TransactionLog.find({ adminId: null }).sort({ timestamp: 1 });

    if (transactions.length === 0) {
      await ownerBot.sendMessage(chatId, '📄 No transactions found.');
      return;
    }

    let content = '=== TRANSACTION LOGS ===\n\n';
    transactions.forEach((t, i) => {
      content += `${i + 1}. ${t.productTitle}\n   Rs. ${t.amount} - ${t.status.toUpperCase()}\n   ${new Date(t.timestamp).toLocaleString()}\n\n`;
    });

    const buffer = Buffer.from(content, 'utf-8');
    await ownerBot.sendDocument(chatId, buffer, { caption: `📄 ${transactions.length} transactions` }, { filename: `transactions_${Date.now()}.txt` });
  } catch (error) {
    await ownerBot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

async function handleOwnerQRUpload(chatId, fileId) {
  try {
    const file = await ownerBot.getFile(fileId);
    const telegramFileUrl = `https://api.telegram.org/file/bot${ownerBotToken}/${file.file_path}`;

    const existingQR = await QRCode.findOne({ adminId: null });
    if (existingQR?.cloudinaryPublicId) {
      await deleteFromCloudinary(existingQR.cloudinaryPublicId);
    }

    await ownerBot.sendMessage(chatId, '⏳ Uploading to cloud...');
    const result = await uploadQRToCloudinary(telegramFileUrl, 'qr-codes/owner');

    await QRCode.findOneAndUpdate(
      { adminId: null },
      { imageUrl: result.url, cloudinaryPublicId: result.publicId, updatedAt: new Date(), updatedBy: 'owner-bot' },
      { upsert: true }
    );

    await ownerBot.sendMessage(chatId, '✅ QR code updated successfully!');
  } catch (error) {
    await ownerBot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

async function handleOwnerDelete(chatId, userId) {
  deleteConfirmation.set(`owner_${userId}`, 1);
  await ownerBot.sendMessage(chatId, `
⚠️ *DELETE ALL LOGS*

Step 1/3 - Type: \`/delete_confirm_1\`
  `, { parse_mode: 'Markdown' });
}

async function handleOwnerDeleteConfirm(chatId, userId, step) {
  const key = `owner_${userId}`;
  const current = deleteConfirmation.get(key) || 0;

  if (step !== current) {
    await ownerBot.sendMessage(chatId, '❌ Invalid step. Start with /delete');
    return;
  }

  if (step === 1) {
    deleteConfirmation.set(key, 2);
    await ownerBot.sendMessage(chatId, '⚠️ Step 2/3 - Type: `/delete_confirm_2`', { parse_mode: 'Markdown' });
  } else if (step === 2) {
    deleteConfirmation.set(key, 3);
    await ownerBot.sendMessage(chatId, '🚨 FINAL - Type: `/delete_confirm_3`', { parse_mode: 'Markdown' });
  } else if (step === 3) {
    const result = await TransactionLog.deleteMany({ adminId: null });
    deleteConfirmation.delete(key);
    await ownerBot.sendMessage(chatId, `✅ Deleted ${result.deletedCount} records.`);
  }
}

async function handleOwnerApprove(chatId, txId, queryId) {
  try {
    const tx = await TransactionLog.findById(txId);
    if (!tx) {
      const msg = '❌ Not found';
      if (queryId) await ownerBot.answerCallbackQuery(queryId, { text: msg });
      else await ownerBot.sendMessage(chatId, msg);
      return;
    }
    if (tx.status !== 'pending') {
      const msg = `⚠️ Already ${tx.status}`;
      if (queryId) await ownerBot.answerCallbackQuery(queryId, { text: msg });
      else await ownerBot.sendMessage(chatId, msg);
      return;
    }
    tx.status = 'approved';
    await tx.save();
    if (queryId) await ownerBot.answerCallbackQuery(queryId, { text: '✅ Approved!' });
    await ownerBot.sendMessage(chatId, `✅ *Approved*\n${tx.productTitle}\nRs. ${tx.amount.toLocaleString()}`, { parse_mode: 'Markdown' });
  } catch (error) {
    if (queryId) await ownerBot.answerCallbackQuery(queryId, { text: '❌ Error' });
    else await ownerBot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

async function handleOwnerDecline(chatId, txId, queryId) {
  try {
    const tx = await TransactionLog.findById(txId);
    if (!tx) {
      const msg = '❌ Not found';
      if (queryId) await ownerBot.answerCallbackQuery(queryId, { text: msg });
      else await ownerBot.sendMessage(chatId, msg);
      return;
    }
    if (tx.status !== 'pending') {
      const msg = `⚠️ Already ${tx.status}`;
      if (queryId) await ownerBot.answerCallbackQuery(queryId, { text: msg });
      else await ownerBot.sendMessage(chatId, msg);
      return;
    }
    tx.status = 'declined';
    await tx.save();
    if (queryId) await ownerBot.answerCallbackQuery(queryId, { text: '❌ Declined' });
    await ownerBot.sendMessage(chatId, `❌ *Declined*\n${tx.productTitle}\nRs. ${tx.amount.toLocaleString()}`, { parse_mode: 'Markdown' });
  } catch (error) {
    if (queryId) await ownerBot.answerCallbackQuery(queryId, { text: '❌ Error' });
    else await ownerBot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

async function handleOwnerApproveAll(chatId) {
  try {
    const pending = await TransactionLog.find({ adminId: null, status: 'pending' });
    if (pending.length === 0) {
      await ownerBot.sendMessage(chatId, '⚠️ No pending payments.');
      return;
    }
    let total = 0;
    for (const tx of pending) {
      tx.status = 'approved';
      await tx.save();
      total += tx.amount;
    }
    await ownerBot.sendMessage(chatId, `✅ Approved ${pending.length} (Rs. ${total.toLocaleString()})`);
  } catch (error) {
    await ownerBot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

async function handleOwnerDeclineAll(chatId) {
  try {
    const pending = await TransactionLog.find({ adminId: null, status: 'pending' });
    if (pending.length === 0) {
      await ownerBot.sendMessage(chatId, '⚠️ No pending payments.');
      return;
    }
    for (const tx of pending) {
      tx.status = 'declined';
      await tx.save();
    }
    await ownerBot.sendMessage(chatId, `❌ Declined ${pending.length} payments`);
  } catch (error) {
    await ownerBot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

// Admin Bot Functions (for tenant stores)
async function startAdminBot(adminId, botToken, chatId, storeSlug) {
  try {
    await stopAdminBot(adminId);
    
    console.log(`🤖 Starting bot for ${storeSlug}...`);
    const bot = new TelegramBot(botToken, { polling: true });

    bot.on('message', async (msg) => {
      const msgChatId = msg.chat.id;
      const text = msg.text;
      const userId = msg.from?.id;

      if (msgChatId.toString() !== chatId) {
        await bot.sendMessage(msgChatId, '❌ Not authorized.');
        return;
      }

      if (msg.photo && msg.photo.length > 0) {
        await handleAdminQRUpload(bot, botToken, msgChatId, msg.photo[msg.photo.length - 1].file_id, adminId, storeSlug);
        return;
      }

      if (!text) return;
      const cmd = text.toLowerCase().trim();

      if (cmd === '/start') {
        await bot.sendMessage(msgChatId, `
🎉 *${storeSlug} Store Bot*

/status - Today's summary
/statusall - All transactions
/change - Upload new QR
/delete - Delete logs
/approveall - Approve all
/declineall - Decline all
        `, { parse_mode: 'Markdown' });
      } else if (cmd === '/status') {
        await handleAdminStatus(bot, msgChatId, adminId);
      } else if (cmd === '/statusall') {
        await handleAdminStatusAll(bot, msgChatId, adminId);
      } else if (cmd === '/change') {
        await bot.sendMessage(msgChatId, '📷 Send a QR image to update.');
      } else if (cmd === '/delete' && userId) {
        await handleAdminDelete(bot, msgChatId, userId, adminId);
      } else if (cmd === '/confirm1' && userId) {
        await handleAdminDeleteConfirm(bot, msgChatId, userId, 1, adminId);
      } else if (cmd === '/confirm2' && userId) {
        await handleAdminDeleteConfirm(bot, msgChatId, userId, 2, adminId);
      } else if (cmd === '/finalconfirm' && userId) {
        await handleAdminDeleteConfirm(bot, msgChatId, userId, 3, adminId);
      } else if (cmd === '/approveall') {
        await handleAdminApproveAll(bot, msgChatId, adminId);
      } else if (cmd === '/declineall') {
        await handleAdminDeclineAll(bot, msgChatId, adminId);
      }
    });

    bot.on('callback_query', async (query) => {
      const data = query.data;
      const msgChatId = query.message?.chat.id;
      if (!data || !msgChatId) return;

      if (data.startsWith('approve_')) {
        await handleAdminApprove(bot, msgChatId, data.replace('approve_', ''), adminId, query.id);
      } else if (data.startsWith('decline_')) {
        await handleAdminDecline(bot, msgChatId, data.replace('decline_', ''), adminId, query.id);
      }
    });

    bot.on('polling_error', (error) => {
      console.error(`❌ [${storeSlug}] Polling error:`, error.message);
    });

    adminBots.set(adminId, { bot, botToken, adminId, storeSlug, chatId });
    console.log(`✅ Bot started for ${storeSlug}`);
    return true;
  } catch (error) {
    console.error(`❌ Failed to start bot for ${storeSlug}:`, error);
    return false;
  }
}

async function stopAdminBot(adminId) {
  const existing = adminBots.get(adminId);
  if (existing) {
    try {
      existing.bot.removeAllListeners();
      await existing.bot.stopPolling();
      adminBots.delete(adminId);
      console.log(`🛑 Bot stopped for ${existing.storeSlug}`);
    } catch (error) {
      console.error('Error stopping bot:', error);
    }
  }
}

async function handleAdminStatus(bot, chatId, adminId) {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const txs = await TransactionLog.find({ adminId, timestamp: { $gte: today } });
    const approved = txs.filter(t => t.status === 'approved');
    const total = approved.reduce((s, t) => s + t.amount, 0);
    await bot.sendMessage(chatId, `
📊 *Today*
⏳ Pending: ${txs.filter(t => t.status === 'pending').length}
✅ Approved: ${approved.length} (Rs. ${total.toLocaleString()})
❌ Declined: ${txs.filter(t => t.status === 'declined').length}
    `, { parse_mode: 'Markdown' });
  } catch (error) {
    await bot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

async function handleAdminStatusAll(bot, chatId, adminId) {
  try {
    const txs = await TransactionLog.find({ adminId }).sort({ timestamp: -1 }).limit(50);
    if (txs.length === 0) {
      await bot.sendMessage(chatId, '📄 No transactions.');
      return;
    }
    let msg = '*Recent (50)*\n\n';
    for (const tx of txs) {
      const s = tx.status === 'approved' ? '✅' : tx.status === 'declined' ? '❌' : '⏳';
      msg += `${s} Rs.${tx.amount} - ${tx.productTitle.substring(0, 15)}...\n`;
    }
    await bot.sendMessage(chatId, msg, { parse_mode: 'Markdown' });
  } catch (error) {
    await bot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

async function handleAdminQRUpload(bot, botToken, chatId, fileId, adminId, storeSlug) {
  try {
    const file = await bot.getFile(fileId);
    const url = `https://api.telegram.org/file/bot${botToken}/${file.file_path}`;

    const existing = await QRCode.findOne({ adminId });
    if (existing?.cloudinaryPublicId) {
      await deleteFromCloudinary(existing.cloudinaryPublicId);
    }

    await bot.sendMessage(chatId, '⏳ Uploading...');
    const result = await uploadQRToCloudinary(url, `qr-codes/${storeSlug}`);

    await QRCode.findOneAndUpdate(
      { adminId },
      { imageUrl: result.url, cloudinaryPublicId: result.publicId, adminId, storeSlug, updatedAt: new Date(), updatedBy: 'admin-bot' },
      { upsert: true }
    );

    await bot.sendMessage(chatId, '✅ QR updated!');
  } catch (error) {
    await bot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

async function handleAdminDelete(bot, chatId, userId, adminId) {
  deleteConfirmation.set(`${adminId}_${userId}`, 1);
  const count = await TransactionLog.countDocuments({ adminId });
  await bot.sendMessage(chatId, `⚠️ Delete ${count} transactions?\nType /confirm1`, { parse_mode: 'Markdown' });
}

async function handleAdminDeleteConfirm(bot, chatId, userId, step, adminId) {
  const key = `${adminId}_${userId}`;
  const current = deleteConfirmation.get(key) || 0;
  if (step !== current) {
    await bot.sendMessage(chatId, '❌ Start with /delete');
    return;
  }
  if (step === 1) {
    deleteConfirmation.set(key, 2);
    await bot.sendMessage(chatId, '⚠️ Step 2/3 - /confirm2');
  } else if (step === 2) {
    deleteConfirmation.set(key, 3);
    await bot.sendMessage(chatId, '🚨 FINAL - /finalconfirm');
  } else if (step === 3) {
    const result = await TransactionLog.deleteMany({ adminId });
    deleteConfirmation.delete(key);
    await bot.sendMessage(chatId, `✅ Deleted ${result.deletedCount}`);
  }
}

async function handleAdminApprove(bot, chatId, txId, adminId, queryId) {
  try {
    const tx = await TransactionLog.findOne({ _id: txId, adminId });
    if (!tx) {
      if (queryId) await bot.answerCallbackQuery(queryId, { text: '❌ Not found' });
      else await bot.sendMessage(chatId, '❌ Not found');
      return;
    }
    if (tx.status !== 'pending') {
      if (queryId) await bot.answerCallbackQuery(queryId, { text: `⚠️ ${tx.status}` });
      else await bot.sendMessage(chatId, `⚠️ ${tx.status}`);
      return;
    }
    tx.status = 'approved';
    await tx.save();
    if (queryId) await bot.answerCallbackQuery(queryId, { text: '✅ Approved!' });
    await bot.sendMessage(chatId, `✅ Rs. ${tx.amount.toLocaleString()} approved`);
  } catch (error) {
    if (queryId) await bot.answerCallbackQuery(queryId, { text: '❌ Error' });
    else await bot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

async function handleAdminDecline(bot, chatId, txId, adminId, queryId) {
  try {
    const tx = await TransactionLog.findOne({ _id: txId, adminId });
    if (!tx) {
      if (queryId) await bot.answerCallbackQuery(queryId, { text: '❌ Not found' });
      else await bot.sendMessage(chatId, '❌ Not found');
      return;
    }
    if (tx.status !== 'pending') {
      if (queryId) await bot.answerCallbackQuery(queryId, { text: `⚠️ ${tx.status}` });
      else await bot.sendMessage(chatId, `⚠️ ${tx.status}`);
      return;
    }
    tx.status = 'declined';
    await tx.save();
    if (queryId) await bot.answerCallbackQuery(queryId, { text: '❌ Declined' });
    await bot.sendMessage(chatId, `❌ Rs. ${tx.amount.toLocaleString()} declined`);
  } catch (error) {
    if (queryId) await bot.answerCallbackQuery(queryId, { text: '❌ Error' });
    else await bot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

async function handleAdminApproveAll(bot, chatId, adminId) {
  try {
    const pending = await TransactionLog.find({ adminId, status: 'pending' });
    if (pending.length === 0) {
      await bot.sendMessage(chatId, '⚠️ No pending.');
      return;
    }
    let total = 0;
    for (const tx of pending) {
      tx.status = 'approved';
      await tx.save();
      total += tx.amount;
    }
    await bot.sendMessage(chatId, `✅ ${pending.length} approved (Rs. ${total.toLocaleString()})`);
  } catch (error) {
    await bot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

async function handleAdminDeclineAll(bot, chatId, adminId) {
  try {
    const pending = await TransactionLog.find({ adminId, status: 'pending' });
    if (pending.length === 0) {
      await bot.sendMessage(chatId, '⚠️ No pending.');
      return;
    }
    for (const tx of pending) {
      tx.status = 'declined';
      await tx.save();
    }
    await bot.sendMessage(chatId, `❌ ${pending.length} declined`);
  } catch (error) {
    await bot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

// Start all admin bots
async function startAllAdminBots() {
  try {
    const admins = await Admin.find({
      isActive: true,
      expiryDate: { $gt: new Date() },
      botToken: { $ne: null },
      botChatId: { $ne: null }
    });

    console.log(`🤖 Found ${admins.length} admins with bot tokens`);

    for (const admin of admins) {
      if (admin.botToken && admin.botChatId) {
        const slug = admin.storeSlug || admin.username.toLowerCase().replace(/[^a-z0-9]/g, '-');
        await startAdminBot(admin._id.toString(), admin.botToken, admin.botChatId, slug);
        await new Promise(r => setTimeout(r, 500));
      }
    }

    console.log('✅ All admin bots started');
  } catch (error) {
    console.error('❌ Error starting admin bots:', error);
  }
}

// Express middleware for JSON
app.use(express.json());

// Simple API key auth (optional security)
const API_KEY = process.env.BOT_SERVER_API_KEY || 'bot-server-secret-key';

function authMiddleware(req, res, next) {
  const key = req.headers['x-api-key'] || req.query.key;
  if (key !== API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
}

// Express routes for health check
app.get('/', (req, res) => {
  res.json({
    status: 'running',
    ownerBot: ownerBot ? 'active' : 'inactive',
    adminBots: adminBots.size,
    adminBotsList: Array.from(adminBots.entries()).map(([id, b]) => ({
      adminId: id,
      storeSlug: b.storeSlug,
      active: true
    })),
    timestamp: new Date().toISOString()
  });
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

// API: Start/Restart a specific admin bot
app.post('/api/admin-bot/start', authMiddleware, async (req, res) => {
  try {
    const { adminId, botToken, chatId, storeSlug } = req.body;
    
    if (!adminId || !botToken || !chatId || !storeSlug) {
      return res.status(400).json({ error: 'Missing required fields: adminId, botToken, chatId, storeSlug' });
    }
    
    const success = await startAdminBot(adminId, botToken, chatId, storeSlug);
    
    if (success) {
      console.log(`✅ [API] Admin bot started for ${storeSlug}`);
      res.json({ success: true, message: `Bot started for ${storeSlug}` });
    } else {
      res.status(500).json({ error: 'Failed to start bot' });
    }
  } catch (error) {
    console.error('❌ [API] Start admin bot error:', error);
    res.status(500).json({ error: error.message });
  }
});

// API: Stop a specific admin bot
app.post('/api/admin-bot/stop', authMiddleware, async (req, res) => {
  try {
    const { adminId } = req.body;
    
    if (!adminId) {
      return res.status(400).json({ error: 'Missing adminId' });
    }
    
    await stopAdminBot(adminId);
    console.log(`✅ [API] Admin bot stopped for ${adminId}`);
    res.json({ success: true, message: 'Bot stopped' });
  } catch (error) {
    console.error('❌ [API] Stop admin bot error:', error);
    res.status(500).json({ error: error.message });
  }
});

// API: Refresh all admin bots from database
app.post('/api/admin-bots/refresh', authMiddleware, async (req, res) => {
  try {
    // Stop all existing bots first
    for (const [adminId] of adminBots) {
      await stopAdminBot(adminId);
    }
    
    // Restart all from database
    await startAllAdminBots();
    
    console.log(`✅ [API] All admin bots refreshed. Active: ${adminBots.size}`);
    res.json({ success: true, activeCount: adminBots.size });
  } catch (error) {
    console.error('❌ [API] Refresh admin bots error:', error);
    res.status(500).json({ error: error.message });
  }
});

// API: Reload owner bot from database
app.post('/api/owner-bot/reload', authMiddleware, async (req, res) => {
  try {
    // Stop existing owner bot
    if (ownerBot) {
      ownerBot.removeAllListeners();
      await ownerBot.stopPolling();
      ownerBot = null;
      console.log('🛑 Owner bot stopped');
    }
    
    // Get token from database or request body
    let token = req.body.botToken;
    
    if (!token) {
      const setting = await Settings.findOne({ key: 'OWNER_BOT_TOKEN' });
      token = setting?.value || process.env.TELEGRAM_BOT_TOKEN;
    }
    
    if (token) {
      initOwnerBot(token);
      console.log('✅ [API] Owner bot reloaded');
      res.json({ success: true, message: 'Owner bot reloaded' });
    } else {
      res.status(400).json({ error: 'No bot token available' });
    }
  } catch (error) {
    console.error('❌ [API] Reload owner bot error:', error);
    res.status(500).json({ error: error.message });
  }
});

// API: Get status of all bots
app.get('/api/bots/status', authMiddleware, (req, res) => {
  res.json({
    ownerBot: ownerBot ? 'active' : 'inactive',
    adminBots: Array.from(adminBots.entries()).map(([id, b]) => ({
      adminId: id,
      storeSlug: b.storeSlug,
      chatId: b.chatId,
      active: true
    })),
    totalActive: adminBots.size
  });
});

// Main startup
async function main() {
  try {
    console.log('🚀 Starting Standalone Bot Server...');

    // Connect to MongoDB
    const mongoUri = process.env.MONGODB_URI;
    if (!mongoUri) {
      throw new Error('MONGODB_URI not set');
    }

    await mongoose.connect(mongoUri);
    console.log('✅ MongoDB connected');

    // Try to get owner bot token from database first
    let ownerToken = process.env.TELEGRAM_BOT_TOKEN;
    try {
      const setting = await Settings.findOne({ key: 'OWNER_BOT_TOKEN' });
      if (setting?.value) {
        ownerToken = setting.value;
        console.log('📥 Using owner bot token from database');
      }
    } catch (e) {
      console.log('Using owner bot token from env');
    }

    // Initialize owner bot
    if (ownerToken) {
      initOwnerBot(ownerToken);
    }

    // Start all admin bots
    await startAllAdminBots();

    // Start express server
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`✅ Bot server running on port ${PORT}`);
      console.log(`📊 Owner bot: ${ownerBot ? 'active' : 'inactive'}`);
      console.log(`📊 Admin bots: ${adminBots.size}`);
    });

  } catch (error) {
    console.error('❌ Startup error:', error);
    process.exit(1);
  }
}

main();
