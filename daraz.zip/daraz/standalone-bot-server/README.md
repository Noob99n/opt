# Standalone Telegram Bot Server

This is a separate bot server for handling Telegram payment notifications. Run this on a single VPS while your main e-commerce website runs on multiple VPS servers behind a load balancer.

## Why Separate?

Telegram bots can only run ONE instance at a time. If you have 8 VPS servers running your website, only ONE should run the bot. This standalone server handles all bot functionality independently.

## Setup

### 1. Install Dependencies

```bash
cd standalone-bot-server
npm install
```

### 2. Configure Environment

Copy `.env.example` to `.env` and fill in your values:

```bash
cp .env.example .env
nano .env
```

Required variables:
- `MONGODB_URI` - Same MongoDB connection string as your main website
- `TELEGRAM_BOT_TOKEN` - Owner's Telegram bot token
- `OWNER_CHAT_ID` - Owner's Telegram chat ID

### 3. Run the Bot Server

```bash
npm start
```

Or with PM2 for production:

```bash
pm2 start index.js --name "telegram-bot"
pm2 save
```

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      LOAD BALANCER                          │
│                    (Your Main VPS)                          │
└───────────────────────────┬─────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
        ▼                   ▼                   ▼
┌───────────────┐   ┌───────────────┐   ┌───────────────┐
│   Website     │   │   Website     │   │   Website     │
│   VPS 1       │   │   VPS 2       │   │   VPS 3...8   │
│  (No Bot)     │   │  (No Bot)     │   │  (No Bot)     │
└───────────────┘   └───────────────┘   └───────────────┘
        │                   │                   │
        └───────────────────┼───────────────────┘
                            │
                            ▼
                    ┌───────────────┐
                    │   MongoDB     │
                    │   (Shared)    │
                    └───────────────┘
                            ▲
                            │
                    ┌───────────────┐
                    │   Bot Server  │
                    │  (This VPS)   │
                    │  Port 4000    │
                    └───────────────┘
```

## How It Works

1. **Websites create transactions** in MongoDB when users submit payment screenshots
2. **Bot server polls** MongoDB and sends notifications to Telegram
3. **Admin approves/declines** via Telegram buttons
4. **Bot server updates** transaction status in MongoDB
5. **Websites poll** for status updates and redirect users accordingly

## Features

### Owner Bot Commands
- `/start` - Welcome message
- `/status` - Today's payment statistics
- `/status_all` - Export all transactions
- `/approve_all` - Approve all pending payments
- `/decline_all` - Decline all pending payments
- `/change` - Upload new QR code
- `/delete` - Delete all logs (3-step confirmation)

### Admin Bot Commands (for tenant stores)
- `/start` - Store welcome
- `/status` - Today's summary
- `/statusall` - Recent transactions
- `/change` - Upload QR
- `/delete` - Delete logs
- `/approveall` - Approve all
- `/declineall` - Decline all

## Health Check & API Endpoints

The server provides these endpoints:

### Public Endpoints
- `GET /` - Returns bot status and count
- `GET /health` - Simple health check

### Protected API Endpoints (require `x-api-key` header)

**Start/Restart Admin Bot:**
```bash
curl -X POST http://bot-server:4000/api/admin-bot/start \
  -H "Content-Type: application/json" \
  -H "x-api-key: your-secret-api-key" \
  -d '{"adminId": "123", "botToken": "bot_token", "chatId": "chat_id", "storeSlug": "mystore"}'
```

**Stop Admin Bot:**
```bash
curl -X POST http://bot-server:4000/api/admin-bot/stop \
  -H "Content-Type: application/json" \
  -H "x-api-key: your-secret-api-key" \
  -d '{"adminId": "123"}'
```

**Refresh All Admin Bots:**
```bash
curl -X POST http://bot-server:4000/api/admin-bots/refresh \
  -H "x-api-key: your-secret-api-key"
```

**Reload Owner Bot:**
```bash
curl -X POST http://bot-server:4000/api/owner-bot/reload \
  -H "x-api-key: your-secret-api-key"
```

**Get All Bots Status:**
```bash
curl http://bot-server:4000/api/bots/status \
  -H "x-api-key: your-secret-api-key"
```

### Website Integration

When admin updates their bot token on the website, call the bot server API:

```javascript
// In your website's admin panel save handler
async function notifyBotServer(adminId, botToken, chatId, storeSlug) {
  const BOT_SERVER_URL = process.env.BOT_SERVER_URL || 'http://bot-vps:4000';
  const API_KEY = process.env.BOT_SERVER_API_KEY;
  
  await fetch(`${BOT_SERVER_URL}/api/admin-bot/start`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': API_KEY
    },
    body: JSON.stringify({ adminId, botToken, chatId, storeSlug })
  });
}
```

## Disable Bot in Main Website

On your 8 website VPS servers, you need to disable the Telegram bot initialization. 

Edit your main website's startup to skip bot initialization, or set:

```env
DISABLE_TELEGRAM_BOT=true
```

Then modify your main app to check this before starting bots.

## PM2 Ecosystem (Optional)

Create `ecosystem.config.js`:

```javascript
module.exports = {
  apps: [{
    name: 'telegram-bot',
    script: 'index.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '500M',
    env: {
      NODE_ENV: 'production'
    }
  }]
};
```

Run with: `pm2 start ecosystem.config.js`

## Troubleshooting

### Bot not responding
- Check if `TELEGRAM_BOT_TOKEN` is correct
- Ensure only ONE instance is running
- Check MongoDB connection

### Transactions not syncing
- Verify `MONGODB_URI` matches your website's database
- Check network connectivity

### Multiple bot instances error
- Make sure no other server is running the same bot token
- Kill any duplicate processes: `pkill -f "node index.js"`
