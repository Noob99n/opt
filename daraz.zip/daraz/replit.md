# E-commerce Application

## Overview
This full-stack e-commerce application, a Daraz replica, provides a complete shopping experience with a mobile-first responsive design. Key features include product browsing, cart management, a multi-step checkout process, and user account functionalities. A unique QR payment flow is integrated with an interactive chatbot and a Telegram bot for admin payment management. The project emphasizes a robust, scalable, and user-friendly platform with localized content (Nepali language) and efficient payment verification, alongside a universal product extraction system.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### UI/UX Decisions
- **Design**: Mobile-first responsive design.
- **Styling**: Tailwind CSS with a custom design system, Radix UI primitives, and shadcn/ui components.
- **Visuals**: Orange/purple color scheme, AI-generated SVG icons, dynamic promotional banners.
- **Localization**: Full Nepali language support for chatbot, flash sales, and UI.
- **Admin Panel**: Professional dark theme with subtle blue accents, English localization, and tab-based navigation.
- **Owner Panel**: Full desktop layout at `/owner` for multi-tenant admin management (password: via OWNER_PASSWORD env var, default Alex@123).

### Technical Implementations
- **Frontend**: React 18 with TypeScript, Vite, TanStack Query, and Wouter.
- **Backend**: Express.js with TypeScript on Node.js.
- **Database**: PostgreSQL (Neon Database) with Drizzle ORM for core e-commerce data; MongoDB for admin panel data, script collections, transaction logs, and QR code management.
- **API Design**: RESTful APIs with JSON responses.
- **Session Management**: Connect-pg-simple for PostgreSQL session storage; server-side admin authentication with session-based security (HttpOnly cookies).
- **Payment Flow**: Interactive chatbot-based QR payment verification.
- **Admin Management**: Telegram bot for payment verification, QR code management, and transaction logging; web-based admin panel for script and product creation.
- **Product Data**: Universal product extraction from any e-commerce website using a 3-layer strategy (Schema.org → Site-specific → Heuristics), supporting major platforms and 40+ currencies.

### Feature Specifications
- **Product Catalog**: Browsing, filtering, search, flash sales, dynamic displays.
- **Shopping Cart**: Real-time updates, quantity management, guest user persistence.
- **Checkout**: Multi-step process with address and various payment options.
- **QR Payment**: Dynamic QR code generation, screenshot upload for bot-guided verification.
- **User Account**: Profile and address management, order history.
- **Admin Panel**: Web-based (product/script creation) and Telegram-based (payment/stats/QR updates) with features like product editing, flash deal management, and dynamic script updates.
- **Multi-Tenant Admin System**: 
  - Owner Panel (`/owner`): Generate admin panels with expiration dates, manage scripts (add/edit/delete)
  - Admin Panel (`/admin`): Login with owner-assigned credentials, select and run scripts
  - **Complete Tenant Store Clone** (`/store/:slug/*`): Each admin gets a full website clone with all pages:
    - Home page: `/store/:slug` - Shows flash sales and products from admin's active script
    - Product detail: `/store/:slug/product/:id` - Full product page with images, specs, buy now
    - Cart: `/store/:slug/cart` - Shopping cart for the tenant store
    - Checkout: `/store/:slug/checkout` - Full checkout flow
    - Address: `/store/:slug/address` - Address management
    - Payment: `/store/:slug/payment` and `/store/:slug/qr-payment` - Payment flow
    - Categories: `/store/:slug/categories` - Category browsing
    - Search: `/store/:slug/search` - Product search
    - Account: `/store/:slug/account` - User account
  - **Architecture**: TenantContext provider extracts slug from URL and provides tenant state to all pages
    - **Unified Components**: HomeSimpleClean component is tenant-aware and serves both main site (/) and tenant stores (/store/:slug)
    - **API Path Transformation**: TenantContext.getApiPath() transforms all API calls (products, flash-sale, script-products, categories, search, qr-code, transactions, transaction-log, transaction-status)
    - **Route Path Transformation**: TenantContext.getRoutePath() transforms navigation paths to include /store/:slug prefix
  - Each admin has username, hashed password (bcrypt), expiry date, storeSlug, optional bot token/chat ID
  - Store shows products from admin's active script only (tenant isolation via scriptId)
  - **Multi-Tenant Bot System** (BotManager): Each admin gets their own fully functional Telegram bot
    - **Bot Features**: /start, /status, /statusall, /change (QR), /delete (transactions), /approve, /decline, /approveall, /declineall
    - **Bot Lifecycle**: Started automatically on app boot for all active admins with configured tokens
    - **Dynamic Management**: Bots start/stop when admin saves/deletes bot settings in Admin Panel
    - **Tenant Isolation**: Transactions and QRCodes include adminId/storeSlug for per-admin scoping
    - **Fallback**: If admin bot not active, tenant payments fall back to owner's bot
  - **Bot Coordination System** (server/bot-coordinator.ts): MongoDB-based multi-VPS coordination
    - **Heartbeat**: 30-second heartbeat, 90-second timeout for failover detection
    - **Auto-Failover**: If one VPS goes down, another automatically takes over bots
    - **Instance Tracking**: Each VPS gets unique instanceId, stored in BotCoordination MongoDB collection
    - **Shutdown Cleanup**: SIGINT/SIGTERM handlers mark bots inactive for proper failover
  - **Tenant Payment Flow**: Uses admin's bot via BotManager if active, falls back to owner's bot
  - Key files: `client/src/context/TenantContext.tsx`, `client/src/pages/home-simple-clean.tsx`, `server/models/Admin.ts`, `server/bot-manager.ts`
- **Pricing**: Transparent breakdown including original price, discount, delivery, and total.

### System Design Choices
- **Modularity**: Clear separation of frontend and backend.
- **Scalability**: Leverages serverless PostgreSQL and optimized API calls.
- **Data Persistence**: Hybrid database approach for varied data needs.
- **Performance**: Lazy loading, code splitting, optimized API calls.
- **Security**: Zod validation, screenshot enforcement, Replit Secrets for credentials, server-side admin authentication, bcrypt password hashing for admins.

## External Dependencies

- **Database Providers**: Neon Database (PostgreSQL), MongoDB Atlas
- **Frontend Libraries**:
    - `@tanstack/react-query`
    - `@radix-ui/*`
    - `tailwindcss`
    - `wouter`
    - `lucide-react`
- **Backend Libraries**:
    - `drizzle-orm`
    - `@neondatabase/serverless`
    - `express`
    - `zod`
    - `connect-pg-simple`
- **Development Tools**:
    - `vite`
    - `typescript`
    - `drizzle-kit`
    - `esbuild`
- **Third-party Integrations**:
    - Telegram Bot API
    - Cloudinary (for custom images and icons - *note: permanent storage needed for production QR codes*)