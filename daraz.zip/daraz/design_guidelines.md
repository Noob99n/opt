# E-Commerce Admin Dashboard Design Guidelines

## Design Approach
**System Selected**: Hybrid approach drawing from Linear's dashboard aesthetics + Vercel's data density + Stripe's professional restraint. Dark-themed admin interfaces prioritize information clarity, efficient workflows, and reduced eye strain during extended use.

**Core Principles**: 
- Information hierarchy through typography and spacing, not decoration
- High-contrast text for readability in dark environments
- Purposeful use of surfaces to separate functional areas
- Data-first design with minimal chrome

---

## Typography System

**Families**: 
- Primary: Inter (body, UI elements, data tables)
- Monospace: JetBrains Mono (codes, IDs, technical data)

**Scale**:
- Page titles: text-3xl font-semibold
- Section headers: text-xl font-semibold
- Card titles: text-lg font-medium
- Body/labels: text-sm
- Helper text: text-xs
- Table data: text-sm tabular-nums

---

## Layout System

**Spacing Primitives**: Use Tailwind units 2, 4, 6, 8, 12, 16
- Component padding: p-4 to p-6
- Section gaps: gap-6 to gap-8
- Card spacing: space-y-4
- Table cell padding: px-4 py-3

**Grid Structure**:
- Sidebar: Fixed 256px width (w-64)
- Main content: flex-1 with max-w-7xl container, px-8 py-6
- Dashboard cards: 3-column grid on desktop (grid-cols-3 gap-6)
- Full-width tables with sticky headers

---

## Component Library

### Navigation & Layout

**Sidebar** (Fixed left):
- Logo/brand at top (h-16)
- Navigation grouped by function: Dashboard, Admin Management, Script Management, Settings
- Active state with accent left border (border-l-2)
- Icons from Heroicons (outline style, w-5 h-5)
- Logout at bottom with divider

**Top Bar** (Sticky):
- Breadcrumb navigation (Dashboard > Admin Management)
- Search bar (w-96, prominent placement)
- User profile dropdown (right-aligned with avatar, role badge)
- Notification bell icon

### Dashboard Cards (3-column grid)

**Stat Cards** (First row):
- Large metric (text-4xl font-bold)
- Label below (text-sm opacity-70)
- Trend indicator with arrow icon
- Compact height (h-32)
- Border treatment on surface

**Activity Cards** (Second row):
- Recent admin actions list (5 items, truncated)
- Script execution status
- System health metrics
- Each with "View All" link in card footer

### Admin Management Table

**Layout**:
- Full-width with rounded surface
- Column headers: sticky top-0, uppercase text-xs font-semibold tracking-wide
- Columns: Avatar + Name, Email, Role (badge), Status (badge), Last Active, Actions
- Row height: h-16 with hover state
- Checkbox column for bulk actions

**Actions Bar** (Above table):
- "Add Admin" primary button (right-aligned)
- Bulk action dropdown (visible when rows selected)
- Filter/sort controls (left-aligned)
- Results count

**Action Buttons** (Per row):
- Edit icon button
- Delete icon button (destructive styling)
- More options menu (3-dot)

### Script Management Interface

**Two-Panel Layout**:
- Left: Script list (w-80, scrollable)
  - Search filter at top
  - Script cards with: name, description snippet, last modified, status badge
  - Add Script FAB at bottom
  
- Right: Script detail/editor (flex-1)
  - Header with script name (editable inline), status toggle
  - Code editor area (monospace, line numbers, syntax highlighting placeholder)
  - Metadata panel: Created, Modified, Author, Tags
  - Action buttons: Save, Delete, Duplicate (sticky bottom bar)

### Form Components

**Input Fields**:
- Label above (text-sm font-medium, mb-2)
- Input with focus ring (ring-2 on focus)
- Helper text below (text-xs)
- Error states with icon

**Buttons**:
- Primary: Accent styling, font-medium, px-6 py-2.5
- Secondary: Outlined style
- Destructive: Red accent for delete actions
- Icon buttons: p-2, rounded-md

**Modals**:
- Centered overlay (backdrop blur)
- Max-w-md for forms, max-w-2xl for complex actions
- Header with title and close button
- Content with scrollable body
- Footer with action buttons (Cancel left, Primary right)

### Data Tables (Shared pattern)

**Structure**:
- Bordered surface with rounded corners
- Alternating row treatment (subtle)
- Sortable headers (with sort indicators)
- Pagination footer (showing X-Y of Z, page controls)
- Empty state with illustration placeholder and CTA

**Badges**:
- Role: Small, uppercase, px-2 py-1, rounded-full
- Status: Dot indicator + text (Active, Inactive, Pending)

---

## Interaction Patterns

**Loading States**: Skeleton screens maintaining layout, spinner for actions
**Confirmations**: Modal dialogs for destructive actions with explicit confirmation
**Notifications**: Toast messages (top-right, auto-dismiss, stacked)
**Drag-and-drop**: Script reordering (visual feedback with ghost element)

---

## Images
No hero images. Admin dashboards are data-focused. Only use small avatar images for user profiles (32px circular) and optional empty state illustrations (max 200px, centered, muted styling).