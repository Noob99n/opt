// PostgreSQL is NOT used - all data is in MongoDB
// This file is only kept for TypeScript imports compatibility
// No actual database connections are made

export const pool = null as any;
export const db = null as any;
