import express, { type Request, Response, NextFunction } from "express";
import session from "express-session";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log as viteLog } from "./vite";
import { initTelegramBot, initBotFromOwnerSettings } from "./telegram-bot";
import { startAllAdminBots } from "./bot-manager";
import { log, error as logError } from "./logger";

// Set MongoDB URI if not already set
if (!process.env.MONGODB_URI) {
  process.env.MONGODB_URI = 'mongodb+srv://iamnew:XVhDWjoyhewSjx9R@web.zmozins.mongodb.net/?retryWrites=true&w=majority&appName=Web';
}

// Initialize Telegram bots - owner and all admin bots
(async () => {
  // Start owner's bot first
  const ownerBotLoaded = await initBotFromOwnerSettings();
  if (!ownerBotLoaded) {
    // Fallback to env variable if no owner bot configured
    initTelegramBot();
  }
  
  // Start all admin bots with configured tokens
  // Small delay to allow MongoDB to connect first
  setTimeout(async () => {
    try {
      await startAllAdminBots();
      log('✅ All admin bots initialized');
    } catch (error) {
      logError('❌ Error starting admin bots:', error);
    }
  }, 3000);
})();

const app = express();

// IMPORTANT: Add session middleware FIRST, before any other middleware
// This ensures req.session is available for all routes and logging
// For VPS: Set FORCE_HTTPS=true if using HTTPS, otherwise cookies work on HTTP too
const isHttps = process.env.FORCE_HTTPS === 'true';
app.set('trust proxy', 1); // Trust first proxy (needed for VPS behind nginx/reverse proxy)
app.use(session({
  secret: process.env.SESSION_SECRET || 'default_session_secret_change_me_in_production',
  resave: true, // Changed to true for better compatibility
  saveUninitialized: false,
  rolling: true, // Auto-renew session on every request to prevent logout
  cookie: {
    secure: isHttps, // Only secure if explicitly using HTTPS
    httpOnly: true,
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    sameSite: isHttps ? 'none' : 'lax', // 'none' for cross-site HTTPS, 'lax' for same-site
    path: '/'
  }
}));

app.use(express.json({ limit: '10mb' })); // Increased for screenshot uploads
app.use(express.urlencoded({ extended: false, limit: '10mb' }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      // Only log errors, not successful GET requests
      if (res.statusCode >= 400 || req.method !== "GET") {
        let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
        if (capturedJsonResponse) {
          logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
        }

        if (logLine.length > 80) {
          logLine = logLine.slice(0, 79) + "…";
        }

        log(logLine);
      }
    }
  });

  next();
});

(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
