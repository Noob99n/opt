import TelegramBot from 'node-telegram-bot-api';
import TransactionLog from './models/TransactionLog';
import QRCode from './models/QRCode';
import BotSettings from './models/BotSettings';
import FormData from 'form-data';
import { log, error as logError } from './logger';
import { uploadQRToCloudinary, deleteFromCloudinary } from './cloudinary';

const ADMIN_USER_ID = 7646520243; // Fallback default admin
const BOT_TOKEN = ''; // Bot token comes from MongoDB only, no .env needed

let bot: TelegramBot | null = null;
let currentBotToken: string = ''; // Store the actual token being used
let deleteConfirmation: { [key: number]: number } = {};

// Helper function to check if user is admin
async function isAdmin(userId: number): Promise<boolean> {
  try {
    const settings = await BotSettings.findOne();
    if (!settings || !settings.admins || settings.admins.length === 0) {
      // Fallback to hardcoded admin if no settings
      return userId === ADMIN_USER_ID;
    }
    return settings.admins.some((admin: any) => admin.userId === userId);
  } catch (error) {
    console.error('Error checking admin status:', error);
    // Fallback to hardcoded admin on error
    return userId === ADMIN_USER_ID;
  }
}

// Helper function to get all admin user IDs
async function getAllAdminIds(): Promise<number[]> {
  try {
    const settings = await BotSettings.findOne();
    if (!settings || !settings.admins || settings.admins.length === 0) {
      return [ADMIN_USER_ID]; // Fallback
    }
    return settings.admins.map((admin: any) => admin.userId);
  } catch (error) {
    console.error('Error getting admin IDs:', error);
    return [ADMIN_USER_ID]; // Fallback
  }
}

export function initTelegramBot(token?: string) {
  const actualToken = token || BOT_TOKEN;
  
  if (!actualToken) {
    log('⚠️ TELEGRAM_BOT_TOKEN not set. Telegram bot disabled.');
    return null;
  }

  try {
    currentBotToken = actualToken; // Store the token for later use
    bot = new TelegramBot(actualToken, { polling: true });
    log('✅ Telegram bot initialized successfully');

    bot.on('message', async (msg) => {
      const chatId = msg.chat.id;
      const userId = msg.from?.id || 0;
      const text = msg.text || '';

      // Check if user is admin (dynamic check from database)
      const userIsAdmin = await isAdmin(userId);
      if (!userIsAdmin) {
        await bot?.sendMessage(chatId, '❌ You are not authorised to use this bot.');
        return;
      }

      if (text === '/start') {
        await handleStart(chatId);
      } else if (text === '/status') {
        await handleStatus(chatId);
      } else if (text === '/status_all') {
        await handleStatusAll(chatId);
      } else if (text === '/change') {
        await handleChange(chatId);
      } else if (text === '/delete') {
        console.log(`📝 DELETE command received from user: ${userId}`);
        await handleDelete(chatId, userId);
      } else if (text.startsWith('/delete_confirm_')) {
        const step = parseInt(text.replace('/delete_confirm_', ''));
        console.log(`📝 DELETE_CONFIRM command received - User: ${userId}, Text: "${text}", Extracted Step: ${step}`);
        await handleDeleteConfirm(chatId, userId, step);
      } else if (text === '/approve_all') {
        await handleApproveAll(chatId);
      } else if (text === '/decline_all') {
        await handleDeclineAll(chatId);
      } else if (text.startsWith('/approve_')) {
        const txId = text.replace('/approve_', '');
        await handleApprove(chatId, txId);
      } else if (text.startsWith('/decline_')) {
        const txId = text.replace('/decline_', '');
        await handleDecline(chatId, txId);
      } else if (msg.photo && msg.photo.length > 0) {
        await handleQRUpload(chatId, msg.photo[msg.photo.length - 1].file_id);
      }
    });

    // Handle callback queries (inline keyboard buttons)
    bot.on('callback_query', async (query) => {
      const chatId = query.message?.chat.id;
      const userId = query.from.id;

      // Check if user is admin (dynamic check from database)
      const userIsAdmin = await isAdmin(userId);
      if (!chatId || !userIsAdmin) {
        await bot?.answerCallbackQuery(query.id, { text: '❌ Not authorised' });
        return;
      }

      const data = query.data;
      if (data?.startsWith('approve_')) {
        const txId = data.replace('approve_', '');
        await handleApprove(chatId, txId, query.id);
      } else if (data?.startsWith('decline_')) {
        const txId = data.replace('decline_', '');
        await handleDecline(chatId, txId, query.id);
      }
    });

    return bot;
  } catch (error) {
    console.error('❌ Failed to initialize Telegram bot:', error);
    return null;
  }
}

async function handleStart(chatId: number) {
  const message = `
🤖 *Welcome Admin!*

Available Commands:

📊 */status* - View today's approved payment statistics
📄 */status_all* - Export all transactions as TXT file
✅ */approve_all* - Approve all pending payments
❌ */decline_all* - Decline all pending payments
🔄 */change* - Upload new QR code image
🗑️ */delete* - Delete all transaction logs (requires confirmation)

ℹ️ Payment screenshots are automatically forwarded here.
✅ Click Approve/Decline buttons to manage individual payments.
  `;

  await bot?.sendMessage(chatId, message, { parse_mode: 'Markdown' });
}

async function handleStatus(chatId: number) {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayTransactions = await TransactionLog.find({
      timestamp: { $gte: today }
    });

    const count = todayTransactions.length;
    const approved = todayTransactions.filter(t => t.status === 'approved').length;
    const declined = todayTransactions.filter(t => t.status === 'declined').length;
    const pending = todayTransactions.filter(t => t.status === 'pending').length;
    
    // Total amount = only approved payments
    const approvedAmount = todayTransactions
      .filter(t => t.status === 'approved')
      .reduce((sum, t) => sum + t.amount, 0);

    const message = `
📊 *Today's Payment Statistics*

📅 Date: ${today.toLocaleDateString('en-IN')}

💰 Total Submissions: ${count}
✅ Approved: ${approved}
❌ Declined: ${declined}
⏳ Pending: ${pending}

💵 *Total Collected (Approved Only): Rs. ${approvedAmount.toLocaleString()}*

Last updated: ${new Date().toLocaleTimeString('en-IN')}
    `;

    await bot?.sendMessage(chatId, message, { parse_mode: 'Markdown' });
  } catch (error) {
    const err = error as Error;
    await bot?.sendMessage(chatId, '❌ Error fetching statistics: ' + err.message);
  }
}

async function handleStatusAll(chatId: number) {
  try {
    const allTransactions = await TransactionLog.find().sort({ timestamp: 1 });

    if (allTransactions.length === 0) {
      await bot?.sendMessage(chatId, '📄 No transactions found.');
      return;
    }

    let txtContent = '=== ALL TRANSACTION LOGS ===\n\n';
    
    allTransactions.forEach((t, index) => {
      txtContent += `${index + 1}. Transaction ID: ${t._id}\n`;
      txtContent += `   Date: ${new Date(t.timestamp).toLocaleString('en-IN')}\n`;
      txtContent += `   Product: ${t.productTitle}\n`;
      txtContent += `   Amount: Rs. ${t.amount.toLocaleString()}\n`;
      txtContent += `   Status: ${t.status.toUpperCase()}\n`;
      txtContent += `   User: ${t.userId}\n`;
      txtContent += `   ----------------------------------------\n\n`;
    });

    const approved = allTransactions.filter(t => t.status === 'approved');
    const approvedTotal = approved.reduce((sum, t) => sum + t.amount, 0);
    
    txtContent += `\nTotal Transactions: ${allTransactions.length}\n`;
    txtContent += `Approved: ${approved.length}\n`;
    txtContent += `Total Amount (All): Rs. ${allTransactions.reduce((sum, t) => sum + t.amount, 0).toLocaleString()}\n`;
    txtContent += `Total Collected (Approved Only): Rs. ${approvedTotal.toLocaleString()}\n`;
    txtContent += `Generated: ${new Date().toLocaleString('en-IN')}\n`;

    const buffer = Buffer.from(txtContent, 'utf-8');
    const filename = `transactions_${Date.now()}.txt`;
    
    await bot?.sendDocument(chatId, buffer, {
      caption: `📄 All transaction logs exported\nTotal: ${allTransactions.length} transactions`
    }, {
      filename: filename
    });
  } catch (error) {
    const err = error as Error;
    await bot?.sendMessage(chatId, '❌ Error exporting transactions: ' + err.message);
  }
}

async function handleChange(chatId: number) {
  const message = `
🔄 *Change QR Code*

Please upload the new QR code image.

Send the photo directly to this chat, and it will be updated on the website automatically.
  `;

  await bot?.sendMessage(chatId, message, { parse_mode: 'Markdown' });
}

async function handleQRUpload(chatId: number, fileId: string) {
  try {
    // Get file from Telegram
    const file = await bot?.getFile(fileId);
    if (!file || !file.file_path) {
      throw new Error('Failed to get file path');
    }

    // Construct download URL from Telegram
    const telegramFileUrl = `https://api.telegram.org/file/bot${currentBotToken}/${file.file_path}`;

    // Get existing QR to delete old image from Cloudinary
    const existingQR = await QRCode.findOne({ adminId: null });
    if (existingQR?.cloudinaryPublicId) {
      console.log('🗑️ Deleting old QR from Cloudinary:', existingQR.cloudinaryPublicId);
      await deleteFromCloudinary(existingQR.cloudinaryPublicId);
    }

    // Upload to Cloudinary
    await bot?.sendMessage(chatId, '⏳ Uploading QR to cloud...');
    const cloudinaryResult = await uploadQRToCloudinary(telegramFileUrl, 'qr-codes/owner');

    // Update QR code in database with Cloudinary URL
    await QRCode.findOneAndUpdate(
      { adminId: null },
      {
        imageUrl: cloudinaryResult.url,
        cloudinaryPublicId: cloudinaryResult.publicId,
        updatedAt: new Date(),
        updatedBy: 'owner-bot'
      },
      { upsert: true, new: true }
    );

    console.log('✅ QR code uploaded to Cloudinary:', cloudinaryResult.url);
    await bot?.sendMessage(chatId, '✅ QR code uploaded successfully! The new QR is now live on the website.');
  } catch (error) {
    const err = error as Error;
    console.error('❌ Error updating QR code:', err);
    await bot?.sendMessage(chatId, '❌ Error updating QR code: ' + err.message);
  }
}

async function handleDelete(chatId: number, userId: number) {
  deleteConfirmation[userId] = 1;

  const message = `
⚠️ *WARNING: DELETE ALL TRANSACTION LOGS*

🗑️ This will permanently delete ALL transaction logs from the database.

❗ This action CANNOT be undone!

📊 Step 1 of 3

Type: \`/delete_confirm_1\` to proceed
  `;

  await bot?.sendMessage(chatId, message, { parse_mode: 'Markdown' });
}

async function handleDeleteConfirm(chatId: number, userId: number, step: number) {
  const currentStep = deleteConfirmation[userId] || 0;
  
  console.log(`🔍 Delete confirmation - User: ${userId}, Step requested: ${step}, Current state: ${currentStep}`);

  if (step !== currentStep) {
    const message = `❌ *Invalid confirmation step*

📍 Your current step: ${currentStep === 0 ? 'Not started' : currentStep}
❌ You tried: Step ${step}

Please start with \`/delete\` command first`;
    console.log(`❌ Step mismatch - User ${userId} tried step ${step} but current is ${currentStep}`);
    await bot?.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    return;
  }

  if (step === 1) {
    deleteConfirmation[userId] = 2;
    console.log(`✅ Step 1 completed - Setting user ${userId} to step 2`);
    const message = `⚠️ *SECOND CONFIRMATION REQUIRED*

📊 Step 2 of 3

Are you absolutely sure you want to delete all logs?

Type: \`/delete_confirm_2\` to continue`;
    await bot?.sendMessage(chatId, message, { parse_mode: 'Markdown' });
  } else if (step === 2) {
    deleteConfirmation[userId] = 3;
    console.log(`✅ Step 2 completed - Setting user ${userId} to step 3`);
    const message = `🚨 *FINAL CONFIRMATION REQUIRED*

📊 Step 3 of 3

⚠️ LAST CHANCE TO CANCEL!

This will DELETE ALL transaction logs permanently.

Type: \`/delete_confirm_3\` to DELETE ALL LOGS`;
    await bot?.sendMessage(chatId, message, { parse_mode: 'Markdown' });
  } else if (step === 3) {
    try {
      console.log(`🗑️ Step 3 - Deleting all transaction logs for user ${userId}`);
      const result = await TransactionLog.deleteMany({});
      delete deleteConfirmation[userId];
      console.log(`✅ Deleted ${result.deletedCount} transaction logs`);
      
      const message = `✅ *ALL TRANSACTION LOGS DELETED*

📊 Total deleted: ${result.deletedCount} records

The database is now empty.`;
      await bot?.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } catch (error) {
      const err = error as Error;
      console.error(`❌ Error deleting logs:`, err);
      await bot?.sendMessage(chatId, '❌ Error deleting logs: ' + err.message);
    }
  }
}

async function handleApprove(chatId: number, txId: string, queryId?: string) {
  try {
    console.log('🔵 [APPROVE] Starting approval for txId:', txId);
    
    const transaction = await TransactionLog.findById(txId);
    console.log('🔵 [APPROVE] Transaction found:', transaction ? 'YES' : 'NO');
    
    if (!transaction) {
      console.log('❌ [APPROVE] Transaction not found in database');
      const msg = '❌ Transaction not found.';
      if (queryId) await bot?.answerCallbackQuery(queryId, { text: msg });
      else await bot?.sendMessage(chatId, msg);
      return;
    }

    console.log('🔵 [APPROVE] Current status:', transaction.status);
    console.log('🔵 [APPROVE] Transaction details:', {
      id: transaction._id,
      product: transaction.productTitle,
      amount: transaction.amount,
      status: transaction.status
    });

    if (transaction.status !== 'pending') {
      console.log('⚠️ [APPROVE] Transaction already processed:', transaction.status);
      const msg = `⚠️ Already ${transaction.status}`;
      if (queryId) await bot?.answerCallbackQuery(queryId, { text: msg });
      else await bot?.sendMessage(chatId, msg);
      return;
    }

    console.log('🔵 [APPROVE] Updating status to approved...');
    transaction.status = 'approved';
    
    console.log('🔵 [APPROVE] Saving to database...');
    const savedTransaction = await transaction.save();
    console.log('✅ [APPROVE] SAVED! New status:', savedTransaction.status);
    console.log('✅ [APPROVE] Saved transaction ID:', savedTransaction._id);

    // Verify the save by re-fetching
    const verifyTransaction = await TransactionLog.findById(txId);
    console.log('🔍 [APPROVE] Verification check - Status in DB:', verifyTransaction?.status);

    const message = `✅ *Payment APPROVED*\n\n📦 ${transaction.productTitle}\n💰 Rs. ${transaction.amount.toLocaleString()}`;
    
    if (queryId) {
      await bot?.answerCallbackQuery(queryId, { text: '✅ Approved!' });
      await bot?.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } else {
      await bot?.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    }
    
    console.log('✅ [APPROVE] Process complete!');
  } catch (error) {
    const err = error as Error;
    console.error('❌ [APPROVE] ERROR:', err.message);
    console.error('❌ [APPROVE] Stack:', err.stack);
    const msg = '❌ Error: ' + err.message;
    if (queryId) await bot?.answerCallbackQuery(queryId, { text: msg });
    else await bot?.sendMessage(chatId, msg);
  }
}

async function handleDecline(chatId: number, txId: string, queryId?: string) {
  try {
    const transaction = await TransactionLog.findById(txId);
    
    if (!transaction) {
      const msg = '❌ Transaction not found.';
      if (queryId) await bot?.answerCallbackQuery(queryId, { text: msg });
      else await bot?.sendMessage(chatId, msg);
      return;
    }

    if (transaction.status !== 'pending') {
      const msg = `⚠️ Already ${transaction.status}`;
      if (queryId) await bot?.answerCallbackQuery(queryId, { text: msg });
      else await bot?.sendMessage(chatId, msg);
      return;
    }

    transaction.status = 'declined';
    await transaction.save();

    const message = `❌ *Payment DECLINED*\n\n📦 ${transaction.productTitle}\n💰 Rs. ${transaction.amount.toLocaleString()}`;
    
    if (queryId) {
      await bot?.answerCallbackQuery(queryId, { text: '❌ Declined' });
      await bot?.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } else {
      await bot?.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    }
  } catch (error) {
    const err = error as Error;
    const msg = '❌ Error: ' + err.message;
    if (queryId) await bot?.answerCallbackQuery(queryId, { text: msg });
    else await bot?.sendMessage(chatId, msg);
  }
}

async function handleApproveAll(chatId: number) {
  try {
    const pendingTransactions = await TransactionLog.find({ status: 'pending' });
    
    if (pendingTransactions.length === 0) {
      await bot?.sendMessage(chatId, '⚠️ No pending payments to approve.');
      return;
    }

    let approvedCount = 0;
    let totalAmount = 0;

    for (const transaction of pendingTransactions) {
      transaction.status = 'approved';
      await transaction.save();
      approvedCount++;
      totalAmount += transaction.amount;
    }

    const message = `
✅ *Bulk Approval Successful!*

📊 Approved Payments: ${approvedCount}
💰 Total Amount: Rs. ${totalAmount.toLocaleString()}

All pending payments have been approved.
    `;

    await bot?.sendMessage(chatId, message, { parse_mode: 'Markdown' });
  } catch (error) {
    const err = error as Error;
    await bot?.sendMessage(chatId, '❌ Error approving all payments: ' + err.message);
  }
}

async function handleDeclineAll(chatId: number) {
  try {
    const pendingTransactions = await TransactionLog.find({ status: 'pending' });
    
    if (pendingTransactions.length === 0) {
      await bot?.sendMessage(chatId, '⚠️ No pending payments to decline.');
      return;
    }

    let declinedCount = 0;
    let totalAmount = 0;

    for (const transaction of pendingTransactions) {
      transaction.status = 'declined';
      await transaction.save();
      declinedCount++;
      totalAmount += transaction.amount;
    }

    const message = `
❌ *Bulk Decline Successful!*

📊 Declined Payments: ${declinedCount}
💰 Total Amount: Rs. ${totalAmount.toLocaleString()}

All pending payments have been declined.
    `;

    await bot?.sendMessage(chatId, message, { parse_mode: 'Markdown' });
  } catch (error) {
    const err = error as Error;
    await bot?.sendMessage(chatId, '❌ Error declining all payments: ' + err.message);
  }
}

export async function forwardScreenshotToAdmin(
  productTitle: string,
  amount: number,
  screenshotBase64: string,
  transactionId: string
) {
  if (!bot) return;

  try {
    console.log('📤 [TELEGRAM] Forwarding screenshot to admins for txId:', transactionId);
    
    const buffer = Buffer.from(screenshotBase64.split(',')[1], 'base64');
    
    const message = `
💳 *New Payment Screenshot*

📦 Product: ${productTitle}
💰 Amount: Rs. ${amount.toLocaleString()}
🕐 Time: ${new Date().toLocaleString('en-IN')}
🆔 ID: ${transactionId.substring(transactionId.length - 6)}

⏳ Status: Pending Review
    `;

    // Get all admin IDs and send to each
    const adminIds = await getAllAdminIds();
    console.log(`📤 [TELEGRAM] Sending to ${adminIds.length} admin(s):`, adminIds);

    for (const adminId of adminIds) {
      try {
        await bot.sendPhoto(adminId, buffer, {
          caption: message,
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: [
              [
                { text: '✅ Approve', callback_data: `approve_${transactionId}` },
                { text: '❌ Decline', callback_data: `decline_${transactionId}` }
              ]
            ]
          }
        });
        console.log(`✅ [TELEGRAM] Screenshot sent to admin ${adminId}`);
      } catch (err) {
        console.error(`❌ [TELEGRAM] Failed to send to admin ${adminId}:`, err);
      }
    }
    
    console.log('✅ [TELEGRAM] Screenshot sent to all admins with approve/decline buttons');
  } catch (error) {
    console.error('❌ [TELEGRAM] Error forwarding screenshot to admins:', error);
    throw error;
  }
}

export function getTelegramBot() {
  return bot;
}

// Send payment notification using custom bot token/chat (for tenant admins)
export async function sendTenantPaymentNotification(
  botToken: string,
  chatId: string,
  productTitle: string,
  amount: number,
  screenshotBase64: string,
  transactionId: string
): Promise<boolean> {
  try {
    const TelegramBot = (await import('node-telegram-bot-api')).default;
    const tenantBot = new TelegramBot(botToken, { polling: false });
    
    const buffer = Buffer.from(screenshotBase64.split(',')[1], 'base64');
    
    const message = `
💳 *New Payment Screenshot*

📦 Product: ${productTitle}
💰 Amount: Rs. ${amount.toLocaleString()}
🕐 Time: ${new Date().toLocaleString('en-IN')}
🆔 ID: ${transactionId.substring(transactionId.length - 6)}

⏳ Status: Pending Review

_Use owner panel to approve/decline_
    `;

    await tenantBot.sendPhoto(parseInt(chatId), buffer, {
      caption: message,
      parse_mode: 'Markdown'
    });
    
    console.log(`✅ [TENANT BOT] Screenshot sent to admin chat ${chatId}`);
    return true;
  } catch (error) {
    console.error('❌ [TENANT BOT] Error sending notification:', error);
    return false;
  }
}

// Initialize bot from Owner settings in MongoDB
export async function initBotFromOwnerSettings(): Promise<boolean> {
  try {
    const connectDB = (await import('./mongodb')).default;
    await connectDB();
    const { getSetting } = await import('./models/Settings');
    const ownerBotToken = await getSetting('OWNER_BOT_TOKEN');
    
    if (ownerBotToken) {
      log('🔄 Loading owner bot token from database...');
      initTelegramBot(ownerBotToken);
      return true;
    }
    return false;
  } catch (error) {
    logError('Error loading owner bot settings:', error);
    return false;
  }
}

// Restart bot with new token
export async function restartTelegramBot(newToken: string): Promise<boolean> {
  try {
    log('🔄 Restarting Telegram bot with new token...');
    
    // Stop current bot if exists and clean up ALL resources
    if (bot) {
      try {
        // Remove all event listeners to prevent duplicate handlers
        bot.removeAllListeners('message');
        bot.removeAllListeners('callback_query');
        bot.removeAllListeners('polling_error');
        
        // Stop polling
        await bot.stopPolling();
        log('✅ Previous bot stopped and listeners removed successfully');
      } catch (err) {
        logError('⚠️ Error stopping previous bot:', err);
      }
      
      // Clear the bot reference
      bot = null;
    }
    
    // Small delay to ensure cleanup
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Initialize new bot with new token
    initTelegramBot(newToken);
    
    log('✅ Telegram bot restarted successfully with new token');
    return true;
  } catch (error) {
    logError('❌ Error restarting Telegram bot:', error);
    return false;
  }
}
