import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { forwardScreenshotToAdmin } from "./telegram-bot";
import Admin from "./models/Admin";
import ScriptProduct from "./models/ScriptProduct";
import TransactionLog from "./models/TransactionLog";
// MongoDB validation schemas - temporarily using simple validation
import { z } from "zod";

// Admin validation schemas
const createAdminSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters").max(50).trim(),
  password: z.string().min(4, "Password must be at least 4 characters"),
  expiryDays: z.number().int().min(1).max(365),
  botToken: z.string().optional().nullable(),
  botChatId: z.string().optional().nullable()
});

const updateAdminSchema = z.object({
  password: z.string().min(4).optional(),
  expiryDays: z.number().int().min(1).max(365).optional(),
  isActive: z.boolean().optional(),
  botToken: z.string().optional().nullable(),
  botChatId: z.string().optional().nullable()
});

// Zod validation schemas for Script Management
const createScriptSchema = z.object({
  name: z.string().min(1, "Script name is required").max(100).trim(),
  description: z.string().optional().default(''),
  category: z.enum(['Phone', 'Accessories', 'Electronics', 'Fashion', 'Other']).optional().default('Other'),
  tags: z.array(z.string()).optional().default([]),
  priority: z.number().int().min(0).max(100).optional().default(0),
  visibility: z.enum(['public', 'private', 'scheduled']).optional().default('private'),
  status: z.enum(['active', 'inactive', 'draft', 'archived']).optional().default('draft'),
  deploymentNotes: z.string().optional().default(''),
  metadata: z.record(z.any()).optional().default({}),
  config: z.object({
    maxProducts: z.number().optional().default(50),
    allowFlashDeals: z.boolean().optional().default(true),
    autoActivate: z.boolean().optional().default(false)
  }).optional(),
  scheduledStartDate: z.string().datetime().optional().nullable(),
  scheduledEndDate: z.string().datetime().optional().nullable()
});

const updateScriptSchema = z.object({
  name: z.string().min(1).max(100).trim().optional(),
  description: z.string().optional(),
  category: z.enum(['Phone', 'Accessories', 'Electronics', 'Fashion', 'Other']).optional(),
  tags: z.array(z.string()).optional(),
  priority: z.number().int().min(0).max(100).optional(),
  visibility: z.enum(['public', 'private', 'scheduled']).optional(),
  status: z.enum(['active', 'inactive', 'draft', 'archived']).optional(),
  deploymentNotes: z.string().optional(),
  metadata: z.record(z.any()).optional(),
  config: z.object({
    maxProducts: z.number().optional(),
    allowFlashDeals: z.boolean().optional(),
    autoActivate: z.boolean().optional()
  }).optional(),
  scheduledStartDate: z.string().datetime().optional().nullable(),
  scheduledEndDate: z.string().datetime().optional().nullable(),
  additionalInfo: z.string().optional()
});

const bulkOperationSchema = z.object({
  scriptIds: z.array(z.string()).min(1, "At least one script ID is required"),
  operation: z.enum(['activate', 'deactivate', 'archive', 'delete']),
  metadata: z.record(z.any()).optional()
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Helper: Get owner's active script products (main store uses owner's running script)
  // Returns null if no active script OR if script has no products (triggers fallback to shared catalog)
  async function getOwnerScriptProducts(): Promise<any[] | null> {
    try {
      const connectDB = (await import('./mongodb')).default;
      await connectDB();
      const { getSetting } = await import('./models/Settings');
      const activeScriptId = await getSetting('OWNER_ACTIVE_SCRIPT');
      if (activeScriptId) {
        const products = await storage.getScriptProducts(activeScriptId);
        return products && products.length > 0 ? products : null;
      }
      return null;
    } catch (error) {
      console.error('Error getting owner script products:', error);
      return null;
    }
  }

  // Products - uses owner's running script, falls back to shared catalog
  app.get("/api/products", async (req, res) => {
    try {
      const ownerProducts = await getOwnerScriptProducts();
      if (ownerProducts) {
        return res.json(ownerProducts);
      }
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const id = req.params.id;
      const ownerProducts = await getOwnerScriptProducts();
      if (ownerProducts) {
        const product = ownerProducts.find((p: any) => 
          p._id?.toString() === id || p.id?.toString() === id
        );
        if (product) return res.json(product);
      }
      const product = await storage.getProduct(id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  // New slug-based route for SEO-friendly URLs
  app.get("/api/products/slug/:slug", async (req, res) => {
    try {
      const slug = req.params.slug;
      const ownerProducts = await getOwnerScriptProducts();
      if (ownerProducts) {
        const product = ownerProducts.find((p: any) => p.slug === slug);
        if (product) return res.json(product);
      }
      const product = await storage.getProductBySlug(slug);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  app.get("/api/products/category/:category", async (req, res) => {
    try {
      const category = req.params.category;
      const ownerProducts = await getOwnerScriptProducts();
      if (ownerProducts) {
        const filtered = ownerProducts.filter((p: any) => 
          p.category?.toLowerCase() === category.toLowerCase()
        );
        if (filtered.length > 0) return res.json(filtered);
      }
      const products = await storage.getProductsByCategory(category);
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products by category" });
    }
  });

  app.get("/api/products/search/:query", async (req, res) => {
    try {
      const query = req.params.query.toLowerCase();
      const ownerProducts = await getOwnerScriptProducts();
      if (ownerProducts) {
        const filtered = ownerProducts.filter((p: any) => 
          p.name?.toLowerCase().includes(query) || 
          p.description?.toLowerCase().includes(query)
        );
        if (filtered.length > 0) return res.json(filtered);
      }
      const products = await storage.searchProducts(query);
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to search products" });
    }
  });

  app.get("/api/flash-sale", async (req, res) => {
    try {
      const ownerProducts = await getOwnerScriptProducts();
      if (ownerProducts) {
        const flashProducts = ownerProducts.filter((p: any) => p.isFlashDeal);
        if (flashProducts.length > 0) return res.json(flashProducts);
      }
      const products = await storage.getFlashSaleProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch flash sale products" });
    }
  });

  // New endpoint for all script products (both flash and regular)
  app.get("/api/script-products", async (req, res) => {
    try {
      // Use owner's active script for the main store
      const ownerProducts = await getOwnerScriptProducts();
      if (ownerProducts && ownerProducts.length > 0) {
        return res.json(ownerProducts);
      }
      // Fallback to shared catalog
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      console.error('Error getting script products:', error);
      res.status(500).json({ error: "Failed to fetch script products" });
    }
  });

  // Helper function to calculate discount percentage
  function calculateDiscount(originalPrice: string, currentPrice: string): number {
    // Sanitize prices: remove ALL currency symbols, commas, and spaces
    const sanitize = (price: string) => {
      const cleaned = price
        // Remove all currency symbols and tokens
        .replace(/₹|\$|€|£|¥|₱|रु|₭|₫|RM|MYR|SG\$|SGD|S\$|฿|THB|₦|NGN|₨|Rs\.?|NPR|Rp|IDR|₵|GHS|CA\$|CAD|A\$|AUD|NZ\$|NZD|CHF|₺|TRY|SAR|ر\.س|QAR|ر\.ق|AED|د\.إ|BDT|৳|LKR|ரூ|USD|INR|PHP/gi, '')
        // Remove commas, spaces, and trim
        .replace(/[,\s]/g, '')
        .trim();
      
      const parsed = Number.parseFloat(cleaned);
      return Number.isNaN(parsed) ? 0 : parsed;
    };

    const original = sanitize(originalPrice);
    const current = sanitize(currentPrice);
    
    // Validate numbers
    if (!original || !current || original <= current) {
      return 0;
    }
    
    const discount = Math.round(((original - current) / original) * 100);
    return Math.min(Math.max(discount, 0), 99); // Cap between 0-99%
  }

  // Universal product data extraction (supports ANY e-commerce website)
  app.post("/api/extract-amazon-product", async (req, res) => {
    try {
      const { url } = req.body;
      
      if (!url || !url.startsWith('http')) {
        return res.status(400).json({ error: "Please enter a valid URL" });
      }

      console.log('🌐 Extracting product from:', url);

      // Use universal extractor for ANY website
      const { extractUniversalProduct } = await import('./utils/universal-product-extractor');
      const productData = await extractUniversalProduct(url);

      if (!productData.success) {
        return res.status(400).json({ 
          error: "Product details extract nahi ho paya. Please check the product URL." 
        });
      }

      // Calculate discount properly
      const price = productData.price || '0';
      const originalPrice = productData.originalPrice || productData.price || '0';
      const discount = calculateDiscount(originalPrice, price);
      
      // Format response for database with complete specifications
      // Map images array to individual imageUrl fields
      const images = productData.images || [];
      const response = {
        title: productData.title,
        description: productData.description,
        descriptionContent: productData.description,
        price: price,
        originalPrice: originalPrice,
        imageUrl: images[0] || '',
        imageUrl2: images[1] || '',
        imageUrl3: images[2] || '',
        imageUrl4: images[3] || '',
        images: images,
        brand: productData.brand || 'Unknown',
        rating: productData.rating || '0',
        reviewCount: productData.reviewCount || 0,
        reviews: productData.reviews,
        url: productData.url,
        discount: discount,
        // Enhanced specification fields for complete product details
        highlights: productData.highlights || [],
        technicalDetails: productData.technicalDetails || [],
        specifications: productData.specifications || {}
      };

      console.log('✅ Product extracted successfully:', response.title);
      res.json(response);

    } catch (error) {
      console.error('Product extraction error:', error.message);
      res.status(500).json({ 
        error: `Product data extract nahi ho paya: ${error.message}` 
      });
    }
  });

  // Daraz product extraction function
  async function extractDarazProduct(url: string, res: any) {
    try {
      // Dynamic import for ES modules
      const axios = (await import('axios')).default;
      const cheerio = await import('cheerio');

      console.log('Extracting from Daraz URL:', url);

      // Make request with proper headers and follow redirects
      const response = await axios.get(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
          'Accept-Encoding': 'gzip, deflate, br',
          'Connection': 'keep-alive',
          'Upgrade-Insecure-Requests': '1',
          'Sec-Fetch-Dest': 'document',
          'Sec-Fetch-Mode': 'navigate',
          'Cache-Control': 'max-age=0'
        },
        timeout: 30000, // Increased to 30 seconds
        maxRedirects: 10, // Increased redirects
        validateStatus: function (status) {
          return status < 500; // Accept 4xx errors but reject 5xx
        }
      });

      const $ = cheerio.load(response.data);

      // Extract product data from Daraz page
      const productData = {
        title: '',
        description: '',
        images: [],
        price: '',
        originalPrice: '',
        highlights: '',
        technicalDetails: '',
        specifications: '',
        success: false
      };

      // Extract title from multiple possible sources
      productData.title = 
        $('meta[property="og:title"]').attr('content')?.replace(/\s*\|\s*Daraz\..*$/, '').trim() ||
        $('h1[data-spm="anchor_title"]').text().trim() ||
        $('.pdp-mod-product-badge-title').text().trim() ||
        $('.pdp-product-title').text().trim() ||
        $('.pdp-mod-product-badge-wrapper h1').text().trim() ||
        $('span[data-spm-anchor-id*="title"]').text().trim() ||
        $('h1').first().text().trim() ||
        $('title').text().replace(/\s*\|\s*Daraz\..*$/, '').trim() ||
        '';
      
      console.log('Title extraction attempts:', {
        ogTitle: $('meta[property="og:title"]').attr('content'),
        h1DataSpm: $('h1[data-spm="anchor_title"]').text(),
        pdpBadgeTitle: $('.pdp-mod-product-badge-title').text(),
        pdpProductTitle: $('.pdp-product-title').text(),
        titleTag: $('title').text(),
        finalTitle: productData.title
      });

      // Extract description from multiple sources
      productData.description = 
        $('meta[property="og:description"]').attr('content')?.trim() ||
        $('meta[name="description"]').attr('content')?.trim() ||
        $('.pdp-product-desc').text().trim() ||
        $('.pdp-mod-product-feature').text().trim() ||
        $('.pdp-mod-product-detail .html-content').text().trim() ||
        $('.product-intro').text().trim() ||
        $('.key-features').text().trim() ||
        '';

      // Clean description
      if (productData.description) {
        productData.description = productData.description
          .replace(/[\n\r\t]/g, ' ')
          .replace(/\s+/g, ' ')
          .replace(/Buy.*on Daraz.*/, '')
          .replace(/Daraz.*guarantee.*/, '')
          .substring(0, 500)
          .trim();
      }
      
      console.log('Description extraction:', {
        ogDescription: $('meta[property="og:description"]').attr('content'),
        metaDescription: $('meta[name="description"]').attr('content'),
        finalDescription: productData.description
      });

      // Extract images with better selectors
      const imageUrls = [];
      
      // Main product image from og:image
      const ogImage = $('meta[property="og:image"]').attr('content');
      if (ogImage && ogImage.includes('lazcdn.com')) {
        // Convert to high resolution
        const highResImage = ogImage.replace(/_\d+x\d+q\d+\.(jpg|png)(_\.webp)?/, '_2200x2200q80.$1').replace('.webp', '');
        imageUrls.push(highResImage);
      }

      // Extract additional images from various selectors
      const imageSelectors = [
        '.item-gallery-slider img',
        '.pdp-mod-common-image img', 
        '.gallery-preview-panel img',
        '.next-slick-track img',
        '.pdp-gallery img',
        '.product-gallery img',
        '[data-spm*="gallery"] img'
      ];
      
      imageSelectors.forEach(selector => {
        $(selector).each((i, elem) => {
          const src = $(elem).attr('src') || $(elem).attr('data-src') || $(elem).attr('data-original');
          if (src && src.includes('lazcdn.com') && imageUrls.length < 4) {
            const highResSrc = src.replace(/_\d+x\d+q\d+\.(jpg|png)(_\.webp)?/, '_2200x2200q80.$1').replace('.webp', '');
            if (!imageUrls.includes(highResSrc)) {
              imageUrls.push(highResSrc);
            }
          }
        });
      });

      // If we need more images, try to generate variants
      while (imageUrls.length < 4 && imageUrls.length > 0) {
        const baseImage = imageUrls[0];
        // Try different URL variations commonly used by Lazada CDN
        const variants = [
          baseImage.replace('.jpg', '_01.jpg'),
          baseImage.replace('.jpg', '_02.jpg'),
          baseImage.replace('.jpg', '_03.jpg'),
          baseImage.replace('.jpg', '_04.jpg'),
          baseImage.replace('_2200x2200q80', '_1200x1200q80'),
          baseImage.replace('_2200x2200q80', '_800x800q80')
        ];
        
        for (const variant of variants) {
          if (!imageUrls.includes(variant) && imageUrls.length < 4) {
            imageUrls.push(variant);
          }
        }
        break; // Prevent infinite loop
      }

      productData.images = imageUrls;
      console.log('Extracted images:', imageUrls.length, 'images found');

      // Detect product category based on title and URL
      const detectProductCategory = (title, url) => {
        const titleLower = title.toLowerCase();
        const urlLower = url.toLowerCase();
        const combined = `${titleLower} ${urlLower}`;
        
        if (combined.match(/\b(iphone|samsung|xiaomi|oppo|vivo|realme|oneplus|pixel|mobile|phone|smartphone)\b/)) {
          return 'mobile';
        }
        if (combined.match(/\b(laptop|macbook|thinkpad|dell|hp|asus|acer|lenovo|computer|pc)\b/)) {
          return 'laptop';
        }
        if (combined.match(/\b(fan|cooler|air conditioner|ac|blower|ceiling fan|table fan|tower fan)\b/)) {
          return 'appliance';
        }
        if (combined.match(/\b(tv|television|led|oled|smart tv|monitor|display)\b/)) {
          return 'electronics';
        }
        if (combined.match(/\b(headphone|earphone|earbuds|speaker|audio|wireless|bluetooth)\b/)) {
          return 'audio';
        }
        if (combined.match(/\b(watch|smartwatch|fitness|tracker|wearable)\b/)) {
          return 'wearable';
        }
        if (combined.match(/\b(camera|dslr|lens|photography|gopro)\b/)) {
          return 'camera';
        }
        return 'general';
      };

      const category = detectProductCategory(productData.title, url);
      console.log('Detected product category:', category);

      // Extract category-specific highlights
      const extractCategorySpecificData = (category, $) => {
        const data = { highlights: [], specifications: [], technicalDetails: '' };
        
        if (category === 'mobile') {
          // Mobile-specific extraction
          const mobileSpecs = [];
          $('.pdp-mod-specification tr, .specification-table tr').each((i, elem) => {
            const key = $(elem).find('td:first-child, th:first-child').text().trim().toLowerCase();
            const value = $(elem).find('td:last-child, th:last-child').text().trim();
            
            if (key && value && key !== value.toLowerCase()) {
              if (key.includes('ram') || key.includes('memory')) {
                mobileSpecs.push(`RAM: ${value}`);
              } else if (key.includes('storage') || key.includes('internal')) {
                mobileSpecs.push(`Storage: ${value}`);
              } else if (key.includes('display') || key.includes('screen')) {
                mobileSpecs.push(`Display: ${value}`);
              } else if (key.includes('camera') || key.includes('rear') || key.includes('front')) {
                mobileSpecs.push(`Camera: ${value}`);
              } else if (key.includes('battery')) {
                mobileSpecs.push(`Battery: ${value}`);
              } else if (key.includes('processor') || key.includes('chipset') || key.includes('cpu')) {
                mobileSpecs.push(`Processor: ${value}`);
              } else if (key.includes('os') || key.includes('android') || key.includes('ios')) {
                mobileSpecs.push(`OS: ${value}`);
              }
            }
          });
          
          data.highlights = [
            'High Performance Smartphone',
            'Latest Android/iOS Version',
            'Premium Build Quality',
            'Fast Charging Support',
            'Multiple Camera Setup',
            'Large Display Screen'
          ];
          data.specifications = mobileSpecs.join('\n');
          data.technicalDetails = 'Advanced smartphone with modern features including high-resolution display, powerful processor, ample RAM and storage, multiple camera setup, and long-lasting battery with fast charging capabilities.';
          
        } else if (category === 'appliance') {
          // Appliance-specific extraction (Fan, Cooler, AC)
          const applianceSpecs = [];
          $('.pdp-mod-specification tr, .specification-table tr').each((i, elem) => {
            const key = $(elem).find('td:first-child, th:first-child').text().trim().toLowerCase();
            const value = $(elem).find('td:last-child, th:last-child').text().trim();
            
            if (key && value && key !== value.toLowerCase()) {
              if (key.includes('power') || key.includes('watt') || key.includes('consumption')) {
                applianceSpecs.push(`Power: ${value}`);
              } else if (key.includes('speed') || key.includes('rpm')) {
                applianceSpecs.push(`Speed: ${value}`);
              } else if (key.includes('material') || key.includes('blade')) {
                applianceSpecs.push(`Material: ${value}`);
              } else if (key.includes('warranty')) {
                applianceSpecs.push(`Warranty: ${value}`);
              } else if (key.includes('size') || key.includes('dimension')) {
                applianceSpecs.push(`Size: ${value}`);
              }
            }
          });
          
          data.highlights = [
            'Energy Efficient Operation',
            'Low Noise Operation',
            'Durable Build Quality',
            'Easy Installation',
            'Remote Control Support',
            'Multiple Speed Settings'
          ];
          data.specifications = applianceSpecs.join('\n');
          data.technicalDetails = 'High-quality home appliance designed for optimal performance and energy efficiency. Features durable construction, quiet operation, and user-friendly controls.';
          
        } else if (category === 'laptop') {
          // Laptop-specific extraction
          const laptopSpecs = [];
          $('.pdp-mod-specification tr, .specification-table tr').each((i, elem) => {
            const key = $(elem).find('td:first-child, th:first-child').text().trim().toLowerCase();
            const value = $(elem).find('td:last-child, th:last-child').text().trim();
            
            if (key && value && key !== value.toLowerCase()) {
              if (key.includes('ram') || key.includes('memory')) {
                laptopSpecs.push(`RAM: ${value}`);
              } else if (key.includes('storage') || key.includes('ssd') || key.includes('hdd')) {
                laptopSpecs.push(`Storage: ${value}`);
              } else if (key.includes('processor') || key.includes('cpu') || key.includes('intel') || key.includes('amd')) {
                laptopSpecs.push(`Processor: ${value}`);
              } else if (key.includes('display') || key.includes('screen')) {
                laptopSpecs.push(`Display: ${value}`);
              } else if (key.includes('graphics') || key.includes('gpu')) {
                laptopSpecs.push(`Graphics: ${value}`);
              } else if (key.includes('os') || key.includes('windows') || key.includes('operating')) {
                laptopSpecs.push(`OS: ${value}`);
              }
            }
          });
          
          data.highlights = [
            'High Performance Computing',
            'Full HD Display',
            'Fast SSD Storage',
            'Long Battery Life',
            'Lightweight Design',
            'Multiple Connectivity Ports'
          ];
          data.specifications = laptopSpecs.join('\n');
          data.technicalDetails = 'Powerful laptop computer with modern processor, ample RAM and storage, high-resolution display, and comprehensive connectivity options for work and entertainment.';
        }
        
        // Fallback to generic extraction if category-specific didn't work
        if (data.highlights.length === 0) {
          const genericHighlights = [];
          const highlightSelectors = [
            '.key-features li',
            '.product-key-features li',
            '.pdp-mod-specification .key-features li',
            '.specification-list .key-feature',
            '.product-highlights li',
            '.product-features li'
          ];
          
          highlightSelectors.forEach(selector => {
            $(selector).each((i, elem) => {
              const text = $(elem).text().trim();
              if (text && text.length > 3 && genericHighlights.length < 8) {
                genericHighlights.push(text);
              }
            });
          });
          
          data.highlights = genericHighlights;
        }
        
        return data;
      };

      const categoryData = extractCategorySpecificData(category, $);
      productData.highlights = categoryData.highlights.join('\n');
      console.log('Extracted category-specific highlights:', categoryData.highlights.length, 'features found');

      // Use category-specific specifications and technical details
      productData.specifications = categoryData.specifications || '';
      productData.technicalDetails = categoryData.technicalDetails || '';

      // If category-specific extraction didn't work, fallback to generic
      if (!productData.specifications) {
        const genericSpecs = [];
        const specSelectors = [
          '.pdp-mod-specification tr',
          '.specification-table tr', 
          '.specs-table tr',
          '.product-specification tr',
          '.technical-specs tr'
        ];

        specSelectors.forEach(selector => {
          $(selector).each((i, elem) => {
            const key = $(elem).find('td:first-child, th:first-child').text().trim();
            const value = $(elem).find('td:last-child, th:last-child').text().trim();
            if (key && value && key !== value && genericSpecs.length < 12) {
              genericSpecs.push(`${key}: ${value}`);
            }
          });
        });
        productData.specifications = genericSpecs.join('\n');
      }

      // Fallback for technical details
      if (!productData.technicalDetails) {
        const techDetailSelectors = [
          '.pdp-mod-product-feature',
          '.product-detail-info',
          '.technical-information',
          '.product-tech-details',
          '.detailed-specs'
        ];

        techDetailSelectors.forEach(selector => {
          if (!productData.technicalDetails) {
            const text = $(selector).text().trim();
            if (text && text.length > 50) {
              productData.technicalDetails = text.substring(0, 800).trim();
            }
          }
        });

        // Final fallback
        if (!productData.technicalDetails) {
          if (productData.specifications) {
            productData.technicalDetails = productData.specifications.split('\n').slice(0, 8).join('\n');
          } else if (productData.description && productData.description.length > 100) {
            productData.technicalDetails = productData.description.substring(0, 400);
          }
        }
      }

      console.log('Final specifications:', productData.specifications.split('\n').length, 'specs found');
      console.log('Final technical details:', productData.technicalDetails ? productData.technicalDetails.substring(0, 100) + '...' : 'Not found');

      // Extract current price - prioritize webpage content over URL params
      const priceSelectors = [
        // Modern Daraz selectors
        '.pdp-price .notranslate',
        '.pdp-price_color_orange',
        '.pdp-product-price .notranslate',
        '.pdp-mod-product-price-current', 
        '.product-price .current-price',
        '.price-current',
        '.current-price',
        '.pdp-price',
        'span[data-spm-anchor-id*="price"]',
        '.price-box .price',
        '.price-now',
        '.discounted-price',
        '.sale-price',
        '.special-price',
        '.price',
        '[class*="price"][class*="current"]',
        '[class*="price"][class*="orange"]',
        'script[type="application/ld+json"]' // Structured data
      ];

      // Try to extract price from webpage content first
      console.log('Searching for prices with selectors...');
      
      for (const selector of priceSelectors) {
        if (productData.price) break;
        
        if (selector.includes('script')) {
          // Extract from JSON-LD structured data
          $(selector).each((i, elem) => {
            try {
              const jsonData = JSON.parse($(elem).html() || '{}');
              if (jsonData.price || jsonData.offers?.price) {
                productData.price = (jsonData.price || jsonData.offers.price).toString().replace(/[^\d]/g, '');
                return false;
              }
            } catch (e) {}
          });
        } else {
          const priceElements = $(selector);
          if (priceElements.length > 0) {
            console.log(`Found ${priceElements.length} elements for selector: ${selector}`);
            priceElements.each((i, elem) => {
              const priceText = $(elem).text().trim();
              console.log(`  Element ${i} text:`, priceText);
              
              if (priceText && (priceText.includes('Rs') || priceText.includes('₹') || /\d+/.test(priceText))) {
                const priceMatch = priceText.match(/[\d,]+/);
                if (priceMatch && priceMatch[0]) {
                  const cleanPrice = priceMatch[0].replace(/,/g, '').trim();
                  if (cleanPrice && parseInt(cleanPrice) > 100) { // Sanity check for reasonable price
                    productData.price = cleanPrice;
                    console.log('✅ Found price from selector', selector, ':', cleanPrice);
                    return false;
                  }
                }
              }
            });
          }
        }
      }

      // Extract price from URL parameters - more reliable for Daraz than HTML parsing
      const urlPriceMatch = url.match(/price=(\d+)/);
      if (urlPriceMatch && !productData.price) {
        // Convert from cents to main currency (divide by 100 for Nepal/Pakistan)
        const priceFromUrl = Math.round(parseInt(urlPriceMatch[1]) / 100).toString();
        console.log('✅ Extracted price from URL parameter:', priceFromUrl);
        productData.price = priceFromUrl;
      }

      // Extract original price from page content first
      const originalPriceSelectors = [
        // Modern Daraz original price selectors
        '.pdp-price .origin-price',
        '.pdp-price_color_lightgray',
        '.pdp-mod-product-price-original',
        '.product-price .original-price',
        '.price-original', 
        '.original-price',
        '.price-was',
        '.old-price',
        '.crossed-price',
        'span[style*="text-decoration: line-through"]',
        'span[style*="line-through"]',
        '[class*="price"][class*="original"]',
        '[class*="price"][class*="gray"]',
        '[class*="price"][class*="old"]',
        '.price del, .price strike, .price s'
      ];

      // Try to extract original price from webpage content
      console.log('Searching for original prices...');
      
      for (const selector of originalPriceSelectors) {
        if (productData.originalPrice) break;
        
        const originalElements = $(selector);
        if (originalElements.length > 0) {
          console.log(`Found ${originalElements.length} original price elements for selector: ${selector}`);
          originalElements.each((i, elem) => {
            const originalPriceText = $(elem).text().trim();
            console.log(`  Original price element ${i} text:`, originalPriceText);
            
            if (originalPriceText && (originalPriceText.includes('Rs') || originalPriceText.includes('₹') || /\d+/.test(originalPriceText))) {
              const priceMatch = originalPriceText.match(/[\d,]+/);
              if (priceMatch && priceMatch[0] !== productData.price) {
                const cleanOriginalPrice = priceMatch[0].replace(/,/g, '').trim();
                if (cleanOriginalPrice && parseInt(cleanOriginalPrice) > parseInt(productData.price || '0')) {
                  productData.originalPrice = cleanOriginalPrice;
                  console.log('✅ Found original price from selector', selector, ':', cleanOriginalPrice);
                  return false;
                }
              }
            }
          });
        }
      }

      // Extract original price from URL params - check priceCompare section
      if (!productData.originalPrice) {
        // Check multiple URL patterns for original price
        const patterns = [
          /originPrice%3A(\d+)/,  // from priceCompare parameter
          /originPrice=(\d+)/,    // direct parameter
        ];
        
        for (const pattern of patterns) {
          const match = url.match(pattern);
          if (match) {
            const originalPriceFromUrl = Math.round(parseInt(match[1]) / 100).toString();
            console.log('✅ Extracted original price from URL:', originalPriceFromUrl);
            productData.originalPrice = originalPriceFromUrl;
            break;
          }
        }
      }

      // Extract real prices from URL query parameters and tracking data  
      if (!productData.price) {
        // Method 1: Direct price parameter
        const directPriceMatch = url.match(/[?&]price=(\d+)/);
        if (directPriceMatch) {
          productData.price = directPriceMatch[1];
          console.log('Extracted price from URL direct:', productData.price);
        }
        
        // Method 2: From tracking parameters
        const trackingMatch = url.match(/clickTrackInfo=([^&]+)/);
        if (trackingMatch && !productData.price) {
          try {
            const decodedTracking = decodeURIComponent(trackingMatch[1]);
            const priceMatch = decodedTracking.match(/price%3A(\d+)/);
            if (priceMatch) {
              productData.price = priceMatch[1];
              console.log('Extracted price from tracking:', productData.price);
            }
          } catch (e) {}
        }
        
        // Method 3: From priceCompare parameter
        const priceCompareMatch = url.match(/priceCompare=([^&]+)/);
        if (priceCompareMatch && !productData.price) {
          try {
            const decodedCompare = decodeURIComponent(priceCompareMatch[1]);
            const originPriceMatch = decodedCompare.match(/originPrice%3A(\d+)/);
            if (originPriceMatch) {
              // Convert from cents to rupees (divide by 100)
              productData.price = Math.round(parseInt(originPriceMatch[1]) / 100).toString();
              console.log('Extracted price from priceCompare:', productData.price);
            }
          } catch (e) {}
        }

        // Method 3: From originPrice in tracking
        if (trackingMatch && !productData.originalPrice) {
          try {
            const decodedTracking = decodeURIComponent(trackingMatch[1]);
            const originalPriceMatch = decodedTracking.match(/originPrice%3A(\d+)/);
            if (originalPriceMatch) {
              productData.originalPrice = Math.round(parseInt(originalPriceMatch[1]) / 100).toString();
              console.log('Extracted original price from tracking:', productData.originalPrice);
            }
          } catch (e) {}
        }
      }

      // Last resort: Minimum viable prices if still not found
      if (!productData.price) {
        console.log('Warning: Could not extract real price from Daraz page, using fallback');
        productData.price = "999"; // Minimal fallback
      }

      if (!productData.originalPrice && productData.price) {
        const currentPrice = parseInt(productData.price);
        productData.originalPrice = Math.round(currentPrice * 1.25).toString(); // Minimal markup
      }
      
      // Ensure prices are properly formatted (remove any extra characters)
      if (productData.price) {
        productData.price = productData.price.replace(/[^\d]/g, '');
      }
      if (productData.originalPrice) {
        productData.originalPrice = productData.originalPrice.replace(/[^\d]/g, '');
      }

      console.log('Extracted Daraz product data:', {
        title: productData.title,
        description: productData.description ? productData.description.substring(0, 100) + '...' : 'Not found', 
        images: productData.images.length,
        price: productData.price,
        originalPrice: productData.originalPrice,
        highlights: productData.highlights ? productData.highlights.split('\n').length + ' features' : 'Not found',
        specifications: productData.specifications ? productData.specifications.split('\n').length + ' specs' : 'Not found',
        technicalDetails: productData.technicalDetails ? 'Found (' + productData.technicalDetails.length + ' chars)' : 'Not found'
      });

      // Debug price generation
      console.log('Final prices:', {
        currentPrice: productData.price,
        originalPrice: productData.originalPrice
      });

      // Validate extraction
      if (!productData.title) {
        return res.status(400).json({ 
          error: "Could not extract product title from Daraz page" 
        });
      }

      // Final validation and cleanup
      const responseData = {
        title: productData.title.trim(),
        description: productData.description.trim(),
        price: productData.price,
        originalPrice: productData.originalPrice,
        images: productData.images,
        highlights: productData.highlights.trim(),
        technicalDetails: productData.technicalDetails.trim(),
        specifications: productData.specifications.trim(),
        success: true
      };
      
      console.log('Sending response data:', responseData);
      res.json(responseData);

    } catch (error) {
      console.error('Daraz extraction error:', error.message);
      
      // Specific error handling for different types of errors
      if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
        res.status(408).json({ 
          error: 'Request timeout - The Daraz website took too long to respond. Please try again.' 
        });
      } else if (error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
        res.status(503).json({ 
          error: 'Connection failed - Unable to reach Daraz website. Please check the URL and try again.' 
        });
      } else if (error.message.includes('aborted')) {
        res.status(408).json({ 
          error: 'Request was aborted - The connection was interrupted. Please try again.' 
        });
      } else {
        res.status(500).json({ 
          error: `Failed to extract Daraz product data: ${error.message}` 
        });
      }
    }
  }

  app.post("/api/products", async (req, res) => {
    try {
      const productData = req.body;
      const product = await storage.createProduct(productData);
      res.status(201).json(product);
    } catch (error) {
      console.error('Product creation error:', error);
      res.status(500).json({ error: "Failed to create product" });
    }
  });

  // Categories
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });

  // Cart
  app.get("/api/cart/:userId", async (req, res) => {
    try {
      const userId = req.params.userId;
      const cartItems = await storage.getCartItems(userId);
      res.json(cartItems);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch cart items" });
    }
  });

  app.post("/api/cart", async (req, res) => {
    try {
      const cartItem = await storage.addToCart(req.body);
      res.json(cartItem);
    } catch (error) {
      res.status(500).json({ error: "Failed to add to cart" });
    }
  });

  app.put("/api/cart/:id", async (req, res) => {
    try {
      const id = req.params.id;
      const { quantity } = req.body;
      const cartItem = await storage.updateCartItem(id, quantity);
      res.json(cartItem);
    } catch (error) {
      res.status(500).json({ error: "Failed to update cart item" });
    }
  });

  app.delete("/api/cart/:id", async (req, res) => {
    try {
      const id = req.params.id;
      await storage.removeFromCart(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to remove from cart" });
    }
  });

  app.delete("/api/cart/clear/:userId", async (req, res) => {
    try {
      const userId = req.params.userId;
      await storage.clearCart(userId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to clear cart" });
    }
  });

  // Addresses
  app.get("/api/addresses/:userId", async (req, res) => {
    try {
      const userId = req.params.userId;
      const addresses = await storage.getAddresses(userId);
      res.json(addresses);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch addresses" });
    }
  });

  app.post("/api/addresses", async (req, res) => {
    try {
      const address = await storage.createAddress(req.body);
      res.json(address);
    } catch (error) {
      res.status(500).json({ error: "Failed to create address" });
    }
  });

  app.put("/api/addresses/:id", async (req, res) => {
    try {
      const id = req.params.id;
      const updateData = req.body;
      const address = await storage.updateAddress(id, updateData);
      res.json(address);
    } catch (error) {
      res.status(500).json({ error: "Failed to update address" });
    }
  });

  app.delete("/api/addresses/:id", async (req, res) => {
    try {
      const id = req.params.id;
      await storage.deleteAddress(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete address" });
    }
  });

  // Orders
  app.get("/api/orders/:userId", async (req, res) => {
    try {
      const userId = req.params.userId;
      const orders = await storage.getOrders(userId);
      res.json(orders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const order = await storage.createOrder(req.body);
      res.json(order);
    } catch (error) {
      res.status(500).json({ error: "Failed to create order" });
    }
  });

  app.get("/api/orders/:orderId/items", async (req, res) => {
    try {
      const orderId = req.params.orderId;
      const orderItems = await storage.getOrderItems(orderId);
      res.json(orderItems);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch order items" });
    }
  });

  // Settings
  app.get("/api/settings", async (req, res) => {
    try {
      const settings = await storage.getSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  app.post("/api/settings", async (req, res) => {
    try {
      const { script } = req.body;
      if (!script || !['watch', 'phone', 'none'].includes(script)) {
        return res.status(400).json({ error: "Invalid script value. Must be 'watch', 'phone', or 'none'" });
      }
      const settings = await storage.updateSettings({ script });
      res.json(settings);
    } catch (error) {
      res.status(500).json({ error: "Failed to update settings" });
    }
  });

  // Scripts Management API
  app.get("/api/scripts", async (req, res) => {
    try {
      const scripts = await storage.getScripts();
      res.json(scripts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch scripts" });
    }
  });

  app.get("/api/scripts/:id", async (req, res) => {
    try {
      const id = req.params.id;
      const script = await storage.getScript(id);
      if (!script) {
        return res.status(404).json({ error: "Script not found" });
      }
      res.json(script);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch script" });
    }
  });

  app.post("/api/scripts", async (req, res) => {
    try {
      // Validate request body with Zod
      const validatedData = createScriptSchema.parse(req.body);
      
      // Create script with validated data
      const script = await storage.createScript({
        ...validatedData,
        createdAt: new Date().toISOString(),
        isActive: validatedData.status === 'active' || false
      });
      
      res.status(201).json(script);
    } catch (error) {
      console.error('Script creation error:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: error.errors.map(e => ({ field: e.path.join('.'), message: e.message }))
        });
      }
      
      res.status(400).json({ 
        error: "Failed to create script: " + (error instanceof Error ? error.message : 'Unknown error') 
      });
    }
  });

  app.put("/api/scripts/:id", async (req, res) => {
    try {
      const id = req.params.id;
      
      // Validate script ID
      if (!id || id === 'undefined' || id === 'null') {
        return res.status(400).json({ error: "Valid script ID is required" });
      }
      
      // Validate updates with Zod
      const validatedUpdates = updateScriptSchema.parse(req.body);
      
      // Update script
      const script = await storage.updateScript(id, validatedUpdates);
      
      if (!script) {
        return res.status(404).json({ error: "Script not found" });
      }
      
      res.json(script);
    } catch (error) {
      console.error('Script update error:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: error.errors.map(e => ({ field: e.path.join('.'), message: e.message }))
        });
      }
      
      res.status(400).json({ 
        error: "Failed to update script: " + (error instanceof Error ? error.message : 'Unknown error')
      });
    }
  });

  app.delete("/api/scripts/:id", async (req, res) => {
    try {
      const id = req.params.id;
      
      // Validate script ID
      if (!id || id === 'undefined' || id === 'null') {
        return res.status(400).json({ error: "Valid script ID is required" });
      }
      
      await storage.deleteScript(id);
      res.status(204).send();
    } catch (error) {
      console.error('Script deletion error:', error);
      res.status(500).json({ error: "Failed to delete script" });
    }
  });

  // Activate script - body based (for admin panel)
  app.post("/api/scripts/activate", async (req, res) => {
    try {
      const { scriptId } = req.body;
      if (!scriptId) {
        return res.status(400).json({ error: "scriptId is required" });
      }
      await storage.activateScript(scriptId);
      
      // Ensure proper JSON response
      res.setHeader('Content-Type', 'application/json');
      return res.status(200).json({ message: "Script activated successfully" });
    } catch (error) {
      console.error('Script activation error:', error);
      res.setHeader('Content-Type', 'application/json');
      return res.status(500).json({ error: "Failed to activate script" });
    }
  });

  // Activate script - param based (alternative)
  app.post("/api/scripts/:id/activate", async (req, res) => {
    try {
      const id = req.params.id;
      
      // Validate script ID
      if (!id || id === 'undefined' || id === 'null') {
        return res.status(400).json({ error: "Valid script ID is required" });
      }
      
      await storage.activateScript(id);
      res.json({ message: "Script activated successfully" });
    } catch (error) {
      console.error('Script activation error:', error);
      res.status(500).json({ error: "Failed to activate script" });
    }
  });

  app.get("/api/scripts/:id/products", async (req, res) => {
    try {
      const id = req.params.id;
      const scriptProducts = await storage.getScriptProducts(id);
      res.json(scriptProducts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch script products" });
    }
  });

  app.post("/api/scripts/:id/products", async (req, res) => {
    try {
      const scriptId = req.params.id;
      console.log('Received product data:', req.body);
      
      // Validate required fields
      if (!req.body.title) {
        return res.status(400).json({ error: "Title is required" });
      }
      if (!req.body.price) {
        return res.status(400).json({ error: "Price is required" });
      }
      
      // Convert arrays to strings for MongoDB compatibility
      const description = Array.isArray(req.body.description) 
        ? req.body.description.join('\n') 
        : (req.body.description || '');
      const descriptionContent = Array.isArray(req.body.descriptionContent) 
        ? req.body.descriptionContent.join('\n') 
        : (req.body.descriptionContent || '');
      
      const productData = {
        ...req.body,
        description,
        descriptionContent,
        scriptId
      };
      const scriptProduct = await storage.addProductToScript(productData);
      res.status(201).json(scriptProduct);
    } catch (error) {
      console.error('Product creation error:', error);
      res.status(400).json({ error: "Invalid product data" });
    }
  });

  // Update script product (embedded in dynamic script collection)
  app.patch("/api/script-products/:id", async (req, res) => {
    try {
      const productId = req.params.id;
      const { 
        price, originalPrice, discount, isFlashDeal, scriptName,
        title, brand, model,
        specifications,
        highlights, descriptionContent,
        // Images and Daraz-specific fields
        images, imageUrl, imageUrl2, imageUrl3, imageUrl4,
        colorVariants, deliveryLocation, deliveryCharge,
        freeReturn, warranty, rating, disclaimer
      } = req.body;
      
      console.log('🔧 UPDATE EMBEDDED PRODUCT REQUEST:', { 
        productId, 
        price, 
        originalPrice, 
        discount, 
        isFlashDeal,
        scriptName,
        title,
        brand,
        model,
        specifications: specifications ? 'provided' : 'not provided'
      });
      
      // Get DynamicScriptManager
      const DynamicScriptManager = (await import('./models/DynamicScript')).default;
      
      // Build update object for the embedded product
      const updateFields: any = {};
      
      // Basic pricing fields
      if (price !== undefined) updateFields['products.$.price'] = String(price);
      if (originalPrice !== undefined) updateFields['products.$.originalPrice'] = originalPrice ? String(originalPrice) : '';
      if (discount !== undefined) updateFields['products.$.discount'] = Number(discount);
      if (isFlashDeal !== undefined) updateFields['products.$.isFlashDeal'] = Boolean(isFlashDeal);
      
      // Basic info fields
      if (title !== undefined) updateFields['products.$.title'] = String(title);
      if (brand !== undefined) updateFields['products.$.brand'] = String(brand);
      if (model !== undefined) updateFields['products.$.model'] = String(model);
      
      // Specifications object - update each field if provided
      if (specifications) {
        if (specifications.display !== undefined) updateFields['products.$.specifications.display'] = specifications.display;
        if (specifications.size !== undefined) updateFields['products.$.specifications.size'] = specifications.size;
        if (specifications.resolution !== undefined) updateFields['products.$.specifications.resolution'] = specifications.resolution;
        if (specifications.chip !== undefined) updateFields['products.$.specifications.chip'] = specifications.chip;
        if (specifications.cpu !== undefined) updateFields['products.$.specifications.cpu'] = specifications.cpu;
        if (specifications.gpu !== undefined) updateFields['products.$.specifications.gpu'] = specifications.gpu;
        if (specifications.neuralEngine !== undefined) updateFields['products.$.specifications.neuralEngine'] = specifications.neuralEngine;
        if (specifications.camera !== undefined) updateFields['products.$.specifications.camera'] = specifications.camera;
        if (specifications.waterResistance !== undefined) updateFields['products.$.specifications.waterResistance'] = specifications.waterResistance;
        if (specifications.operatingSystem !== undefined) updateFields['products.$.specifications.operatingSystem'] = specifications.operatingSystem;
        if (specifications.storage !== undefined) updateFields['products.$.specifications.storage'] = specifications.storage;
        if (specifications.ram !== undefined) updateFields['products.$.specifications.ram'] = specifications.ram;
        if (specifications.color !== undefined) updateFields['products.$.specifications.color'] = specifications.color;
      }
      
      // Content fields
      if (highlights !== undefined) updateFields['products.$.highlights'] = highlights;
      if (descriptionContent !== undefined) updateFields['products.$.descriptionContent'] = descriptionContent;
      
      // Images (max 4)
      if (images !== undefined) updateFields['products.$.images'] = images;
      if (imageUrl !== undefined) updateFields['products.$.imageUrl'] = imageUrl;
      if (imageUrl2 !== undefined) updateFields['products.$.imageUrl2'] = imageUrl2;
      if (imageUrl3 !== undefined) updateFields['products.$.imageUrl3'] = imageUrl3;
      if (imageUrl4 !== undefined) updateFields['products.$.imageUrl4'] = imageUrl4;
      
      // Daraz-specific fields
      if (colorVariants !== undefined) updateFields['products.$.colorVariants'] = colorVariants;
      if (deliveryLocation !== undefined) updateFields['products.$.deliveryLocation'] = deliveryLocation;
      if (deliveryCharge !== undefined) updateFields['products.$.deliveryCharge'] = deliveryCharge;
      if (freeReturn !== undefined) updateFields['products.$.freeReturn'] = freeReturn;
      if (warranty !== undefined) updateFields['products.$.warranty'] = warranty;
      if (rating !== undefined) updateFields['products.$.rating'] = rating;
      if (disclaimer !== undefined) updateFields['products.$.disclaimer'] = disclaimer;
      
      console.log('📝 Update fields for embedded product:', Object.keys(updateFields));
      
      // Find script containing this product and update
      const result = await storage.updateScriptProduct(scriptName, productId, updateFields);
      
      if (!result) {
        console.error('❌ Product not found in script');
        return res.status(404).json({ error: "Product not found" });
      }
      
      console.log('✅ Embedded product updated successfully');
      res.json(result);
    } catch (error) {
      console.error('❌ Update product error:', error);
      res.status(500).json({ error: "Failed to update product" });
    }
  });

  // Remove product from script endpoint  
  app.delete("/api/script-products/:id", async (req, res) => {
    try {
      const scriptProductId = req.params.id;
      await storage.removeScriptProduct(scriptProductId);
      res.status(204).send();
    } catch (error) {
      console.error('Delete product error:', error);
      res.status(500).json({ error: "Failed to remove product from script" });
    }
  });

  // Advanced Script Management Endpoints
  
  // Duplicate script
  app.post("/api/scripts/:id/duplicate", async (req, res) => {
    try {
      const id = req.params.id;
      const { name } = req.body;
      
      if (!id || id === 'undefined' || id === 'null') {
        return res.status(400).json({ error: "Valid script ID is required" });
      }
      
      // Get original script
      const originalScript = await storage.getScript(id);
      if (!originalScript) {
        return res.status(404).json({ error: "Script not found" });
      }
      
      // Create duplicate with new name
      const duplicateName = name || `${originalScript.name} (Copy)`;
      const duplicateData = {
        name: duplicateName,
        description: originalScript.description,
        category: originalScript.category,
        tags: originalScript.tags || [],
        priority: originalScript.priority || 0,
        visibility: 'private', // Always start as private
        status: 'draft', // Always start as draft
        deploymentNotes: originalScript.deploymentNotes,
        metadata: originalScript.metadata || {},
        config: originalScript.config,
        additionalInfo: originalScript.additionalInfo,
        isActive: false
      };
      
      const duplicateScript = await storage.createScript(duplicateData);
      
      // Copy products if any
      const products = await storage.getScriptProducts(id);
      if (products && products.length > 0) {
        for (const product of products) {
          await storage.addScriptProductById(duplicateScript._id, product.productId, {
            isFlashDeal: product.isFlashDeal,
            order: product.order,
            isFeatured: product.isFeatured,
            section: product.section
          });
        }
      }
      
      res.status(201).json(duplicateScript);
    } catch (error) {
      console.error('Script duplication error:', error);
      res.status(500).json({ 
        error: "Failed to duplicate script: " + (error instanceof Error ? error.message : 'Unknown error')
      });
    }
  });

  // Deactivate script
  app.post("/api/scripts/:id/deactivate", async (req, res) => {
    try {
      const id = req.params.id;
      
      if (!id || id === 'undefined' || id === 'null') {
        return res.status(400).json({ error: "Valid script ID is required" });
      }
      
      const script = await storage.getScript(id);
      if (!script) {
        return res.status(404).json({ error: "Script not found" });
      }
      
      const updated = await storage.updateScript(id, { 
        isActive: false,
        status: 'inactive'
      });
      
      res.json({ message: "Script deactivated successfully", script: updated });
    } catch (error) {
      console.error('Script deactivation error:', error);
      res.status(500).json({ error: "Failed to deactivate script" });
    }
  });

  // Archive script
  app.post("/api/scripts/:id/archive", async (req, res) => {
    try {
      const id = req.params.id;
      
      if (!id || id === 'undefined' || id === 'null') {
        return res.status(400).json({ error: "Valid script ID is required" });
      }
      
      const updated = await storage.updateScript(id, { 
        status: 'archived',
        isActive: false
      });
      
      if (!updated) {
        return res.status(404).json({ error: "Script not found" });
      }
      
      res.json({ message: "Script archived successfully", script: updated });
    } catch (error) {
      console.error('Script archive error:', error);
      res.status(500).json({ error: "Failed to archive script" });
    }
  });

  // Search scripts with filters
  app.get("/api/scripts/search/query", async (req, res) => {
    try {
      const { 
        q, // search query
        category, 
        status, 
        visibility,
        tags,
        sortBy = 'createdAt',
        sortOrder = 'desc',
        limit = 50
      } = req.query;
      
      let scripts = await storage.getScripts();
      
      // Apply search filter
      if (q && typeof q === 'string') {
        const searchTerm = q.toLowerCase();
        scripts = scripts.filter((script: any) => 
          script.name?.toLowerCase().includes(searchTerm) ||
          script.description?.toLowerCase().includes(searchTerm) ||
          script.tags?.some((tag: string) => tag.toLowerCase().includes(searchTerm))
        );
      }
      
      // Apply category filter
      if (category && typeof category === 'string') {
        scripts = scripts.filter((script: any) => script.category === category);
      }
      
      // Apply status filter
      if (status && typeof status === 'string') {
        scripts = scripts.filter((script: any) => script.status === status);
      }
      
      // Apply visibility filter
      if (visibility && typeof visibility === 'string') {
        scripts = scripts.filter((script: any) => script.visibility === visibility);
      }
      
      // Apply tags filter
      if (tags && typeof tags === 'string') {
        const tagList = tags.split(',').map(t => t.trim());
        scripts = scripts.filter((script: any) => 
          tagList.some(tag => script.tags?.includes(tag))
        );
      }
      
      // Sort scripts
      scripts.sort((a: any, b: any) => {
        const aValue = a[sortBy as string];
        const bValue = b[sortBy as string];
        
        if (sortOrder === 'asc') {
          return aValue > bValue ? 1 : -1;
        } else {
          return aValue < bValue ? 1 : -1;
        }
      });
      
      // Apply limit
      const limitNum = parseInt(limit as string);
      if (limitNum > 0) {
        scripts = scripts.slice(0, limitNum);
      }
      
      res.json({ 
        scripts, 
        total: scripts.length,
        filters: { q, category, status, visibility, tags }
      });
    } catch (error) {
      console.error('Script search error:', error);
      res.status(500).json({ error: "Failed to search scripts" });
    }
  });

  // Bulk operations on scripts
  app.post("/api/scripts/bulk", async (req, res) => {
    try {
      const validatedData = bulkOperationSchema.parse(req.body);
      const { scriptIds, operation } = validatedData;
      
      const results = {
        success: [] as string[],
        failed: [] as { id: string; error: string }[]
      };
      
      for (const scriptId of scriptIds) {
        try {
          switch (operation) {
            case 'activate':
              await storage.activateScript(scriptId);
              results.success.push(scriptId);
              break;
              
            case 'deactivate':
              await storage.updateScript(scriptId, { isActive: false, status: 'inactive' });
              results.success.push(scriptId);
              break;
              
            case 'archive':
              await storage.updateScript(scriptId, { status: 'archived', isActive: false });
              results.success.push(scriptId);
              break;
              
            case 'delete':
              await storage.deleteScript(scriptId);
              results.success.push(scriptId);
              break;
          }
        } catch (error) {
          results.failed.push({ 
            id: scriptId, 
            error: error instanceof Error ? error.message : 'Unknown error' 
          });
        }
      }
      
      res.json({
        message: `Bulk ${operation} completed`,
        results,
        summary: {
          total: scriptIds.length,
          succeeded: results.success.length,
          failed: results.failed.length
        }
      });
    } catch (error) {
      console.error('Bulk operation error:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: error.errors.map(e => ({ field: e.path.join('.'), message: e.message }))
        });
      }
      
      res.status(500).json({ 
        error: "Bulk operation failed: " + (error instanceof Error ? error.message : 'Unknown error')
      });
    }
  });

  // Get script statistics
  app.get("/api/scripts/stats", async (req, res) => {
    try {
      const scripts = await storage.getScripts();
      
      const stats = {
        total: scripts.length,
        byStatus: {
          active: scripts.filter((s: any) => s.status === 'active').length,
          inactive: scripts.filter((s: any) => s.status === 'inactive').length,
          draft: scripts.filter((s: any) => s.status === 'draft').length,
          archived: scripts.filter((s: any) => s.status === 'archived').length
        },
        byCategory: {} as Record<string, number>,
        byVisibility: {
          public: scripts.filter((s: any) => s.visibility === 'public').length,
          private: scripts.filter((s: any) => s.visibility === 'private').length,
          scheduled: scripts.filter((s: any) => s.visibility === 'scheduled').length
        },
        totalProducts: 0,
        averageProductsPerScript: 0
      };
      
      // Count by category
      const categories = ['Phone', 'Accessories', 'Electronics', 'Fashion', 'Other'];
      for (const category of categories) {
        stats.byCategory[category] = scripts.filter((s: any) => s.category === category).length;
      }
      
      // Calculate product stats (if available)
      try {
        let totalProducts = 0;
        for (const script of scripts) {
          const products = await storage.getScriptProducts(script._id);
          totalProducts += products.length;
        }
        stats.totalProducts = totalProducts;
        stats.averageProductsPerScript = scripts.length > 0 ? Math.round(totalProducts / scripts.length) : 0;
      } catch (err) {
        // If product stats fail, just skip them
        console.error('Failed to calculate product stats:', err);
      }
      
      res.json(stats);
    } catch (error) {
      console.error('Script stats error:', error);
      res.status(500).json({ error: "Failed to fetch script statistics" });
    }
  });

  // Placeholder image endpoint
  app.get("/api/placeholder/:type", (req, res) => {
    const { type } = req.params;
    // Return a simple SVG placeholder
    const svg = `<svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
      <rect width="100%" height="100%" fill="#f0f0f0"/>
      <text x="50%" y="50%" font-family="Arial, sans-serif" font-size="12" text-anchor="middle" dy=".3em" fill="#666">
        ${type}
      </text>
    </svg>`;
    
    res.setHeader('Content-Type', 'image/svg+xml');
    res.send(svg);
  });

  // Update product
  app.patch("/api/products/:id", async (req, res) => {
    try {
      const id = req.params.id;
      const updates = req.body;
      
      const updated = await storage.updateProduct(id, updates);
      res.json(updated);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Delete product
  app.delete("/api/products/:id", async (req, res) => {
    try {
      const id = req.params.id;
      await storage.deleteProduct(id);
      res.json({ message: "Product deleted successfully" });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // QR Code endpoints
  app.get("/api/qr-code", async (req, res) => {
    try {
      const qrCode = await storage.getQRCode();
      res.json({ imageUrl: qrCode });
    } catch (error) {
      console.error('Error fetching QR code:', error);
      res.status(500).json({ error: "Failed to fetch QR code" });
    }
  });

  // QR Proxy endpoint to bypass CORS
  app.get("/api/proxy-qr", async (req, res) => {
    try {
      const url = req.query.url as string;
      if (!url) {
        return res.status(400).json({ error: "URL parameter required" });
      }

      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Failed to fetch QR: ${response.statusText}`);
      }

      const buffer = await response.arrayBuffer();
      res.set('Content-Type', 'image/png');
      res.send(Buffer.from(buffer));
    } catch (error) {
      console.error('Error proxying QR code:', error);
      res.status(500).json({ error: "Failed to proxy QR code" });
    }
  });

  // Transaction status endpoint for real-time polling
  app.get("/api/transaction-status/:id", async (req, res) => {
    try {
      const txId = req.params.id;
      console.log('🔍 [STATUS API] Fetching status for txId:', txId);
      
      const transaction = await storage.getTransactionById(txId);
      console.log('🔍 [STATUS API] Transaction found:', transaction ? 'YES' : 'NO');
      
      if (!transaction) {
        console.log('❌ [STATUS API] Transaction not found in database');
        return res.status(404).json({ error: "Transaction not found" });
      }

      console.log('🔍 [STATUS API] Returning status:', transaction.status);
      console.log('🔍 [STATUS API] Full transaction:', {
        id: transaction._id,
        status: transaction.status,
        amount: transaction.amount,
        timestamp: transaction.timestamp
      });

      res.json({ 
        status: transaction.status,
        timestamp: transaction.timestamp
      });
    } catch (error) {
      console.error('❌ [STATUS API] Error fetching transaction status:', error);
      res.status(500).json({ error: "Failed to fetch transaction status" });
    }
  });

  // Transaction log endpoint - Public endpoint for payment screenshots
  app.post("/api/transaction-log", async (req, res) => {
    try {
      // Validate input
      const schema = z.object({
        productTitle: z.string().min(1).max(500),
        amount: z.number().positive().max(10000000),
        screenshotBase64: z.string().optional()
      });

      const validated = schema.parse(req.body);
      const { productTitle, amount, screenshotBase64 } = validated;

      // Validate screenshot if provided
      if (screenshotBase64) {
        // Check size (max 5MB base64)
        if (screenshotBase64.length > 7000000) {
          return res.status(400).json({ error: "Screenshot too large (max 5MB)" });
        }

        // Validate base64 format and image type
        const base64Match = screenshotBase64.match(/^data:image\/(png|jpeg|jpg);base64,/);
        if (!base64Match) {
          return res.status(400).json({ error: "Invalid image format. Please upload PNG or JPG" });
        }

        // Decode and check minimum dimensions
        try {
          const base64Data = screenshotBase64.split(',')[1];
          const buffer = Buffer.from(base64Data, 'base64');
          
          // Basic size check - very small images likely invalid
          if (buffer.length < 1000) {
            return res.status(400).json({ error: "Image too small. Please upload a clear screenshot" });
          }
        } catch (err) {
          return res.status(400).json({ error: "Invalid image data" });
        }
      }

      // Create transaction log
      const log = await storage.createTransactionLog({
        userId: 'guest',
        amount,
        productTitle,
        status: 'pending'
      });

      const transactionId = log._id.toString();
      console.log('✅ [CREATE TX] Transaction created with ID:', transactionId);

      // Forward screenshot to admin on Telegram (async, don't wait)
      if (screenshotBase64) {
        console.log('📤 [CREATE TX] Forwarding screenshot to Telegram with txId:', transactionId);
        forwardScreenshotToAdmin(productTitle, amount, screenshotBase64, transactionId).catch(err => {
          console.error('⚠️ Failed to forward screenshot to Telegram admin:', err.message);
          // Log the failure but don't block the user
        });
      }

      res.status(201).json({ success: true, transactionId });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid input data", details: error.errors });
      }
      console.error('Error creating transaction log:', error);
      res.status(500).json({ error: "Failed to create transaction log" });
    }
  });

  // Tenant store transaction endpoint - uses admin's bot token if available
  app.post("/api/store/:slug/transaction-log", async (req, res) => {
    try {
      const { slug } = req.params;
      
      // Validate input
      const schema = z.object({
        productTitle: z.string().min(1).max(500),
        amount: z.number().positive().max(10000000),
        screenshotBase64: z.string().optional()
      });

      const validated = schema.parse(req.body);
      const { productTitle, amount, screenshotBase64 } = validated;

      // Validate screenshot if provided
      if (screenshotBase64) {
        if (screenshotBase64.length > 7000000) {
          return res.status(400).json({ error: "Screenshot too large (max 5MB)" });
        }
        const base64Match = screenshotBase64.match(/^data:image\/(png|jpeg|jpg);base64,/);
        if (!base64Match) {
          return res.status(400).json({ error: "Invalid image format. Please upload PNG or JPG" });
        }
      }

      // Find admin for this store to get adminId
      const admin = await Admin.findOne({ storeSlug: slug });
      
      // Create transaction log with admin scoping
      const log = await TransactionLog.create({
        userId: 'guest',
        amount,
        productTitle,
        status: 'pending',
        adminId: admin?._id || null,
        storeSlug: slug
      });

      const transactionId = log._id.toString();
      console.log(`✅ [TENANT TX] Transaction created for store ${slug} with ID:`, transactionId);

      // Forward screenshot - use admin's bot via BotManager
      if (screenshotBase64 && admin) {
        const { sendAdminPaymentNotification, getAdminBotStatus } = await import('./bot-manager');
        const adminId = admin._id.toString();
        
        if (getAdminBotStatus(adminId)) {
          // Use admin's bot via BotManager
          console.log(`📤 [TENANT TX] Using admin's bot for store ${slug}`);
          sendAdminPaymentNotification(adminId, productTitle, amount, screenshotBase64, transactionId).catch(err => {
            console.error('⚠️ Failed to send to tenant admin:', err.message);
          });
        } else {
          // Fall back to owner's bot
          console.log(`📤 [TENANT TX] Using owner's bot for store ${slug} (admin bot not active)`);
          forwardScreenshotToAdmin(productTitle, amount, screenshotBase64, transactionId).catch(err => {
            console.error('⚠️ Failed to forward screenshot:', err.message);
          });
        }
      } else if (screenshotBase64) {
        // No admin found, use owner's bot
        console.log(`📤 [TENANT TX] Using owner's bot for store ${slug} (no admin found)`);
        forwardScreenshotToAdmin(productTitle, amount, screenshotBase64, transactionId).catch(err => {
          console.error('⚠️ Failed to forward screenshot:', err.message);
        });
      }

      res.status(201).json({ success: true, transactionId });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid input data", details: error.errors });
      }
      console.error('Error creating tenant transaction log:', error);
      res.status(500).json({ error: "Failed to create transaction log" });
    }
  });

  // Tenant transaction status endpoint
  app.get("/api/store/:slug/transaction-status/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const transaction = await storage.getTransactionById(id);
      
      if (!transaction) {
        return res.status(404).json({ error: "Transaction not found" });
      }

      res.json({ 
        status: transaction.status,
        timestamp: transaction.timestamp
      });
    } catch (error) {
      console.error('Error fetching tenant transaction status:', error);
      res.status(500).json({ error: "Failed to fetch transaction status" });
    }
  });

  // Tenant QR code endpoint - returns admin-specific QR code
  app.get("/api/store/:slug/qr-code", async (req, res) => {
    try {
      const { slug } = req.params;
      
      // Find admin by storeSlug
      const admin = await Admin.findOne({ storeSlug: slug });
      
      if (admin) {
        // Try to find admin-specific QR code
        const QRCode = (await import('./models/QRCode')).default;
        const adminQR = await QRCode.findOne({ adminId: admin._id });
        
        if (adminQR && adminQR.imageUrl) {
          console.log(`✅ [QR] Found admin QR for store ${slug}`);
          return res.json({ imageUrl: adminQR.imageUrl });
        }
      }
      
      // Fall back to global/owner QR code
      console.log(`⚠️ [QR] No admin QR for store ${slug}, using owner QR`);
      const qrCode = await storage.getQRCode();
      res.json({ imageUrl: qrCode });
    } catch (error) {
      console.error('Error fetching tenant QR code:', error);
      res.status(500).json({ error: "Failed to fetch QR code" });
    }
  });

  // Owner Panel Login
  app.post("/api/owner/login", async (req, res) => {
    try {
      const { password } = req.body;
      const ownerPassword = process.env.OWNER_PASSWORD || 'Alex@123';
      
      if (password === ownerPassword) {
        // @ts-ignore - session types
        req.session.ownerAuth = true;
        // @ts-ignore - session types
        req.session.save((err: any) => {
          if (err) {
            console.error('Error saving session:', err);
            return res.status(500).json({ error: "Failed to save session" });
          }
          return res.json({ success: true, message: "Login successful" });
        });
      } else {
        return res.status(401).json({ error: "Invalid password" });
      }
    } catch (error) {
      console.error('Error during owner login:', error);
      res.status(500).json({ error: "Login failed" });
    }
  });

  // Check owner authentication
  app.get("/api/owner/check-auth", async (req, res) => {
    // @ts-ignore - session types
    const isAuth = !!req.session?.ownerAuth;
    res.json({ authenticated: isAuth });
  });

  // Owner logout
  app.post("/api/owner/logout", async (req, res) => {
    try {
      // @ts-ignore - session types
      req.session.ownerAuth = false;
      // @ts-ignore - session types
      req.session.save((err: any) => {
        if (err) {
          console.error('Error saving session during logout:', err);
          return res.status(500).json({ error: "Failed to logout" });
        }
        res.json({ success: true, message: "Logged out successfully" });
      });
    } catch (error) {
      console.error('Error during logout:', error);
      res.status(500).json({ error: "Logout failed" });
    }
  });

  // ============= ADMIN MANAGEMENT (Owner only) =============
  
  // Get all admins
  app.get("/api/owner/admins", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.ownerAuth) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      const admins = await Admin.find().select('-password').sort({ createdAt: -1 });
      res.json(admins);
    } catch (error) {
      console.error('Error fetching admins:', error);
      res.status(500).json({ error: "Failed to fetch admins" });
    }
  });

  // Create new admin
  app.post("/api/owner/admins", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.ownerAuth) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      const validatedData = createAdminSchema.parse(req.body);
      
      // Check if username already exists
      const existingAdmin = await Admin.findOne({ username: validatedData.username });
      if (existingAdmin) {
        return res.status(400).json({ error: "Username already exists" });
      }
      
      // Calculate expiry date
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + validatedData.expiryDays);
      
      // Generate storeSlug from username (lowercase, alphanumeric only)
      const storeSlug = validatedData.username.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
      
      const admin = new Admin({
        username: validatedData.username,
        password: validatedData.password,
        expiryDate,
        storeSlug,
        botToken: validatedData.botToken || null,
        botChatId: validatedData.botChatId || null
      });
      
      await admin.save();
      
      // Start the admin's bot if bot token is provided
      if (validatedData.botToken && validatedData.botChatId) {
        try {
          const { startAdminBot } = await import('./bot-manager');
          const started = await startAdminBot(
            admin._id.toString(), 
            validatedData.botToken, 
            validatedData.botChatId, 
            storeSlug
          );
          console.log(`🤖 Admin ${validatedData.username} bot started: ${started}`);
        } catch (botError) {
          console.error(`Failed to start bot for admin ${validatedData.username}:`, botError);
        }
      }
      
      const adminResponse = admin.toObject();
      delete adminResponse.password;
      
      res.status(201).json(adminResponse);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid input", details: error.errors });
      }
      console.error('Error creating admin:', error);
      res.status(500).json({ error: "Failed to create admin" });
    }
  });

  // Update admin
  app.patch("/api/owner/admins/:id", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.ownerAuth) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      const validatedData = updateAdminSchema.parse(req.body);
      const updateData: any = { ...validatedData };
      
      // If expiryDays provided, calculate new expiry date
      if (validatedData.expiryDays) {
        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + validatedData.expiryDays);
        updateData.expiryDate = expiryDate;
        delete updateData.expiryDays;
      }
      
      const admin = await Admin.findByIdAndUpdate(
        req.params.id,
        updateData,
        { new: true }
      ).select('-password');
      
      if (!admin) {
        return res.status(404).json({ error: "Admin not found" });
      }
      
      // Start/restart bot if bot token was updated
      if (validatedData.botToken && validatedData.botChatId && admin.storeSlug) {
        try {
          const { startAdminBot } = await import('./bot-manager');
          const started = await startAdminBot(
            admin._id.toString(), 
            validatedData.botToken, 
            validatedData.botChatId, 
            admin.storeSlug
          );
          console.log(`🤖 Admin ${admin.username} bot started: ${started}`);
        } catch (botError) {
          console.error(`Failed to start bot for admin ${admin.username}:`, botError);
        }
      }
      
      res.json(admin);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid input", details: error.errors });
      }
      console.error('Error updating admin:', error);
      res.status(500).json({ error: "Failed to update admin" });
    }
  });

  // ============= TENANT STORE ROUTES =============
  
  // Get store info by slug
  app.get("/api/store/:slug/info", async (req, res) => {
    try {
      const { slug } = req.params;
      
      // Handle owner-demo store specially
      if (slug === 'owner-demo') {
        return res.json({
          storeName: "Owner Demo Store",
          storeSlug: "owner-demo",
          adminUsername: "owner",
          isActive: true
        });
      }
      
      const admin = await Admin.findOne({ storeSlug: slug }).select('-password');
      
      if (!admin) {
        return res.status(404).json({ error: "Store not found" });
      }
      
      if (!admin.isActive || new Date() > admin.expiryDate) {
        return res.status(404).json({ error: "Store not available" });
      }
      
      res.json({
        storeName: admin.username + "'s Store",
        storeSlug: admin.storeSlug,
        adminUsername: admin.username,
        isActive: admin.isActive
      });
    } catch (error) {
      console.error('Error fetching store info:', error);
      res.status(500).json({ error: "Failed to fetch store info" });
    }
  });
  
  // Get flash sale products for a specific store
  app.get("/api/store/:slug/flash-sale", async (req, res) => {
    try {
      const { slug } = req.params;
      
      // Handle owner-demo store specially
      if (slug === 'owner-demo') {
        const { getSetting } = await import('./models/Settings');
        const activeScriptId = await getSetting('OWNER_ACTIVE_SCRIPT');
        if (activeScriptId) {
          const allProducts = await storage.getScriptProducts(activeScriptId);
          const flashProducts = allProducts.filter((p: any) => p.isFlashDeal);
          return res.json(flashProducts.slice(0, 20));
        }
        return res.json([]);
      }
      
      const admin = await Admin.findOne({ storeSlug: slug });
      
      if (!admin || !admin.isActive || new Date() > admin.expiryDate) {
        return res.json([]);
      }
      
      // If admin has an active script, get flash deal products from that script
      if (admin.activeScriptId) {
        // Use storage.getScriptProducts to fetch from dynamic script collections
        const allProducts = await storage.getScriptProducts(admin.activeScriptId);
        const flashProducts = allProducts.filter((p: any) => p.isFlashDeal);
        return res.json(flashProducts.slice(0, 20));
      }
      
      return res.json([]);
    } catch (error) {
      console.error('Error fetching store flash sale:', error);
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });
  
  // Get ALL products for a specific store (tenant isolation)
  app.get("/api/store/:slug/products", async (req, res) => {
    try {
      const { slug } = req.params;
      
      // Handle owner-demo store specially
      if (slug === 'owner-demo') {
        const { getSetting } = await import('./models/Settings');
        const activeScriptId = await getSetting('OWNER_ACTIVE_SCRIPT');
        if (activeScriptId) {
          const products = await storage.getScriptProducts(activeScriptId);
          return res.json(products.slice(0, 100));
        }
        return res.json([]);
      }
      
      const admin = await Admin.findOne({ storeSlug: slug });
      
      if (!admin || !admin.isActive || new Date() > admin.expiryDate) {
        return res.json([]);
      }
      
      // If admin has an active script, get ALL products using storage method
      if (admin.activeScriptId) {
        const products = await storage.getScriptProducts(admin.activeScriptId);
        return res.json(products.slice(0, 100));
      }
      
      return res.json([]);
    } catch (error) {
      console.error('Error fetching store products:', error);
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  // Tenant script products - same as products endpoint (for HomeSimpleClean compatibility)
  app.get("/api/store/:slug/script-products", async (req, res) => {
    try {
      const { slug } = req.params;
      
      const admin = await Admin.findOne({ storeSlug: slug });
      
      if (!admin || !admin.isActive || new Date() > admin.expiryDate) {
        return res.json([]);
      }
      
      if (admin.activeScriptId) {
        const products = await storage.getScriptProducts(admin.activeScriptId);
        return res.json(products);
      }
      
      return res.json([]);
    } catch (error) {
      console.error('Error fetching store script products:', error);
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });
  
  // Get a SINGLE product for a tenant store
  app.get("/api/store/:slug/product/:productId", async (req, res) => {
    try {
      const { slug, productId } = req.params;
      let activeScriptId: string | null = null;
      
      // Handle owner-demo store specially
      if (slug === 'owner-demo') {
        const { getSetting } = await import('./models/Settings');
        activeScriptId = await getSetting('OWNER_ACTIVE_SCRIPT');
        if (!activeScriptId) {
          return res.status(404).json({ error: "No active script" });
        }
      } else {
        const admin = await Admin.findOne({ storeSlug: slug });
        
        if (!admin || !admin.isActive || new Date() > admin.expiryDate) {
          return res.status(404).json({ error: "Store not found or inactive" });
        }
        
        if (!admin.activeScriptId) {
          return res.status(404).json({ error: "No active products" });
        }
        activeScriptId = admin.activeScriptId;
      }
      
      const products = await storage.getScriptProducts(activeScriptId);
      const product = products.find((p: any) => 
        p._id?.toString() === productId || 
        p.id?.toString() === productId || 
        p.slug === productId
      );
      
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      
      res.json(product);
    } catch (error) {
      console.error('Error fetching store product:', error);
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  // Delete admin
  app.delete("/api/owner/admins/:id", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.ownerAuth) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      const admin = await Admin.findByIdAndDelete(req.params.id);
      
      if (!admin) {
        return res.status(404).json({ error: "Admin not found" });
      }
      
      res.json({ success: true, message: "Admin deleted successfully" });
    } catch (error) {
      console.error('Error deleting admin:', error);
      res.status(500).json({ error: "Failed to delete admin" });
    }
  });

  // ============= SCRIPT PRODUCT MANAGEMENT (Owner only) =============
  
  // Get all products for a script
  app.get("/api/owner/scripts/:scriptId/products", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.ownerAuth) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      const products = await storage.getScriptProducts(req.params.scriptId);
      res.json(products);
    } catch (error) {
      console.error('Error fetching script products:', error);
      res.status(500).json({ error: "Failed to fetch script products" });
    }
  });

  // Add product to script
  app.post("/api/owner/scripts/:scriptId/products", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.ownerAuth) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      const productData = { ...req.body, scriptId: req.params.scriptId };
      const product = await storage.addProductToScript(productData);
      res.status(201).json(product);
    } catch (error) {
      console.error('Error adding product to script:', error);
      res.status(500).json({ error: "Failed to add product" });
    }
  });

  // Update product in script
  app.patch("/api/owner/scripts/:scriptId/products/:productId", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.ownerAuth) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      const updated = await storage.updateScriptProductById(req.params.scriptId, req.params.productId, req.body);
      if (updated) {
        res.json(updated);
      } else {
        res.status(404).json({ error: "Product not found" });
      }
    } catch (error) {
      console.error('Error updating product:', error);
      res.status(500).json({ error: "Failed to update product" });
    }
  });

  // Remove product from script
  app.delete("/api/owner/scripts/:scriptId/products/:productId", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.ownerAuth) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      await storage.removeScriptProduct(req.params.productId);
      res.json({ success: true });
    } catch (error) {
      console.error('Error removing product from script:', error);
      res.status(500).json({ error: "Failed to remove product" });
    }
  });

  // Owner Settings - API Status
  app.get("/api/owner/api-status", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.ownerAuth) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      const { getSetting } = await import('./models/Settings');
      const scraperKey = await getSetting('SCRAPER_API_KEY') || process.env.SCRAPER_API_KEY;
      const maskedKey = scraperKey ? `****${scraperKey.slice(-4)}` : null;
      res.json({ 
        scraperApiConfigured: !!scraperKey,
        maskedKey 
      });
    } catch (error) {
      console.error('Error checking API status:', error);
      res.status(500).json({ error: "Failed to check API status" });
    }
  });

  // Owner Settings - Save setting
  app.post("/api/owner/settings", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.ownerAuth) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      const { key, value } = req.body;
      if (!key || !value) {
        return res.status(400).json({ error: "Key and value required" });
      }
      const { setSetting } = await import('./models/Settings');
      await setSetting(key, value);
      res.json({ success: true });
    } catch (error) {
      console.error('Error saving setting:', error);
      res.status(500).json({ error: "Failed to save setting" });
    }
  });

  // Owner Settings - Delete setting
  app.delete("/api/owner/settings/:key", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.ownerAuth) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      const Settings = (await import('./models/Settings')).default;
      await Settings.deleteOne({ key: req.params.key });
      res.json({ success: true });
    } catch (error) {
      console.error('Error deleting setting:', error);
      res.status(500).json({ error: "Failed to delete setting" });
    }
  });

  // Owner Bot Settings - Get
  app.get("/api/owner/bot-settings", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.ownerAuth) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      const { getSetting } = await import('./models/Settings');
      const botToken = await getSetting('OWNER_BOT_TOKEN');
      const botChatId = await getSetting('OWNER_BOT_CHAT_ID');
      res.json({ 
        botToken: botToken ? '••••' + botToken.slice(-6) : null,
        botChatId: botChatId || null
      });
    } catch (error) {
      console.error('Error getting bot settings:', error);
      res.status(500).json({ error: "Failed to get bot settings" });
    }
  });

  // Owner Bot Settings - Save
  app.post("/api/owner/bot-settings", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.ownerAuth) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      const { botToken, botChatId } = req.body;
      if (!botToken || !botChatId) {
        return res.status(400).json({ error: "Bot token and chat ID required" });
      }
      const { setSetting } = await import('./models/Settings');
      await setSetting('OWNER_BOT_TOKEN', botToken);
      await setSetting('OWNER_BOT_CHAT_ID', botChatId);
      
      // Restart bot with new token
      const { restartTelegramBot } = await import('./telegram-bot');
      await restartTelegramBot(botToken);
      
      res.json({ success: true, message: "Bot settings saved and bot restarted" });
    } catch (error) {
      console.error('Error saving bot settings:', error);
      res.status(500).json({ error: "Failed to save bot settings" });
    }
  });

  // Owner Bot Settings - Delete
  app.delete("/api/owner/bot-settings", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.ownerAuth) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      const Settings = (await import('./models/Settings')).default;
      await Settings.deleteMany({ key: { $in: ['OWNER_BOT_TOKEN', 'OWNER_BOT_CHAT_ID'] } });
      res.json({ success: true });
    } catch (error) {
      console.error('Error deleting bot settings:', error);
      res.status(500).json({ error: "Failed to delete bot settings" });
    }
  });

  // Owner - Get run status
  app.get("/api/owner/run-status", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.ownerAuth) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      const { getSetting } = await import('./models/Settings');
      const activeScriptId = await getSetting('OWNER_ACTIVE_SCRIPT');
      res.json({ activeScriptId: activeScriptId || null });
    } catch (error) {
      console.error('Error getting run status:', error);
      res.status(500).json({ error: "Failed to get run status" });
    }
  });

  // Owner - Run/Stop script
  app.post("/api/owner/run-script", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.ownerAuth) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      const { scriptId } = req.body;
      const { setSetting } = await import('./models/Settings');
      const Settings = (await import('./models/Settings')).default;
      
      if (scriptId) {
        await setSetting('OWNER_ACTIVE_SCRIPT', scriptId);
      } else {
        await Settings.deleteOne({ key: 'OWNER_ACTIVE_SCRIPT' });
      }
      res.json({ success: true, activeScriptId: scriptId || null });
    } catch (error) {
      console.error('Error running script:', error);
      res.status(500).json({ error: "Failed to run script" });
    }
  });

  // ============= ADMIN PANEL LOGIN =============
  
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ error: "Username and password required" });
      }
      
      const admin = await Admin.findOne({ username }).select('+password');
      
      if (!admin) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      const isPasswordValid = await admin.comparePassword(password);
      if (!isPasswordValid) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      // Check if expired
      if (new Date() > admin.expiryDate) {
        return res.status(403).json({ error: "Account expired" });
      }
      
      if (!admin.isActive) {
        return res.status(403).json({ error: "Account disabled" });
      }
      
      // Update last login
      admin.lastLogin = new Date();
      await admin.save();
      
      // @ts-ignore
      req.session.adminAuth = true;
      // @ts-ignore
      req.session.adminId = admin._id.toString();
      // @ts-ignore
      req.session.save((err: any) => {
        if (err) {
          return res.status(500).json({ error: "Failed to save session" });
        }
        res.json({ 
          success: true, 
          admin: {
            id: admin._id,
            username: admin.username,
            expiryDate: admin.expiryDate
          }
        });
      });
    } catch (error) {
      console.error('Error during admin login:', error);
      res.status(500).json({ error: "Login failed" });
    }
  });

  // Check admin auth
  app.get("/api/admin/check-auth", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.adminAuth || !req.session?.adminId) {
        return res.json({ authenticated: false });
      }
      
      // @ts-ignore
      const admin = await Admin.findById(req.session.adminId).select('-password');
      
      if (!admin || !admin.isActive || new Date() > admin.expiryDate) {
        return res.json({ authenticated: false });
      }
      
      res.json({ 
        authenticated: true,
        admin: {
          id: admin._id,
          username: admin.username,
          expiryDate: admin.expiryDate,
          activeScriptId: admin.activeScriptId,
          storeSlug: admin.storeSlug || admin.username.toLowerCase().replace(/[^a-z0-9]/g, '-'),
          botToken: admin.botToken || null,
          botChatId: admin.botChatId || null
        }
      });
    } catch (error) {
      res.json({ authenticated: false });
    }
  });

  // Admin set active script
  app.post("/api/admin/set-script", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.adminAuth || !req.session?.adminId) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      const { scriptId } = req.body;
      
      // @ts-ignore
      const admin = await Admin.findById(req.session.adminId);
      
      if (!admin) {
        return res.status(404).json({ error: "Admin not found" });
      }
      
      admin.activeScriptId = scriptId || null;
      await admin.save();
      
      res.json({ success: true, activeScriptId: admin.activeScriptId });
    } catch (error) {
      console.error('Error setting script:', error);
      res.status(500).json({ error: "Failed to set script" });
    }
  });

  // Admin Bot Settings - Save
  app.post("/api/admin/bot-settings", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.adminAuth || !req.session?.adminId) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      const { botToken, botChatId } = req.body;
      
      if (!botToken || !botChatId) {
        return res.status(400).json({ error: "Bot token and chat ID are required" });
      }
      
      // @ts-ignore
      const adminId = req.session.adminId;
      const admin = await Admin.findById(adminId);
      
      if (!admin) {
        return res.status(404).json({ error: "Admin not found" });
      }
      
      admin.botToken = botToken;
      admin.botChatId = botChatId;
      await admin.save();
      
      // Start the admin's bot via BotManager
      const { startAdminBot } = await import('./bot-manager');
      const storeSlug = admin.storeSlug || admin.username.toLowerCase().replace(/[^a-z0-9]/g, '-');
      const started = await startAdminBot(adminId.toString(), botToken, botChatId, storeSlug);
      
      if (started) {
        res.json({ success: true, message: "Bot settings saved and bot started" });
      } else {
        res.json({ success: true, message: "Bot settings saved but bot failed to start. Please check your token." });
      }
    } catch (error) {
      console.error('Error saving admin bot settings:', error);
      res.status(500).json({ error: "Failed to save bot settings" });
    }
  });

  // Admin Bot Settings - Delete
  app.delete("/api/admin/bot-settings", async (req, res) => {
    try {
      // @ts-ignore
      if (!req.session?.adminAuth || !req.session?.adminId) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      // @ts-ignore
      const adminId = req.session.adminId;
      const admin = await Admin.findById(adminId);
      
      if (!admin) {
        return res.status(404).json({ error: "Admin not found" });
      }
      
      // Stop the admin's bot via BotManager
      const { stopAdminBot } = await import('./bot-manager');
      await stopAdminBot(adminId.toString());
      
      admin.botToken = null;
      admin.botChatId = null;
      await admin.save();
      
      res.json({ success: true, message: "Bot settings removed and bot stopped" });
    } catch (error) {
      console.error('Error removing admin bot settings:', error);
      res.status(500).json({ error: "Failed to remove bot settings" });
    }
  });

  // Admin logout
  app.post("/api/admin/logout", async (req, res) => {
    try {
      // @ts-ignore
      req.session.destroy((err: any) => {
        if (err) {
          return res.status(500).json({ error: "Failed to logout" });
        }
        res.clearCookie('connect.sid');
        res.json({ success: true });
      });
    } catch (error) {
      res.status(500).json({ error: "Logout failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
