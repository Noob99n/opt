import TelegramBot from 'node-telegram-bot-api';
import TransactionLog from './models/TransactionLog';
import QRCode from './models/QRCode';
import Admin from './models/Admin';
import { log, error as logError } from './logger';
import { uploadQRToCloudinary, deleteFromCloudinary } from './cloudinary';

interface AdminBot {
  bot: TelegramBot;
  botToken: string;
  adminId: string;
  storeSlug: string;
  chatId: string;
}

// Registry of active admin bots
const adminBots: Map<string, AdminBot> = new Map();

// Delete confirmation state per admin
const deleteConfirmation: Map<string, number> = new Map();

// Create admin-scoped handlers
function createAdminHandlers(bot: TelegramBot, botToken: string, adminId: string, storeSlug: string, chatId: string) {
  
  bot.on('message', async (msg) => {
    const msgChatId = msg.chat.id;
    const text = msg.text;
    const userId = msg.from?.id;
    
    // Only respond to authorized chat
    if (msgChatId.toString() !== chatId) {
      await bot.sendMessage(msgChatId, '❌ You are not authorized to use this bot.');
      return;
    }
    
    if (!text) {
      // Check if it's a photo for QR upload
      if (msg.photo && msg.photo.length > 0) {
        const fileId = msg.photo[msg.photo.length - 1].file_id;
        await handleQRUpload(bot, botToken, msgChatId, fileId, adminId, storeSlug);
      }
      return;
    }
    
    const command = text.toLowerCase().trim();
    
    if (command === '/start') {
      await handleStart(bot, msgChatId, storeSlug);
    } else if (command === '/status') {
      await handleStatus(bot, msgChatId, adminId);
    } else if (command === '/statusall') {
      await handleStatusAll(bot, msgChatId, adminId);
    } else if (command === '/change') {
      await handleChange(bot, msgChatId);
    } else if (command === '/delete' && userId) {
      await handleDelete(bot, msgChatId, userId, adminId);
    } else if (command === '/confirm1' && userId) {
      await handleDeleteConfirm(bot, msgChatId, userId, 1, adminId);
    } else if (command === '/confirm2' && userId) {
      await handleDeleteConfirm(bot, msgChatId, userId, 2, adminId);
    } else if (command === '/finalconfirm' && userId) {
      await handleDeleteConfirm(bot, msgChatId, userId, 3, adminId);
    } else if (command === '/approveall') {
      await handleApproveAll(bot, msgChatId, adminId);
    } else if (command === '/declineall') {
      await handleDeclineAll(bot, msgChatId, adminId);
    }
  });
  
  bot.on('callback_query', async (query) => {
    const data = query.data;
    const chatId = query.message?.chat.id;
    
    if (!data || !chatId) return;
    
    if (data.startsWith('approve_')) {
      const txId = data.replace('approve_', '');
      await handleApprove(bot, chatId, txId, adminId, query.id);
    } else if (data.startsWith('decline_')) {
      const txId = data.replace('decline_', '');
      await handleDecline(bot, chatId, txId, adminId, query.id);
    }
  });
  
  bot.on('polling_error', (error) => {
    console.error(`❌ [BOT ${storeSlug}] Polling error:`, error.message);
  });
}

async function handleStart(bot: TelegramBot, chatId: number, storeSlug: string) {
  const message = `
🎉 *Welcome to Your Store Bot!*

📦 Store: ${storeSlug}

*Available Commands:*
/status - View today's payment summary
/statusall - Export all transaction logs
/change - Instructions to change QR code
/delete - Delete all transaction logs
/approveall - Approve all pending payments
/declineall - Decline all pending payments

💡 *Tips:*
• Reply to approve/decline buttons on payment screenshots
• Send a new QR image to update your payment QR
  `;
  await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
}

async function handleStatus(bot: TelegramBot, chatId: number, adminId: string) {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const transactions = await TransactionLog.find({
      adminId,
      timestamp: { $gte: today }
    });
    
    const pending = transactions.filter(t => t.status === 'pending');
    const approved = transactions.filter(t => t.status === 'approved');
    const declined = transactions.filter(t => t.status === 'declined');
    
    const totalApproved = approved.reduce((sum, t) => sum + t.amount, 0);
    const totalPending = pending.reduce((sum, t) => sum + t.amount, 0);
    
    const message = `
📊 *Today's Payment Summary*

⏳ Pending: ${pending.length} (Rs. ${totalPending.toLocaleString()})
✅ Approved: ${approved.length} (Rs. ${totalApproved.toLocaleString()})
❌ Declined: ${declined.length}

📈 Total Transactions: ${transactions.length}
    `;
    
    await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
  } catch (error: any) {
    await bot.sendMessage(chatId, '❌ Error fetching statistics: ' + error.message);
  }
}

async function handleStatusAll(bot: TelegramBot, chatId: number, adminId: string) {
  try {
    const transactions = await TransactionLog.find({ adminId }).sort({ timestamp: -1 }).limit(50);
    
    if (transactions.length === 0) {
      await bot.sendMessage(chatId, '📄 No transactions found.');
      return;
    }
    
    let message = '📋 *Recent Transactions (Last 50)*\n\n';
    
    for (const tx of transactions) {
      const date = new Date(tx.timestamp).toLocaleString('en-IN');
      const status = tx.status === 'approved' ? '✅' : tx.status === 'declined' ? '❌' : '⏳';
      message += `${status} Rs.${tx.amount} - ${tx.productTitle.substring(0, 20)}... (${date})\n`;
    }
    
    await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
  } catch (error: any) {
    await bot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

async function handleChange(bot: TelegramBot, chatId: number) {
  const message = `
📷 *Change QR Code*

Simply send a new QR code image to this chat and it will be updated on your store automatically.

💡 Make sure the image is clear and readable.
  `;
  await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
}

async function handleQRUpload(bot: TelegramBot, botToken: string, chatId: number, fileId: string, adminId: string, storeSlug: string) {
  try {
    const file = await bot.getFile(fileId);
    const telegramFileUrl = `https://api.telegram.org/file/bot${botToken}/${file.file_path}`;
    
    // Get existing QR to delete old image from Cloudinary
    const existingQR = await QRCode.findOne({ adminId });
    if (existingQR?.cloudinaryPublicId) {
      console.log('🗑️ Deleting old admin QR from Cloudinary:', existingQR.cloudinaryPublicId);
      await deleteFromCloudinary(existingQR.cloudinaryPublicId);
    }

    // Upload to Cloudinary
    await bot.sendMessage(chatId, '⏳ Uploading QR to cloud...');
    const cloudinaryResult = await uploadQRToCloudinary(telegramFileUrl, `qr-codes/${storeSlug}`);
    
    // Update or create QR code for this admin with Cloudinary URL
    await QRCode.findOneAndUpdate(
      { adminId },
      { 
        imageUrl: cloudinaryResult.url,
        cloudinaryPublicId: cloudinaryResult.publicId,
        adminId,
        storeSlug,
        updatedAt: new Date(),
        updatedBy: 'admin-bot'
      },
      { upsert: true, new: true }
    );
    
    console.log('✅ Admin QR uploaded to Cloudinary:', cloudinaryResult.url);
    await bot.sendMessage(chatId, '✅ QR code uploaded to cloud! The new QR is now live on your store.');
  } catch (error: any) {
    console.error('❌ Error updating QR code:', error);
    await bot.sendMessage(chatId, '❌ Error updating QR code: ' + error.message);
  }
}

async function handleDelete(bot: TelegramBot, chatId: number, userId: number, adminId: string) {
  const key = `${adminId}_${userId}`;
  deleteConfirmation.set(key, 1);
  
  const count = await TransactionLog.countDocuments({ adminId });
  
  const message = `
⚠️ *DELETE ALL TRANSACTIONS*

You are about to delete ${count} transaction(s).

This action is IRREVERSIBLE!

Type /confirm1 to proceed to next step.
  `;
  await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
}

async function handleDeleteConfirm(bot: TelegramBot, chatId: number, userId: number, step: number, adminId: string) {
  const key = `${adminId}_${userId}`;
  const currentStep = deleteConfirmation.get(key) || 0;
  
  if (currentStep !== step) {
    await bot.sendMessage(chatId, '❌ Invalid confirmation step. Start again with /delete');
    return;
  }
  
  if (step === 1) {
    deleteConfirmation.set(key, 2);
    await bot.sendMessage(chatId, '⚠️ *Step 2/3*\n\nType /confirm2 to continue.', { parse_mode: 'Markdown' });
  } else if (step === 2) {
    deleteConfirmation.set(key, 3);
    await bot.sendMessage(chatId, '🚨 *FINAL STEP*\n\nType /finalconfirm to DELETE ALL.', { parse_mode: 'Markdown' });
  } else if (step === 3) {
    try {
      const result = await TransactionLog.deleteMany({ adminId });
      deleteConfirmation.delete(key);
      await bot.sendMessage(chatId, `✅ Deleted ${result.deletedCount} transaction(s).`, { parse_mode: 'Markdown' });
    } catch (error: any) {
      await bot.sendMessage(chatId, '❌ Error deleting: ' + error.message);
    }
  }
}

async function handleApprove(bot: TelegramBot, chatId: number, txId: string, adminId: string, queryId?: string) {
  try {
    const transaction = await TransactionLog.findOne({ _id: txId, adminId });
    
    if (!transaction) {
      const msg = '❌ Transaction not found';
      if (queryId) await bot.answerCallbackQuery(queryId, { text: msg });
      else await bot.sendMessage(chatId, msg);
      return;
    }
    
    if (transaction.status !== 'pending') {
      const msg = `⚠️ Already ${transaction.status}`;
      if (queryId) await bot.answerCallbackQuery(queryId, { text: msg });
      else await bot.sendMessage(chatId, msg);
      return;
    }
    
    transaction.status = 'approved';
    await transaction.save();
    
    const message = `✅ *Payment Approved!*\n\n💰 Amount: Rs. ${transaction.amount.toLocaleString()}`;
    
    if (queryId) {
      await bot.answerCallbackQuery(queryId, { text: '✅ Approved!' });
      await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } else {
      await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    }
  } catch (error: any) {
    const msg = '❌ Error: ' + error.message;
    if (queryId) await bot.answerCallbackQuery(queryId, { text: msg });
    else await bot.sendMessage(chatId, msg);
  }
}

async function handleDecline(bot: TelegramBot, chatId: number, txId: string, adminId: string, queryId?: string) {
  try {
    const transaction = await TransactionLog.findOne({ _id: txId, adminId });
    
    if (!transaction) {
      const msg = '❌ Transaction not found';
      if (queryId) await bot.answerCallbackQuery(queryId, { text: msg });
      else await bot.sendMessage(chatId, msg);
      return;
    }
    
    if (transaction.status !== 'pending') {
      const msg = `⚠️ Already ${transaction.status}`;
      if (queryId) await bot.answerCallbackQuery(queryId, { text: msg });
      else await bot.sendMessage(chatId, msg);
      return;
    }
    
    transaction.status = 'declined';
    await transaction.save();
    
    const message = `❌ *Payment Declined*\n\n💰 Amount: Rs. ${transaction.amount.toLocaleString()}`;
    
    if (queryId) {
      await bot.answerCallbackQuery(queryId, { text: '❌ Declined' });
      await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } else {
      await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    }
  } catch (error: any) {
    const msg = '❌ Error: ' + error.message;
    if (queryId) await bot.answerCallbackQuery(queryId, { text: msg });
    else await bot.sendMessage(chatId, msg);
  }
}

async function handleApproveAll(bot: TelegramBot, chatId: number, adminId: string) {
  try {
    const pending = await TransactionLog.find({ adminId, status: 'pending' });
    
    if (pending.length === 0) {
      await bot.sendMessage(chatId, '⚠️ No pending payments to approve.');
      return;
    }
    
    let count = 0;
    let total = 0;
    
    for (const tx of pending) {
      tx.status = 'approved';
      await tx.save();
      count++;
      total += tx.amount;
    }
    
    await bot.sendMessage(chatId, `✅ Approved ${count} payments (Rs. ${total.toLocaleString()})`, { parse_mode: 'Markdown' });
  } catch (error: any) {
    await bot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

async function handleDeclineAll(bot: TelegramBot, chatId: number, adminId: string) {
  try {
    const pending = await TransactionLog.find({ adminId, status: 'pending' });
    
    if (pending.length === 0) {
      await bot.sendMessage(chatId, '⚠️ No pending payments to decline.');
      return;
    }
    
    let count = 0;
    
    for (const tx of pending) {
      tx.status = 'declined';
      await tx.save();
      count++;
    }
    
    await bot.sendMessage(chatId, `❌ Declined ${count} payments`, { parse_mode: 'Markdown' });
  } catch (error: any) {
    await bot.sendMessage(chatId, '❌ Error: ' + error.message);
  }
}

// Start a bot for a specific admin
export async function startAdminBot(adminId: string, botToken: string, chatId: string, storeSlug: string): Promise<boolean> {
  try {
    // Stop existing bot if any
    await stopAdminBot(adminId);
    
    log(`🤖 [BOT MANAGER] Starting bot for admin ${storeSlug}...`);
    
    const bot = new TelegramBot(botToken, { polling: true });
    
    // Set up handlers
    createAdminHandlers(bot, botToken, adminId, storeSlug, chatId);
    
    // Store in registry
    adminBots.set(adminId, { bot, botToken, adminId, storeSlug, chatId });
    
    log(`✅ [BOT MANAGER] Bot started for ${storeSlug}`);
    return true;
  } catch (error) {
    logError(`❌ [BOT MANAGER] Failed to start bot for ${storeSlug}:`, error);
    return false;
  }
}

// Stop a bot for a specific admin
export async function stopAdminBot(adminId: string): Promise<void> {
  const existing = adminBots.get(adminId);
  if (existing) {
    try {
      existing.bot.removeAllListeners();
      await existing.bot.stopPolling();
      adminBots.delete(adminId);
      log(`🛑 [BOT MANAGER] Bot stopped for ${existing.storeSlug}`);
    } catch (error) {
      logError(`❌ [BOT MANAGER] Error stopping bot:`, error);
    }
  }
}

// Start all admin bots on app startup
export async function startAllAdminBots(): Promise<void> {
  try {
    const admins = await Admin.find({
      isActive: true,
      expiryDate: { $gt: new Date() },
      botToken: { $ne: null },
      botChatId: { $ne: null }
    });
    
    log(`🤖 [BOT MANAGER] Found ${admins.length} admins with bot tokens`);
    
    for (const admin of admins) {
      if (admin.botToken && admin.botChatId) {
        const slug = admin.storeSlug || admin.username.toLowerCase().replace(/[^a-z0-9]/g, '-');
        await startAdminBot(admin._id.toString(), admin.botToken, admin.botChatId, slug);
        // Small delay between bot starts to avoid rate limits
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }
    
    log(`✅ [BOT MANAGER] All admin bots started`);
  } catch (error) {
    logError('❌ [BOT MANAGER] Error starting admin bots:', error);
  }
}

// Send payment notification to admin's bot
export async function sendAdminPaymentNotification(
  adminId: string,
  productTitle: string,
  amount: number,
  screenshotBase64: string,
  transactionId: string
): Promise<boolean> {
  const adminBot = adminBots.get(adminId);
  
  if (!adminBot) {
    console.log(`⚠️ [BOT MANAGER] No active bot for admin ${adminId}`);
    return false;
  }
  
  try {
    const buffer = Buffer.from(screenshotBase64.split(',')[1], 'base64');
    
    const message = `
💳 *New Payment Screenshot*

📦 Product: ${productTitle}
💰 Amount: Rs. ${amount.toLocaleString()}
🕐 Time: ${new Date().toLocaleString('en-IN')}
🆔 ID: ${transactionId.substring(transactionId.length - 6)}

⏳ Status: Pending Review
    `;
    
    await adminBot.bot.sendPhoto(parseInt(adminBot.chatId), buffer, {
      caption: message,
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '✅ Approve', callback_data: `approve_${transactionId}` },
            { text: '❌ Decline', callback_data: `decline_${transactionId}` }
          ]
        ]
      }
    });
    
    console.log(`✅ [BOT MANAGER] Notification sent to ${adminBot.storeSlug}`);
    return true;
  } catch (error) {
    console.error(`❌ [BOT MANAGER] Error sending notification:`, error);
    return false;
  }
}

// Get admin bot status
export function getAdminBotStatus(adminId: string): boolean {
  return adminBots.has(adminId);
}

// Get all active bots count
export function getActiveBotCount(): number {
  return adminBots.size;
}

