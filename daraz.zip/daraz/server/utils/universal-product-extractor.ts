/**
 * Universal Product Extractor
 * Intelligently extracts product data from any e-commerce website
 * Supports: Amazon, Flipkart, Daraz, and any other e-commerce site
 */

interface ProductData {
  title: string;
  description: string;
  price: string;
  originalPrice: string;
  discount?: string;
  images: string[];
  reviews: Array<{
    author: string;
    rating: number;
    text: string;
    date: string;
  }>;
  brand?: string;
  rating?: string;
  reviewCount?: number;
  url: string;
  success: boolean;
  // Enhanced specification fields
  highlights?: string[];
  technicalDetails?: string[];
  specifications?: Record<string, string>;
  // Daraz-specific fields for iPhone/Android
  colorVariants?: string[];
  deliveryCharge?: string;
  deliveryLocation?: string;
  freeReturn?: string;
  warranty?: string;
  disclaimer?: string;
}

/**
 * Extract Daraz-specific data from page JSON payload
 * Daraz stores product data in window.__INIT_DATA__ or script tags with JSON
 */
function extractDarazJsonPayload($: any, html: string): Partial<ProductData> | null {
  console.log('🔍 Attempting Daraz JSON payload extraction...');
  
  const result: Partial<ProductData> = {};
  
  try {
    // Method 1: Look for __INIT_DATA__ in script tags
    const initDataMatch = html.match(/window\.__INIT_DATA__\s*=\s*(\{[\s\S]*?\});?\s*(?:<\/script>|window\.|$)/);
    if (initDataMatch) {
      try {
        const initData = JSON.parse(initDataMatch[1]);
        console.log('📦 Found __INIT_DATA__');
        
        // Extract from data.root.fields.product
        const product = initData?.data?.root?.fields?.product || 
                       initData?.mods?.product ||
                       initData?.pageData?.product;
        
        if (product) {
          if (product.title) result.title = product.title;
          if (product.desc || product.description) result.description = product.desc || product.description;
          
          // Prices
          const skuInfo = product.skuInfos?.[0] || product.skuBase?.skus?.[0] || {};
          const priceInfo = product.priceInfo || skuInfo.price || {};
          
          if (priceInfo.salePrice?.value) {
            result.price = String(priceInfo.salePrice.value);
          } else if (priceInfo.price?.value) {
            result.price = String(priceInfo.price.value);
          } else if (skuInfo.price) {
            result.price = String(skuInfo.price);
          }
          
          if (priceInfo.originalPrice?.value) {
            result.originalPrice = String(priceInfo.originalPrice.value);
          } else if (priceInfo.tagPrice?.value) {
            result.originalPrice = String(priceInfo.tagPrice.value);
          }
          
          // Images
          const images: string[] = [];
          if (product.images && Array.isArray(product.images)) {
            product.images.forEach((img: any) => {
              const url = typeof img === 'string' ? img : img.url || img.src;
              if (url && images.length < 6) images.push(url);
            });
          }
          if (product.image) {
            images.unshift(typeof product.image === 'string' ? product.image : product.image.url);
          }
          if (images.length > 0) result.images = images;
          
          // Brand
          if (product.brand) result.brand = product.brand;
          
          // Highlights
          if (product.highlights && Array.isArray(product.highlights)) {
            result.highlights = product.highlights.map((h: any) => typeof h === 'string' ? h : h.text || '').filter(Boolean);
          }
          
          // Specifications
          if (product.specifications || product.props) {
            const specs: Record<string, string> = {};
            const specData = product.specifications || product.props || [];
            if (Array.isArray(specData)) {
              specData.forEach((spec: any) => {
                const key = spec.name || spec.key || spec.label;
                const value = spec.value || spec.text;
                if (key && value) {
                  specs[key.toLowerCase().replace(/\s+/g, '')] = value;
                }
              });
            }
            if (Object.keys(specs).length > 0) result.specifications = specs;
          }
        }
      } catch (e) {
        console.log('❌ Failed to parse __INIT_DATA__:', e);
      }
    }
    
    // Method 2: Look for pdpData or pageData in script tags
    const scripts = $('script:not([src])').toArray();
    for (const script of scripts) {
      const content = $(script).html() || '';
      
      // Look for various Daraz/Lazada JSON patterns
      const patterns = [
        /var\s+(?:pdpData|pageData)\s*=\s*(\{[\s\S]*?\});/,
        /__moduleData__\s*=\s*(\{[\s\S]*?\});/,
        /window\.pageData\s*=\s*(\{[\s\S]*?\});/,
        /"product"\s*:\s*(\{[^}]+(?:\{[^}]*\}[^}]*)*\})/
      ];
      
      for (const pattern of patterns) {
        const match = content.match(pattern);
        if (match) {
          try {
            const data = JSON.parse(match[1]);
            console.log('📦 Found pageData/pdpData in script');
            
            // Extract product info
            const product = data.product || data.item || data;
            
            if (!result.title && (product.title || product.name)) {
              result.title = product.title || product.name;
            }
            if (!result.description && (product.description || product.desc || product.longDescription)) {
              result.description = product.description || product.desc || product.longDescription;
            }
            
            // Prices from various structures
            if (!result.price) {
              const price = product.price || product.salePrice || product.promotionPrice ||
                           data.price?.salePrice || data.priceInfo?.salePrice?.value;
              if (price) result.price = String(typeof price === 'object' ? price.value || price.amount : price);
            }
            
            if (!result.originalPrice) {
              const origPrice = product.originalPrice || product.tagPrice || product.listPrice ||
                               data.price?.originalPrice || data.priceInfo?.originalPrice?.value;
              if (origPrice) result.originalPrice = String(typeof origPrice === 'object' ? origPrice.value || origPrice.amount : origPrice);
            }
            
            // Images
            if (!result.images || result.images.length === 0) {
              const images: string[] = [];
              const imgSources = product.images || product.gallery || product.imageList || data.images || [];
              if (Array.isArray(imgSources)) {
                imgSources.forEach((img: any) => {
                  const url = typeof img === 'string' ? img : (img.url || img.src || img.original);
                  if (url && images.length < 6) {
                    // Fix Daraz image URLs
                    const fixedUrl = url.startsWith('//') ? 'https:' + url : url;
                    images.push(fixedUrl);
                  }
                });
              }
              if (images.length > 0) result.images = images;
            }
            
            // Brand
            if (!result.brand && product.brand) {
              result.brand = typeof product.brand === 'object' ? product.brand.name : product.brand;
            }
          } catch (e) {
            // Continue to next pattern
          }
        }
      }
    }
    
    // Method 3: Extract from HTML data attributes (Daraz uses data-* attributes)
    const productElement = $('[data-aplus-ae]').first();
    if (productElement.length) {
      try {
        const aplusData = productElement.attr('data-aplus-ae');
        if (aplusData) {
          const data = JSON.parse(aplusData);
          if (!result.title && data.title) result.title = data.title;
          if (!result.price && data.price) result.price = String(data.price);
        }
      } catch (e) {
        // Ignore parsing errors
      }
    }
    
    // Method 4: Extract prices from visible HTML elements with better selectors
    if (!result.price || !result.originalPrice) {
      // Current/sale price
      const priceSelectors = [
        '.pdp-price.pdp-price_type_normal',
        '.pdp-price_color_orange',
        'span[data-spm="price"]',
        '.pdp-product-price .pdp-price',
        '#module_product_price_1 .pdp-price',
        '.origin-block .pdp-price'
      ];
      
      for (const sel of priceSelectors) {
        const priceText = $(sel).first().text().trim();
        if (priceText && !result.price) {
          const cleanPrice = priceText.replace(/[^\d.,]/g, '').replace(/,/g, '');
          if (cleanPrice) {
            result.price = cleanPrice;
            console.log('💰 Found price from selector:', sel, cleanPrice);
            break;
          }
        }
      }
      
      // Original/crossed price
      const origPriceSelectors = [
        '.pdp-price.pdp-price_type_deleted',
        '.origin-block .pdp-price_type_deleted',
        'span.pdp-price_type_deleted',
        '.pdp-product-price del',
        '#module_product_price_1 .pdp-price_type_deleted'
      ];
      
      for (const sel of origPriceSelectors) {
        const priceText = $(sel).first().text().trim();
        if (priceText && !result.originalPrice) {
          const cleanPrice = priceText.replace(/[^\d.,]/g, '').replace(/,/g, '');
          if (cleanPrice) {
            result.originalPrice = cleanPrice;
            console.log('💰 Found original price from selector:', sel, cleanPrice);
            break;
          }
        }
      }
    }
    
    // Method 5: Extract images from gallery
    if (!result.images || result.images.length === 0) {
      const images: string[] = [];
      
      // Daraz image gallery selectors
      const imgSelectors = [
        '.item-gallery__thumbnail img',
        '.item-gallery-slider img',
        '.pdp-mod-common-image img',
        '[data-gallery] img',
        '.gallery-preview-panel img',
        '.pdp-block__gallery img'
      ];
      
      for (const sel of imgSelectors) {
        $(sel).each((_: any, el: any) => {
          const src = $(el).attr('src') || $(el).attr('data-src') || $(el).attr('data-lazy-src');
          if (src && images.length < 6) {
            // Fix URL and get high resolution version
            let fixedUrl = src.startsWith('//') ? 'https:' + src : src;
            // Remove thumbnail sizing to get full image
            fixedUrl = fixedUrl.replace(/_\d+x\d+/, '').replace(/\.jpg_\d+x\d+\.jpg/, '.jpg');
            if (!images.includes(fixedUrl)) {
              images.push(fixedUrl);
            }
          }
        });
        if (images.length >= 4) break;
      }
      
      if (images.length > 0) result.images = images;
    }
    
    // Method 6: Extract description from HTML
    if (!result.description) {
      const descSelectors = [
        '.pdp-product-desc',
        '.detail-content',
        '.pdp-mod-product-feature',
        '#module_product_detail .detail-content',
        '.product-description'
      ];
      
      for (const sel of descSelectors) {
        const descText = $(sel).first().text().trim();
        if (descText && descText.length > 20) {
          result.description = descText.substring(0, 1000);
          break;
        }
      }
    }
    
    // Method 7: Extract highlights from HTML
    if (!result.highlights || result.highlights.length === 0) {
      const highlights: string[] = [];
      
      $('.pdp-product-highlights li, .pdp-mod-product-badge-desc li, .key-features li').each((_: any, el: any) => {
        const text = $(el).text().trim();
        if (text && highlights.length < 10) {
          highlights.push(text);
        }
      });
      
      if (highlights.length > 0) result.highlights = highlights;
    }
    
    // Method 8: Extract specifications from table
    if (!result.specifications || Object.keys(result.specifications).length === 0) {
      const specs: Record<string, string> = {};
      
      // Table-based specs
      $('.specification-keys li, .pdp-mod-specification li').each((_: any, el: any) => {
        const keyEl = $(el).find('.key-li, .key-value');
        const valEl = $(el).find('.val-li, .value-value');
        
        if (keyEl.length && valEl.length) {
          const key = keyEl.text().trim().toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, '');
          const value = valEl.text().trim();
          if (key && value) {
            specs[key] = value;
          }
        }
      });
      
      // Also try table rows
      $('.pdp-general-features tr, .specification-table tr').each((_: any, el: any) => {
        const th = $(el).find('th, td:first-child').text().trim();
        const td = $(el).find('td:last-child').text().trim();
        if (th && td && th !== td) {
          const key = th.toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, '');
          specs[key] = td;
        }
      });
      
      if (Object.keys(specs).length > 0) result.specifications = specs;
    }
    
  } catch (e) {
    console.log('❌ Error in Daraz JSON extraction:', e);
  }
  
  console.log('📊 Daraz extraction result:', {
    hasTitle: !!result.title,
    hasPrice: !!result.price,
    hasOriginalPrice: !!result.originalPrice,
    imagesCount: result.images?.length || 0,
    hasDescription: !!result.description,
    highlightsCount: result.highlights?.length || 0,
    specsCount: Object.keys(result.specifications || {}).length
  });
  
  return Object.keys(result).length > 0 ? result : null;
}

/**
 * Extract Daraz product using search API and product name from URL
 * Daraz blocks direct product page access, so we use their search API
 */
async function extractDarazViaApi(url: string, axios: any): Promise<Partial<ProductData> | null> {
  console.log('🔍 Attempting Daraz search API extraction...');
  
  // Extract product name from URL
  // URL formats: 
  // 1. https://www.daraz.com.np/products/product-name-i{itemId}-s{skuId}.html
  // 2. https://www.daraz.com.np/products/product-name-i{itemId}.html (no skuId)
  const productNameMatch = url.match(/\/products\/(.+?)(?:-i\d+)(?:-s\d+)?\.html/);
  if (!productNameMatch) {
    console.log('❌ Could not extract product name from Daraz URL');
    return null;
  }
  
  const productSlug = productNameMatch[1];
  // Convert slug to search query - extract main product name
  const words = productSlug.replace(/-/g, ' ').split(' ');
  
  // Take first 3-5 meaningful words (brand + model usually)
  // Skip common non-meaningful words and long spec numbers
  const meaningfulWords: string[] = [];
  for (const word of words) {
    // Skip spec words (numbers with units)
    if (/^\d+gb$/i.test(word)) continue;
    if (/^\d+mp$/i.test(word)) continue;
    if (/^\d+mah$/i.test(word)) continue;
    if (/^\d+hz$/i.test(word)) continue;
    if (/^\d+inch$/i.test(word)) continue;
    if (/^\d+\"$/i.test(word)) continue;
    if (/^ram$/i.test(word)) continue;
    if (/^rom$/i.test(word)) continue;
    if (/^display$/i.test(word)) continue;
    if (/^battery$/i.test(word)) continue;
    if (/^camera$/i.test(word)) continue;
    // Skip standalone numbers
    if (/^\d+$/.test(word)) continue;
    
    meaningfulWords.push(word);
    if (meaningfulWords.length >= 5) break;
  }
  
  let searchQuery = meaningfulWords.join(' ').slice(0, 40);
  // If too short, use original first 25 chars
  if (searchQuery.length < 8) {
    searchQuery = productSlug.replace(/-/g, ' ').slice(0, 25);
  }
  console.log(`🔍 Search query: "${searchQuery}"`);
  
  // Determine the Daraz region
  let region = 'np';
  if (url.includes('daraz.pk')) region = 'pk';
  else if (url.includes('daraz.lk')) region = 'lk';
  else if (url.includes('daraz.bd')) region = 'bd';
  
  const result: Partial<ProductData> = {};
  
  try {
    // Use Daraz search API with ajax=true
    const searchUrl = `https://www.daraz.com.${region}/catalog/?ajax=true&q=${encodeURIComponent(searchQuery)}`;
    console.log('🌐 Searching via API:', searchUrl);
    
    const searchResponse = await axios.get(searchUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.9',
        'X-Requested-With': 'XMLHttpRequest',
        'Referer': `https://www.daraz.com.${region}/`
      },
      timeout: 15000,
      validateStatus: () => true
    });
    
    if (searchResponse.status === 200 && typeof searchResponse.data === 'object') {
      const data = searchResponse.data;
      console.log('✅ Daraz search API response received');
      
      // Find products in listItems
      const listItems = data.mods?.listItems || [];
      
      if (listItems.length > 0) {
        // Get the first matching product
        const product = listItems[0];
        console.log('📦 Found product in search results');
        
        // Extract basic info
        if (product.name) result.title = product.name;
        if (product.title) result.title = product.title;
        
        // Prices - clean numeric value from Daraz price format
        const cleanPrice = (val: any): string => {
          if (!val) return '';
          // Remove currency symbol, commas, spaces, then extract number
          const cleaned = String(val)
            .replace(/Rs\.?\s*/gi, '')
            .replace(/NPR\.?\s*/gi, '')
            .replace(/[,\s]/g, '')
            .trim();
          // Extract the numeric portion
          const match = cleaned.match(/(\d+(?:\.\d+)?)/);
          return match ? match[1] : '';
        };
        
        if (product.price) result.price = cleanPrice(product.price);
        if (product.priceShow) {
          const priceNum = cleanPrice(product.priceShow);
          if (priceNum) result.price = priceNum;
        }
        if (product.originalPrice) {
          result.originalPrice = cleanPrice(product.originalPrice);
        }
        if (product.originalPriceShow) {
          const origNum = cleanPrice(product.originalPriceShow);
          if (origNum) result.originalPrice = origNum;
        }
        
        // Images - MAX 4 only
        const images: string[] = [];
        if (product.image) {
          let imgUrl = product.image;
          if (imgUrl.startsWith('//')) imgUrl = 'https:' + imgUrl;
          images.push(imgUrl);
        }
        if (product.thumbs && Array.isArray(product.thumbs)) {
          product.thumbs.forEach((thumb: any) => {
            if (images.length >= 4) return; // Max 4 images
            let imgUrl = typeof thumb === 'string' ? thumb : thumb.image || thumb.src;
            if (imgUrl) {
              if (imgUrl.startsWith('//')) imgUrl = 'https:' + imgUrl;
              if (!images.includes(imgUrl)) images.push(imgUrl);
            }
          });
        }
        // Limit to max 4 images
        if (images.length > 0) result.images = images.slice(0, 4);
        
        // Brand
        if (product.brandName) result.brand = product.brandName;
        
        // Rating - extract real rating from Daraz
        if (product.ratingScore) result.rating = String(product.ratingScore);
        if (product.review) result.reviewCount = Number(product.review) || 0;
        
        // Calculate discount percentage
        if (result.price && result.originalPrice) {
          const salePrice = parseFloat(result.price);
          const origPrice = parseFloat(result.originalPrice);
          if (origPrice > salePrice && origPrice > 0) {
            const discountPercent = Math.round(((origPrice - salePrice) / origPrice) * 100);
            result.discount = `${discountPercent}%`;
          }
        }
        // Also check if discount is provided directly
        if (product.discount && !result.discount) {
          result.discount = String(product.discount).replace(/-/g, '');
        }
        
        // Color Variants - extract only color options
        const colorVariants: string[] = [];
        if (product.skuVariants && Array.isArray(product.skuVariants)) {
          product.skuVariants.forEach((variant: any) => {
            if (variant.name && variant.name.toLowerCase().includes('color')) {
              if (variant.options && Array.isArray(variant.options)) {
                variant.options.forEach((opt: any) => {
                  const colorName = typeof opt === 'string' ? opt : opt.name || opt.value;
                  if (colorName && !colorVariants.includes(colorName)) {
                    colorVariants.push(colorName);
                  }
                });
              }
            }
          });
        }
        // Also check in itemAttributes
        if (product.itemAttributes && Array.isArray(product.itemAttributes)) {
          product.itemAttributes.forEach((attr: any) => {
            if (attr.name && attr.name.toLowerCase().includes('color')) {
              const colorName = attr.value;
              if (colorName && !colorVariants.includes(colorName)) {
                colorVariants.push(colorName);
              }
            }
          });
        }
        if (colorVariants.length > 0) result.colorVariants = colorVariants;
        
        // Default Delivery Info for Kathmandu (iPhone/Android category)
        result.deliveryLocation = 'Kathmandu';
        result.deliveryCharge = '75'; // Rs 75 standard delivery
        
        // Default Service Info
        result.freeReturn = '14 Days Free Return';
        result.warranty = '1 Year Brand Warranty';
        
        // Description - try multiple sources
        if (product.description) result.description = product.description;
        if (product.shortDescription && !result.description) result.description = product.shortDescription;
        
        // Highlights from promotion tags, icons, or product features
        const highlights: string[] = [];
        
        // Extract from icons/promotion tags
        if (product.icons && Array.isArray(product.icons)) {
          product.icons.forEach((icon: any) => {
            const text = typeof icon === 'string' ? icon : icon.text || icon.title || icon.name;
            if (text && text.length > 3 && text.length < 100) {
              highlights.push(text);
            }
          });
        }
        
        // Extract from promotion tags
        if (product.promotionTags && Array.isArray(product.promotionTags)) {
          product.promotionTags.forEach((tag: any) => {
            const text = typeof tag === 'string' ? tag : tag.text || tag.title;
            if (text && text.length > 3) {
              highlights.push(text);
            }
          });
        }
        
        if (highlights.length > 0) {
          result.highlights = highlights;
        }
        
        // Generate description from available data if none exists
        if (!result.description && result.title) {
          const descParts: string[] = [];
          if (result.brand) descParts.push(`Brand: ${result.brand}`);
          if (descParts.length > 0) {
            result.description = descParts.join('\n');
          }
        }
        
        console.log('📊 Daraz search extraction result:', {
          hasTitle: !!result.title,
          hasPrice: !!result.price,
          hasOriginalPrice: !!result.originalPrice,
          discount: result.discount,
          imagesCount: result.images?.length || 0,
          hasBrand: !!result.brand,
          hasRating: !!result.rating,
          colorVariantsCount: colorVariants.length,
          hasDescription: !!result.description,
          highlightsCount: highlights.length
        });
        
        return Object.keys(result).length > 0 ? result : null;
      } else {
        console.log('⚠️ No products found in search results');
      }
    } else {
      console.log('❌ Daraz search API returned non-JSON response');
    }
  } catch (e: any) {
    console.log('❌ Daraz search API failed:', e.message);
  }
  
  return null;
}

/**
 * Get ScraperAPI key from database or environment
 */
async function getScraperApiKey(): Promise<string | null> {
  try {
    const { getSetting } = await import('../models/Settings');
    const dbKey = await getSetting('SCRAPER_API_KEY');
    if (dbKey) return dbKey;
  } catch (e) {
    console.log('⚠️ Could not check database for API key');
  }
  return process.env.SCRAPER_API_KEY || null;
}

/**
 * Extract Amazon product using ScraperAPI (handles JavaScript rendering)
 */
async function extractAmazonViaScraperAPI(url: string, axios: any): Promise<Partial<ProductData> | null> {
  const apiKey = await getScraperApiKey();
  if (!apiKey) {
    console.log('⚠️ SCRAPER_API_KEY not set, falling back to direct fetch');
    return null;
  }

  try {
    console.log('🔄 Using ScraperAPI for Amazon extraction...');
    const scraperUrl = `http://api.scraperapi.com?api_key=${apiKey}&url=${encodeURIComponent(url)}`;
    
    const response = await axios.get(scraperUrl, { timeout: 60000 });
    const cheerio = await import('cheerio');
    const $ = cheerio.load(response.data);

    const result: Partial<ProductData> = {};

    // Extract title
    const title = $('#productTitle').text().trim() || 
                  $('meta[property="og:title"]').attr('content') ||
                  $('h1#title span').text().trim();
    if (title) result.title = title;

    // Extract price
    const priceWhole = $('.a-price-whole').first().text().replace(/[,\.]/g, '').trim();
    const priceFraction = $('.a-price-fraction').first().text().trim();
    if (priceWhole) {
      result.price = priceFraction ? `${priceWhole}.${priceFraction}` : priceWhole;
    }

    // Extract original price
    const originalPrice = $('.a-text-price .a-offscreen').first().text().replace(/[^\d.]/g, '').trim();
    if (originalPrice) result.originalPrice = originalPrice;

    // Extract images
    const images: string[] = [];
    $('#altImages img, #imgTagWrapperId img, #landingImage').each((_i: number, el: any) => {
      let src = $(el).attr('data-old-hires') || $(el).attr('data-a-dynamic-image') || $(el).attr('src');
      if (src && images.length < 6) {
        // Parse dynamic image JSON if present
        if (src.startsWith('{')) {
          try {
            const imgObj = JSON.parse(src);
            src = Object.keys(imgObj)[0];
          } catch (e) {}
        }
        if (src && src.startsWith('http') && !images.includes(src)) {
          images.push(src.replace(/\._.*_\./, '._SL1500_.'));
        }
      }
    });
    if (images.length > 0) result.images = images;

    // Extract brand
    const brand = $('#bylineInfo').text().replace(/Visit the|Store|Brand:/gi, '').trim() ||
                  $('a#bylineInfo').text().trim();
    if (brand) result.brand = brand;

    // Extract description
    const description = $('#productDescription p').text().trim() ||
                       $('#feature-bullets ul').text().trim();
    if (description) result.description = description.substring(0, 1000);

    // Extract highlights
    const highlights: string[] = [];
    $('#feature-bullets li span.a-list-item').each((_i: number, el: any) => {
      const text = $(el).text().trim();
      if (text && !text.includes('Make sure this fits') && highlights.length < 10) {
        highlights.push(text);
      }
    });
    if (highlights.length > 0) result.highlights = highlights;

    // Extract rating
    const rating = $('#acrPopover').attr('title')?.match(/[\d.]+/)?.[0];
    if (rating) result.rating = rating;

    console.log('✅ ScraperAPI extraction complete:', {
      title: result.title ? 'Yes' : 'No',
      price: result.price || 'No',
      images: result.images?.length || 0
    });

    return Object.keys(result).length > 2 ? result : null;
  } catch (error: any) {
    console.log('❌ ScraperAPI extraction failed:', error.message);
    return null;
  }
}

/**
 * Universal product extraction with AI-powered detection
 */
export async function extractUniversalProduct(url: string): Promise<ProductData> {
  const axios = (await import('axios')).default;
  const cheerio = await import('cheerio');

  console.log('🌐 Extracting from URL:', url);

  // Detect website type
  const websiteType = detectWebsiteType(url);
  console.log('🎯 Detected website:', websiteType);

  const productData: ProductData = {
    title: '',
    description: '',
    price: '',
    originalPrice: '',
    images: [],
    reviews: [],
    url,
    success: false
  };

  // Step 0: For Amazon, try ScraperAPI first (handles JS rendering)
  if (websiteType === 'amazon') {
    const amazonData = await extractAmazonViaScraperAPI(url, axios);
    if (amazonData && (amazonData.title || amazonData.price)) {
      console.log('✅ Using ScraperAPI extraction data for Amazon');
      Object.assign(productData, amazonData);
      productData.success = true;
      return productData;
    }
  }

  // Step 0: For Daraz/Lazada, try API extraction FIRST (bypasses blocking)
  let gotDarazApiData = false;
  if (websiteType === 'daraz' || websiteType === 'lazada') {
    const darazApiData = await extractDarazViaApi(url, axios);
    if (darazApiData && (darazApiData.title || darazApiData.price)) {
      console.log('✅ Using Daraz API extraction data');
      Object.assign(productData, darazApiData);
      gotDarazApiData = true;
      // Don't return early - continue to try HTML extraction for more images
    }
  }

  // Build headers based on website type
  const baseHeaders: Record<string, string> = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Cache-Control': 'max-age=0'
  };

  // Amazon-specific headers to avoid bot detection
  if (websiteType === 'amazon') {
    baseHeaders['Accept-Language'] = 'en-IN,en-GB;q=0.9,en-US;q=0.8,en;q=0.7,hi;q=0.6';
    baseHeaders['Sec-Ch-Ua'] = '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"';
    baseHeaders['Sec-Ch-Ua-Mobile'] = '?0';
    baseHeaders['Sec-Ch-Ua-Platform'] = '"Windows"';
    baseHeaders['Sec-Fetch-Site'] = 'none';
    baseHeaders['Sec-Fetch-User'] = '?1';
  }

  // Fetch page with proper headers
  const response = await axios.get(url, {
    headers: baseHeaders,
    timeout: 30000,
    maxRedirects: 10,
    validateStatus: (status) => status < 500
  });

  const html = response.data;
  const $ = cheerio.load(html);

  // Step 0.5: For Daraz/Lazada, also try JSON payload extraction for more images
  if (websiteType === 'daraz' || websiteType === 'lazada') {
    const darazData = extractDarazJsonPayload($, html);
    if (darazData) {
      console.log('✅ Using Daraz JSON extraction data');
      // Fill in missing fields
      if (!productData.title && darazData.title) productData.title = darazData.title;
      if (!productData.description && darazData.description) productData.description = darazData.description;
      if (!productData.price && darazData.price) productData.price = darazData.price;
      if (!productData.originalPrice && darazData.originalPrice) productData.originalPrice = darazData.originalPrice;
      
      // Merge images - add new images from JSON payload
      if (darazData.images && darazData.images.length > 0) {
        const existingImages = new Set(productData.images);
        for (const img of darazData.images) {
          if (!existingImages.has(img) && productData.images.length < 6) {
            productData.images.push(img);
          }
        }
        console.log('📸 Images after merge:', productData.images.length);
      }
      
      if (!productData.brand && darazData.brand) productData.brand = darazData.brand;
      if ((!productData.specifications || Object.keys(productData.specifications).length === 0) && darazData.specifications) {
        productData.specifications = darazData.specifications;
      }
    }
  }

  // Step 1: Try extracting from Schema.org JSON-LD (most reliable for other sites)
  if (!productData.title || !productData.price) {
    const schemaData = extractFromSchema($);
    if (schemaData) {
      // Only fill missing fields
      if (!productData.title && schemaData.title) productData.title = schemaData.title;
      if (!productData.description && schemaData.description) productData.description = schemaData.description;
      if (!productData.price && schemaData.price) productData.price = schemaData.price;
      if (!productData.originalPrice && schemaData.originalPrice) productData.originalPrice = schemaData.originalPrice;
      if (productData.images.length === 0 && schemaData.images) productData.images = schemaData.images;
      if (!productData.brand && schemaData.brand) productData.brand = schemaData.brand;
    }
  }

  // Step 2: Extract data using universal selectors + site-specific optimizations
  if (!productData.title) productData.title = extractTitle($, websiteType);
  if (!productData.description) productData.description = extractDescription($, websiteType);
  if (!productData.price) productData.price = extractPrice($, websiteType);
  if (!productData.originalPrice) productData.originalPrice = extractOriginalPrice($, websiteType);
  if (productData.images.length === 0) productData.images = extractImages($, websiteType);
  if (productData.reviews.length === 0) productData.reviews = extractReviews($, websiteType);
  if (!productData.brand) productData.brand = extractBrand($, websiteType);
  if (!productData.rating) productData.rating = extractRating($, websiteType);
  if (!productData.reviewCount) productData.reviewCount = extractReviewCount($, websiteType);
  
  // Step 2.5: Extract specifications, highlights, and technical details (if not from Daraz JSON)
  if (!productData.highlights || productData.highlights.length === 0) {
    productData.highlights = extractHighlights($, websiteType);
  }
  if (!productData.technicalDetails || productData.technicalDetails.length === 0) {
    productData.technicalDetails = extractTechnicalDetails($, websiteType);
  }
  if (!productData.specifications || Object.keys(productData.specifications).length === 0) {
    productData.specifications = extractSpecifications($, websiteType);
  }

  // Step 3: Fallback to heuristic extraction for missing critical fields
  if (!productData.price) {
    productData.price = extractPriceHeuristic($);
  }
  if (!productData.title) {
    productData.title = extractTitleHeuristic($);
  }
  if (!productData.description) {
    productData.description = extractDescriptionHeuristic($);
  }

  productData.success = !!(productData.title && productData.price);

  console.log('✅ Extraction complete:', {
    title: productData.title,
    price: productData.price,
    originalPrice: productData.originalPrice,
    images: productData.images.length,
    reviews: productData.reviews.length,
    highlights: productData.highlights?.length || 0,
    specs: Object.keys(productData.specifications || {}).length
  });

  return productData;
}

/**
 * Extract data from Schema.org JSON-LD (most reliable method)
 * Production-ready implementation with full nested structure traversal
 */
function extractFromSchema($: any): Partial<ProductData> | null {
  const scripts = $('script[type="application/ld+json"]');
  const asArray = (value: unknown) => Array.isArray(value) ? value : value ? [value] : [];
  const normalizeType = (value: unknown) => asArray(value).map((item: any) => String(item).toLowerCase());

  const parseImage = (image: unknown): string[] => {
    if (!image) return [];
    return asArray(image)
      .map((item: any) => typeof item === 'string' ? item : (item as any)?.url)
      .filter(Boolean)
      .slice(0, 6);
  };

  const extractOfferPrice = (offer: any): { price?: string; originalPrice?: string } => {
    if (!offer) return {};
    const queue = asArray(offer);
    while (queue.length) {
      const current = queue.shift();
      if (!current || typeof current !== 'object') continue;
      if (current.price) {
        return {
          price: String(current.price),
          originalPrice: current.priceSpecification?.price 
            ? String(current.priceSpecification.price) 
            : current.highPrice 
            ? String(current.highPrice) 
            : undefined,
        };
      }
      // Traverse nested offers arrays and priceSpecification (Shopify pattern)
      queue.push(
        ...asArray(current.offers), 
        ...asArray(current.offers?.offers),  // Nested offers.offers
        ...asArray(current.itemOffered),
        ...asArray(current.priceSpecification)
      );
    }
    return {};
  };

  for (const node of scripts.toArray()) {
    const json = $(node).html();
    if (!json) continue;
    let data: unknown;
    try {
      data = JSON.parse(json);
    } catch {
      continue;
    }

    const queue = asArray(data).concat(asArray((data as any)?.['@graph']));

    while (queue.length) {
      const item = queue.shift();
      if (!item || typeof item !== 'object') continue;
      const typeList = normalizeType((item as any)['@type']);
      if (typeList.includes('product')) {
        const product: any = item;
        const { price, originalPrice } = extractOfferPrice(
          product.offers || product.aggregateOffer || product.itemOffered?.offers
        );
        const reviews = asArray(product.review)
          .filter((review: any) => typeof review === 'object')
          .slice(0, 2)
          .map((review: any) => ({
            author: review.author?.name || review.author || 'Anonymous',
            rating: Number(review.reviewRating?.ratingValue) || Number(review.reviewRating?.bestRating) || 5,
            text: (review.reviewBody || review.description || '').toString().slice(0, 280),
            date: review.datePublished || review.dateCreated || '',
          }));

        console.log('✅ Extracted from Schema.org JSON-LD');
        return {
          title: product.name?.toString().slice(0, 200) || '',
          description: product.description?.toString().slice(0, 1200) || '',
          price: price || '',
          originalPrice: originalPrice || '',
          images: parseImage(product.image),
          brand: typeof product.brand === 'string' ? product.brand : product.brand?.name,
          rating: product.aggregateRating?.ratingValue ? String(product.aggregateRating.ratingValue) : undefined,
          reviewCount: product.aggregateRating?.reviewCount ? Number(product.aggregateRating.reviewCount) : undefined,
          reviews,
        };
      }
      queue.push(
        ...asArray((item as any)['@graph']), 
        ...asArray((item as any).itemListElement), 
        ...asArray((item as any).mainEntity)
      );
    }
  }

  return null;
}

/**
 * Heuristically extract price using smart pattern matching
 * Production-ready implementation with robust normalization
 */
function extractPriceHeuristic($: any): string {
  // Comprehensive pattern supporting prefix AND suffix currencies, localized spacing
  const pricePattern = /(?:Rs\.?|₹|INR|NPR|USD|US\$|\$|€|EUR|£|GBP|RM|MYR|₱|PHP|SGD|SG\$|S\$|THB|฿|¥|JPY|CNY|रु|IDR|Rp\.?|VND|₫|BDT|৳|₦|NGN|₨|₵|GHS|CA\$|CAD|A\$|AUD|NZ\$|NZD|CHF|₺|TRY|SAR|ر\.س|QAR|ر\.ق|AED|د\.إ|LKR|ரூ)\s*(\d+(?:[,.\s]\d+)*)/gi;
  const text = $('body').text();
  const matches = text.matchAll(pricePattern);
  const prices: Record<string, number> = {};

  for (const match of matches) {
    const rawAmount = match[1];
    if (!rawAmount) continue;

    const sanitized = rawAmount.replace(/[^0-9.,\s]/g, '').trim();
    if (!sanitized) continue;

    let normalized = sanitized.replace(/\s+/g, '');
    
    // Smart decimal/comma detection
    if (normalized.includes('.') && normalized.includes(',')) {
      // Both present - last one wins as decimal separator
      normalized = normalized.lastIndexOf('.') > normalized.lastIndexOf(',')
        ? normalized.replace(/,/g, '')
        : normalized.replace(/\./g, '').replace(',', '.');
    } else if (normalized.includes(',')) {
      // Only comma - check if it's decimal or thousands separator
      const parts = normalized.split(',');
      normalized = parts[parts.length - 1].length === 3
        ? normalized.replace(/,/g, '')  // Thousands separator
        : normalized.replace(',', '.');  // Decimal separator
    }

    const numeric = Number.parseFloat(normalized);
    if (Number.isNaN(numeric)) continue;

    const key = Number.isInteger(numeric) ? String(numeric) : numeric.toFixed(2).replace(/\.00$/, '');
    prices[key] = (prices[key] || 0) + 1;
  }

  const sorted = Object.entries(prices).sort((a, b) => b[1] - a[1]);
  return sorted.length > 0 ? sorted[0][0] : '';
}

/**
 * Heuristically extract title using semantic scoring
 */
function extractTitleHeuristic($: any): string {
  // Strategy: Find the largest, most prominent heading
  const candidates: Array<{ text: string; score: number }> = [];
  
  // Check h1 tags (highest priority)
  $('h1').each((_i: number, elem: any) => {
    const text = $(elem).text().trim();
    if (text && text.length > 10 && text.length < 200) {
      candidates.push({ text, score: 100 });
    }
  });
  
  // Check page title
  const titleText = $('title').text().trim();
  if (titleText && titleText.length > 10) {
    candidates.push({ 
      text: titleText
        .replace(/\s*[\|\-]\s*.*$/, '') // Remove site name suffix
        .trim(),
      score: 80 
    });
  }
  
  // Check h2 tags (medium priority)
  $('h2').first().each((_i: number, elem: any) => {
    const text = $(elem).text().trim();
    if (text && text.length > 10 && text.length < 200) {
      candidates.push({ text, score: 60 });
    }
  });
  
  // Return the highest scored candidate
  if (candidates.length > 0) {
    candidates.sort((a, b) => b.score - a.score);
    return candidates[0].text.substring(0, 200);
  }
  
  return '';
}

/**
 * Heuristically extract description using content analysis
 */
function extractDescriptionHeuristic($: any): string {
  // Strategy: Find the longest paragraph-like content near the product area
  let longestText = '';
  
  // Look for common description containers
  const containerSelectors = ['article', 'main', '[role="main"]', '#content', '.content', '.product'];
  
  for (const selector of containerSelectors) {
    $(selector).find('p, div').each((_i: number, elem: any) => {
      const text = $(elem).text().trim();
      if (text.length > longestText.length && text.length > 50 && text.length < 2000) {
        longestText = text;
      }
    });
    
    if (longestText) break;
  }
  
  if (longestText) {
    return longestText
      .replace(/[\n\r\t]/g, ' ')
      .replace(/\s+/g, ' ')
      .substring(0, 1000);
  }
  
  return '';
}

/**
 * Detect website type from URL
 */
function detectWebsiteType(url: string): string {
  if (url.includes('amazon') || url.includes('amzn.in') || url.includes('amzn.to')) return 'amazon';
  if (url.includes('flipkart') || url.includes('fkrt.it')) return 'flipkart';
  if (url.includes('daraz')) return 'daraz';
  if (url.includes('snapdeal')) return 'snapdeal';
  if (url.includes('shopee')) return 'shopee';
  if (url.includes('lazada')) return 'lazada';
  if (url.includes('myntra')) return 'myntra';
  if (url.includes('ajio')) return 'ajio';
  return 'generic';
}

/**
 * Extract title with AI-powered fallbacks
 */
function extractTitle($: any, websiteType: string): string {
  const selectors: Array<{ selector: string; attr?: string; method?: string }> = [
    // Meta tags (universal)
    { selector: 'meta[property="og:title"]', attr: 'content' },
    { selector: 'meta[name="title"]', attr: 'content' },
    { selector: 'meta[property="twitter:title"]', attr: 'content' },
    
    // Amazon
    { selector: '#productTitle', method: 'text' },
    { selector: '#title', method: 'text' },
    { selector: '.product-title', method: 'text' },
    
    // Flipkart
    { selector: '.B_NuCI', method: 'text' },
    { selector: 'span.VU-ZEz', method: 'text' },
    { selector: 'h1.yhB1nd', method: 'text' },
    
    // Daraz/Lazada
    { selector: 'h1[data-spm="anchor_title"]', method: 'text' },
    { selector: '.pdp-mod-product-badge-title', method: 'text' },
    
    // Shopee
    { selector: '._44qnta', method: 'text' },
    { selector: '.WBVL_7', method: 'text' },
    
    // Myntra
    { selector: '.pdp-title', method: 'text' },
    { selector: '.pdp-name', method: 'text' },
    
    // Generic
    { selector: 'h1[itemprop="name"]', method: 'text' },
    { selector: '[data-testid="product-title"]', method: 'text' },
    { selector: 'h1', method: 'text' }
  ];

  for (const { selector, attr, method } of selectors) {
    let value = '';
    if (attr) {
      value = $(selector).attr(attr);
    } else if (method === 'text') {
      value = $(selector).text();
    }
    
    if (value) {
      return value.trim()
        .replace(/\s*\|\s*Amazon.*$/i, '')
        .replace(/\s*\|\s*Flipkart.*$/i, '')
        .replace(/\s*\|\s*Daraz.*$/i, '')
        .replace(/\s*-\s*Buy.*$/i, '')
        .substring(0, 200);
    }
  }

  return '';
}

/**
 * Extract description with complete details
 */
function extractDescription($: any, websiteType: string): string {
  const selectors: Array<{ selector: string; attr?: string; method?: string }> = [
    // Meta tags
    { selector: 'meta[property="og:description"]', attr: 'content' },
    { selector: 'meta[name="description"]', attr: 'content' },
    
    // Amazon
    { selector: '#feature-bullets', method: 'text' },
    { selector: '#productDescription', method: 'text' },
    { selector: '.a-unordered-list.a-vertical', method: 'text' },
    
    // Flipkart
    { selector: '._1mXcCf', method: 'text' },
    { selector: '.Qu-h4r', method: 'text' },
    
    // Daraz
    { selector: '.pdp-product-desc', method: 'text' },
    { selector: '.pdp-mod-product-feature', method: 'text' },
    
    // Generic
    { selector: '[itemprop="description"]', method: 'text' },
    { selector: '.product-description', method: 'text' },
    { selector: '.description', method: 'text' }
  ];

  for (const { selector, attr, method } of selectors) {
    let value = '';
    if (attr) {
      value = $(selector).attr(attr);
    } else if (method === 'text') {
      value = $(selector).text();
    }
    
    if (value) {
      return value.trim()
        .replace(/[\n\r\t]/g, ' ')
        .replace(/\s+/g, ' ')
        .substring(0, 1000);
    }
  }

  return '';
}

/**
 * Extract and normalize price value from text
 * Handles various formats: Rs 50,000 | Rs.50000 | 50,000.00 | NPR 50000
 */
function normalizePrice(text: string): string {
  if (!text) return '';
  
  // Remove all currency symbols and text
  let cleaned = text
    .replace(/₹|\$|€|£|¥|₱|रु|Rs\.?|NPR|USD|INR|PHP|RM|MYR|SGD|THB|฿/gi, '')
    .replace(/[,\s]/g, '')
    .trim();
  
  // Extract the first valid number (avoid picking up small numbers like "1" from dates)
  const matches = cleaned.match(/(\d{3,}(?:\.\d{1,2})?)/g);
  if (matches && matches.length > 0) {
    // Return the largest number found (most likely the actual price)
    const prices = matches.map(m => parseFloat(m)).filter(p => p > 10);
    if (prices.length > 0) {
      return String(Math.round(Math.min(...prices))); // Return smallest valid price (sale price)
    }
  }
  
  // Fallback: extract any number
  const simpleMatch = cleaned.match(/\d+\.?\d*/);
  if (simpleMatch) {
    const price = parseFloat(simpleMatch[0]);
    if (price > 10) return String(Math.round(price));
  }
  
  return '';
}

/**
 * Extract price intelligently
 */
function extractPrice($: any, websiteType: string): string {
  console.log('🔍 Extracting price for website type:', websiteType);
  
  const selectors: Array<{ selector: string; attr?: string; method?: string }> = [
    // Meta tags (highest priority)
    { selector: 'meta[property="og:price:amount"]', attr: 'content' },
    { selector: 'meta[property="product:price:amount"]', attr: 'content' },
    
    // Daraz/Lazada specific (improved selectors)
    { selector: 'span.pdp-price_type_normal', method: 'text' },
    { selector: '.pdp-product-price span.pdp-price', method: 'text' },
    { selector: '.pdp-price_color_orange', method: 'text' },
    { selector: 'span.pdp-price', method: 'text' },
    { selector: '.pdp-mod-product-price .pdp-price', method: 'text' },
    
    // Amazon
    { selector: '.a-price-whole', method: 'text' },
    { selector: '#priceblock_ourprice', method: 'text' },
    { selector: '#priceblock_dealprice', method: 'text' },
    { selector: '.a-price .a-offscreen', method: 'text' },
    { selector: '#corePrice_feature_div .a-price .a-offscreen', method: 'text' },
    
    // Flipkart
    { selector: '._30jeq3', method: 'text' },
    { selector: '._1vC4OE', method: 'text' },
    { selector: 'div._30jeq3._16Jk6d', method: 'text' },
    
    // Shopee
    { selector: '._3n5NQx', method: 'text' },
    { selector: '._1w9jLI', method: 'text' },
    
    // Myntra
    { selector: '.pdp-price strong', method: 'text' },
    { selector: '.pdp-discountedPrice', method: 'text' },
    
    // Generic fallbacks
    { selector: '[itemprop="price"]', attr: 'content' },
    { selector: '.price', method: 'text' },
    { selector: '.product-price', method: 'text' },
    { selector: '.current-price', method: 'text' },
    { selector: '.sale-price', method: 'text' }
  ];

  for (const { selector, attr, method } of selectors) {
    let value = '';
    try {
      if (attr) {
        value = $(selector).first().attr(attr) || '';
      } else if (method === 'text') {
        value = $(selector).first().text() || '';
      }
    } catch (e) {
      continue;
    }
    
    if (value) {
      const price = normalizePrice(value);
      if (price && parseInt(price) > 10) {
        console.log(`✅ Price found with selector "${selector}":`, price);
        return price;
      }
    }
  }

  console.log('⚠️ No price found from selectors, will try heuristic');
  return '';
}

/**
 * Extract original price (before discount)
 */
function extractOriginalPrice($: any, websiteType: string): string {
  console.log('🔍 Extracting original price for website type:', websiteType);
  
  const selectors: Array<{ selector: string; attr?: string; method?: string }> = [
    // Daraz/Lazada specific (improved selectors)
    { selector: 'span.pdp-price_type_deleted', method: 'text' },
    { selector: '.pdp-price_type_deleted', method: 'text' },
    { selector: '.origin-price', method: 'text' },
    { selector: '.pdp-product-price del', method: 'text' },
    { selector: '.pdp-price_color_lightgray', method: 'text' },
    
    // Amazon
    { selector: '.a-text-price .a-offscreen', method: 'text' },
    { selector: '#priceblock_saleprice', method: 'text' },
    { selector: '.a-price.a-text-price .a-offscreen', method: 'text' },
    { selector: '#listPrice', method: 'text' },
    { selector: '.basisPrice .a-offscreen', method: 'text' },
    
    // Flipkart
    { selector: '._3I9_wc', method: 'text' },
    { selector: '._2V1j0C', method: 'text' },
    { selector: 'div._3I9_wc._2p6lqe', method: 'text' },
    
    // Shopee
    { selector: '.shopee-svg-icon~span del', method: 'text' },
    
    // Generic
    { selector: '.original-price', method: 'text' },
    { selector: '.was-price', method: 'text' },
    { selector: '.list-price', method: 'text' },
    { selector: '.mrp', method: 'text' },
    { selector: 'del', method: 'text' },
    { selector: 's', method: 'text' }
  ];

  for (const { selector, attr, method } of selectors) {
    let value = '';
    try {
      if (attr) {
        value = $(selector).first().attr(attr) || '';
      } else if (method === 'text') {
        value = $(selector).first().text() || '';
      }
    } catch (e) {
      continue;
    }
    
    if (value) {
      const price = normalizePrice(value);
      if (price && parseInt(price) > 10) {
        console.log(`✅ Original price found with selector "${selector}":`, price);
        return price;
      }
    }
  }

  console.log('⚠️ No original price found');
  return '';
}

/**
 * Extract product images
 */
function extractImages($: any, websiteType: string): string[] {
  const images: string[] = [];

  // Try meta image first
  const ogImage = $('meta[property="og:image"]').attr('content');
  if (ogImage) images.push(ogImage);

  const selectors = [
    '#landingImage',
    '#imgTagWrapperId img',
    '.a-dynamic-image',
    '._396cs4',  // Flipkart
    '.item-gallery-slider img',  // Daraz
    '[data-test="product-image"]',
    '.product-image img',
    '[itemprop="image"]'
  ];

  selectors.forEach(selector => {
    $(selector).each((_i: number, elem: any) => {
      const src = $(elem).attr('src') || $(elem).attr('data-src') || $(elem).attr('data-original');
      if (src && images.length < 5) {
        const cleanSrc = src.split('?')[0]; // Remove query params
        if (!images.includes(cleanSrc)) {
          images.push(cleanSrc);
        }
      }
    });
  });

  return images;
}

/**
 * Extract 1-2 REAL customer reviews
 */
function extractReviews($: any, websiteType: string): Array<{ author: string; rating: number; text: string; date: string }> {
  const reviews: Array<{ author: string; rating: number; text: string; date: string }> = [];

  if (websiteType === 'amazon') {
    // Amazon reviews
    $('.review').slice(0, 2).each((_i: number, elem: any) => {
      const author = $(elem).find('.a-profile-name').text().trim();
      const ratingText = $(elem).find('.a-icon-alt').text().trim();
      const rating = parseFloat(ratingText) || 5;
      const text = $(elem).find('.review-text-content').text().trim();
      const date = $(elem).find('.review-date').text().trim();
      
      if (author && text) {
        reviews.push({ author, rating, text: text.substring(0, 200), date });
      }
    });
  } else if (websiteType === 'flipkart') {
    // Flipkart reviews
    $('._1PBCrt').slice(0, 2).each((_i: number, elem: any) => {
      const author = $(elem).find('._2V5EHH').text().trim();
      const rating = parseFloat($(elem).find('._3LWZlK').text().trim()) || 5;
      const text = $(elem).find('div.t-ZTKy').text().trim();
      const date = $(elem).find('._3ciYPb').text().trim();
      
      if (author && text) {
        reviews.push({ author, rating, text: text.substring(0, 200), date });
      }
    });
  } else if (websiteType === 'daraz') {
    // Daraz reviews
    $('.item').slice(0, 2).each((_i: number, elem: any) => {
      const author = $(elem).find('.name').text().trim() || $(elem).find('.reviewer').text().trim();
      const rating = parseInt($(elem).find('.star').attr('class')?.match(/star-(\d)/)?.[1] || '5');
      const text = $(elem).find('.content').text().trim() || $(elem).find('.review-text').text().trim();
      const date = $(elem).find('.date').text().trim() || $(elem).find('.review-date').text().trim();
      
      if (author && text) {
        reviews.push({ author, rating, text: text.substring(0, 200), date });
      }
    });
  }

  // Generic review extraction as fallback
  if (reviews.length === 0) {
    $('.review, [itemprop="review"]').slice(0, 2).each((_i: number, elem: any) => {
      const author = $(elem).find('[itemprop="author"], .author, .reviewer').text().trim();
      const ratingElem = $(elem).find('[itemprop="ratingValue"]');
      const rating = parseFloat(ratingElem.attr('content') || ratingElem.text()) || 5;
      const text = $(elem).find('[itemprop="reviewBody"], .review-text, .comment').text().trim();
      const date = $(elem).find('[itemprop="datePublished"], .date, .review-date').text().trim();
      
      if (author && text) {
        reviews.push({ author, rating, text: text.substring(0, 200), date });
      }
    });
  }

  return reviews;
}

/**
 * Extract brand
 */
function extractBrand($: any, websiteType: string): string {
  const selectors: Array<{ selector: string; attr?: string; method?: string }> = [
    { selector: 'meta[property="product:brand"]', attr: 'content' },
    { selector: '#bylineInfo', method: 'text' },  // Amazon
    { selector: '._2WkVRV', method: 'text' },  // Flipkart
    { selector: '.pdp-product-brand', method: 'text' },  // Daraz
    { selector: '[itemprop="brand"]', attr: 'content' },
    { selector: '.brand', method: 'text' }
  ];

  for (const { selector, attr, method } of selectors) {
    let value = '';
    if (attr) {
      value = $(selector).attr(attr);
    } else if (method === 'text') {
      value = $(selector).text();
    }
    
    if (value) {
      return value.trim().replace(/^(Visit the|Brand:)\s*/i, '').substring(0, 50);
    }
  }

  return '';
}

/**
 * Extract rating
 */
function extractRating($: any, websiteType: string): string {
  const selectors: Array<{ selector: string; attr?: string; method?: string }> = [
    { selector: 'meta[property="product:rating"]', attr: 'content' },
    { selector: '#acrPopover', attr: 'title' },  // Amazon
    { selector: '._3LWZlK', method: 'text' },  // Flipkart
    { selector: '.pdp-review-summary .score', method: 'text' },  // Daraz
    { selector: '[itemprop="ratingValue"]', attr: 'content' },
    { selector: '.rating', method: 'text' }
  ];

  for (const { selector, attr, method } of selectors) {
    let value = '';
    if (attr) {
      value = $(selector).attr(attr);
    } else if (method === 'text') {
      value = $(selector).text();
    }
    
    if (value) {
      const ratingMatch = value.match(/[\d.]+/);
      if (ratingMatch) {
        return ratingMatch[0];
      }
    }
  }

  return '';
}

/**
 * Extract review count
 */
function extractReviewCount($: any, websiteType: string): number {
  const selectors: Array<{ selector: string; attr?: string; method?: string }> = [
    { selector: '#acrCustomerReviewText', method: 'text' },  // Amazon
    { selector: '._2_R_DZ', method: 'text' },  // Flipkart
    { selector: '.pdp-review-summary .count', method: 'text' },  // Daraz
    { selector: '[itemprop="reviewCount"]', attr: 'content' },
    { selector: '.review-count', method: 'text' }
  ];

  for (const { selector, attr, method } of selectors) {
    let value = '';
    if (attr) {
      value = $(selector).attr(attr);
    } else if (method === 'text') {
      value = $(selector).text();
    }
    
    if (value) {
      const countMatch = value.match(/[\d,]+/);
      if (countMatch) {
        return parseInt(countMatch[0].replace(/,/g, ''));
      }
    }
  }

  return 0;
}

/**
 * Extract product highlights/features (bullet points)
 * Works with Amazon, Flipkart, Daraz, and other e-commerce sites
 */
function extractHighlights($: any, websiteType: string): string[] {
  const highlights: string[] = [];
  
  // Amazon - Feature bullets
  $('#feature-bullets ul li span.a-list-item').each((_: any, el: any) => {
    const text = $(el).text().trim();
    if (text && text.length > 10 && !text.includes('See more')) {
      highlights.push(text);
    }
  });
  
  // Amazon - alternative selector
  if (highlights.length === 0) {
    $('#featurebullets_feature_div li span').each((_: any, el: any) => {
      const text = $(el).text().trim();
      if (text && text.length > 10) {
        highlights.push(text);
      }
    });
  }
  
  // Flipkart - Features
  if (highlights.length === 0) {
    $('._1AtVbE ul li').each((_: any, el: any) => {
      const text = $(el).text().trim();
      if (text) highlights.push(text);
    });
  }
  
  // Daraz - Features
  if (highlights.length === 0) {
    $('.pdp-product-highlights li').each((_: any, el: any) => {
      const text = $(el).text().trim();
      if (text) highlights.push(text);
    });
  }
  
  // Generic - Look for any feature list
  if (highlights.length === 0) {
    $('[class*="feature"] ul li, [class*="highlight"] ul li').each((_: any, el: any) => {
      const text = $(el).text().trim();
      if (text && text.length > 10) {
        highlights.push(text);
      }
    });
  }
  
  console.log(`📋 Extracted ${highlights.length} highlights`);
  return highlights.slice(0, 10); // Limit to 10 highlights
}

/**
 * Extract technical details/specifications
 * Parses tables and structured data
 */
function extractTechnicalDetails($: any, websiteType: string): string[] {
  const details: string[] = [];
  
  // Amazon - Product details table
  $('#productDetails_techSpec_section_1 tr, #productDetails_detailBullets_sections1 tr').each((_: any, el: any) => {
    const th = $(el).find('th').text().trim();
    const td = $(el).find('td').text().trim();
    if (th && td) {
      details.push(`${th}: ${td}`);
    }
  });
  
  // Amazon - Detail bullets
  if (details.length === 0) {
    $('#detailBullets_feature_div li').each((_: any, el: any) => {
      const text = $(el).text().trim();
      if (text && !text.includes('Customer Reviews') && !text.includes('Best Sellers Rank')) {
        const cleaned = text.replace(/\s+/g, ' ').substring(0, 200);
        if (cleaned.includes(':')) {
          details.push(cleaned);
        }
      }
    });
  }
  
  // Flipkart - Specifications table
  if (details.length === 0) {
    $('._3dtsli table tr').each((_: any, el: any) => {
      const cells = $(el).find('td, th');
      if (cells.length >= 2) {
        const key = $(cells[0]).text().trim();
        const value = $(cells[1]).text().trim();
        if (key && value) {
          details.push(`${key}: ${value}`);
        }
      }
    });
  }
  
  // Daraz - Specifications
  if (details.length === 0) {
    $('.pdp-mod-specification .pdp-general-features li').each((_: any, el: any) => {
      const label = $(el).find('.key-li').text().trim();
      const value = $(el).find('.val-li').text().trim();
      if (label && value) {
        details.push(`${label}: ${value}`);
      }
    });
  }
  
  // Generic - Look for any spec table
  if (details.length === 0) {
    $('[class*="spec"] table tr, [class*="detail"] table tr').each((_: any, el: any) => {
      const cells = $(el).find('td, th');
      if (cells.length >= 2) {
        const key = $(cells[0]).text().trim();
        const value = $(cells[1]).text().trim();
        if (key && value && key.length < 100) {
          details.push(`${key}: ${value}`);
        }
      }
    });
  }
  
  console.log(`🔧 Extracted ${details.length} technical details`);
  return details.slice(0, 20); // Limit to 20 details
}

/**
 * Extract specifications as key-value pairs
 * More structured than technical details
 */
function extractSpecifications($: any, websiteType: string): Record<string, string> {
  const specs: Record<string, string> = {};
  
  // Amazon - Technical specifications
  $('#productDetails_techSpec_section_1 tr').each((_: any, el: any) => {
    const th = $(el).find('th').text().trim();
    const td = $(el).find('td').text().trim();
    if (th && td) {
      const key = th.replace(/\s+/g, ' ').toLowerCase().replace(/[^a-z0-9\s]/g, '').trim();
      specs[key] = td.replace(/\s+/g, ' ').substring(0, 200);
    }
  });
  
  // Amazon - Product overview
  if (Object.keys(specs).length === 0) {
    $('#productOverview_feature_div tr').each((_: any, el: any) => {
      const cells = $(el).find('td');
      if (cells.length >= 2) {
        const key = $(cells[0]).text().trim().toLowerCase().replace(/[^a-z0-9\s]/g, '').trim();
        const value = $(cells[1]).text().trim();
        if (key && value) {
          specs[key] = value.replace(/\s+/g, ' ').substring(0, 200);
        }
      }
    });
  }
  
  // Flipkart - Specifications
  if (Object.keys(specs).length === 0) {
    $('._1UhVsV table tr').each((_: any, el: any) => {
      const cells = $(el).find('td');
      if (cells.length >= 2) {
        const key = $(cells[0]).text().trim().toLowerCase().replace(/[^a-z0-9\s]/g, '').trim();
        const value = $(cells[1]).text().trim();
        if (key && value) {
          specs[key] = value;
        }
      }
    });
  }
  
  // Daraz - Specifications (multiple selectors for better coverage)
  if (Object.keys(specs).length === 0) {
    // Primary Daraz selector
    $('.pdp-mod-specification .key-li').each((_: any, el: any) => {
      const key = $(el).text().trim().toLowerCase().replace(/[^a-z0-9\s]/g, '').trim();
      const value = $(el).siblings('.val-li').text().trim();
      if (key && value) {
        specs[key] = value;
      }
    });
    
    // Alternative Daraz selectors
    if (Object.keys(specs).length === 0) {
      $('.specification-keys li').each((_: any, el: any) => {
        const key = $(el).text().trim().toLowerCase().replace(/[^a-z0-9\s]/g, '').trim();
        const index = $(el).index();
        const value = $(el).closest('.specification').find('.specification-values li').eq(index).text().trim();
        if (key && value) {
          specs[key] = value;
        }
      });
    }
    
    // Try table format
    if (Object.keys(specs).length === 0) {
      $('.pdp-product-detail table tr').each((_: any, el: any) => {
        const cells = $(el).find('td');
        if (cells.length >= 2) {
          const key = $(cells[0]).text().trim().toLowerCase().replace(/[^a-z0-9\s]/g, '').trim();
          const value = $(cells[1]).text().trim();
          if (key && value) {
            specs[key] = value;
          }
        }
      });
    }
  }
  
  // Map generic spec keys to iPhone-specific field names
  const mappedSpecs = mapToiPhoneSpecFields(specs);
  
  console.log(`📊 Extracted ${Object.keys(mappedSpecs).length} specifications`);
  return mappedSpecs;
}

/**
 * Map generic extracted specs to iPhone-specific field names
 * Normalizes various naming conventions to our standardized schema
 */
function mapToiPhoneSpecFields(specs: Record<string, string>): Record<string, string> {
  const mapped: Record<string, string> = {};
  
  // Key mapping - common variations to our standard field names
  const keyMappings: Record<string, string[]> = {
    display: ['display', 'display type', 'screen type', 'panel type', 'screen'],
    size: ['screen size', 'display size', 'size', 'screen', 'diagonal'],
    resolution: ['resolution', 'screen resolution', 'display resolution', 'pixels'],
    chip: ['chip', 'chipset', 'processor', 'cpu', 'soc', 'a18', 'a17', 'a16', 'a15'],
    cpu: ['cpu', 'processor cores', 'cpu cores', 'core'],
    gpu: ['gpu', 'graphics', 'graphics processor'],
    neuralEngine: ['neural engine', 'neural', 'ai chip', 'npu'],
    camera: ['camera', 'main camera', 'rear camera', 'back camera', 'camera system'],
    storage: ['storage', 'internal storage', 'internal memory', 'rom', 'memory'],
    ram: ['ram', 'memory', 'system memory'],
    color: ['color', 'colour', 'body color', 'body colour'],
    waterResistance: ['water resistance', 'water resistant', 'ip rating', 'ip68', 'ip67'],
    operatingSystem: ['operating system', 'os', 'ios', 'system'],
    battery: ['battery', 'battery capacity', 'battery type'],
    weight: ['weight', 'product weight'],
    dimensions: ['dimensions', 'size dimensions', 'product dimensions']
  };
  
  // First, copy all specs
  Object.assign(mapped, specs);
  
  // Then, normalize keys to our standard names
  for (const [standardKey, variations] of Object.entries(keyMappings)) {
    for (const variation of variations) {
      // Check if any spec key contains this variation
      for (const [specKey, specValue] of Object.entries(specs)) {
        if (specKey.includes(variation) && specValue && !mapped[standardKey]) {
          mapped[standardKey] = specValue;
        }
      }
    }
  }
  
  return mapped;
}
