// In-memory storage for when MongoDB is not available
// This will persist data during the session but reset on server restart

interface InMemoryData {
  products: any[];
  scripts: any[];
  scriptProducts: any[];
  settings: { script: string };
  categories: any[];
}

let inMemoryData: InMemoryData = {
  products: [],
  scripts: [
    {
      _id: '1',
      name: 'Default Script',
      description: 'Default product display script',
      isActive: true,
      createdAt: new Date().toISOString()
    }
  ],
  scriptProducts: [],
  settings: { script: 'none' },
  categories: [
    { _id: '1', name: 'Electronics', icon: 'smartphone', color: 'bg-blue-100 text-blue-600' },
    { _id: '2', name: 'Fashion', icon: 'shirt', color: 'bg-purple-100 text-purple-600' },
    { _id: '3', name: 'Beauty', icon: 'sparkles', color: 'bg-pink-100 text-pink-600' },
    { _id: '4', name: 'Home & Garden', icon: 'home', color: 'bg-green-100 text-green-600' }
  ]
};

export class InMemoryPersistence {
  static addProduct(product: any) {
    const newProduct = {
      _id: Date.now().toString(),
      ...product,
      slug: product.title?.toLowerCase().replace(/[^\w\s-]/g, '').replace(/\s+/g, '-'),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    inMemoryData.products.push(newProduct);
    return newProduct;
  }

  static addScript(script: any) {
    const newScript = {
      _id: Date.now().toString(),
      ...script,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    inMemoryData.scripts.push(newScript);
    return newScript;
  }

  static addScriptProduct(scriptProduct: any) {
    const newScriptProduct = {
      _id: Date.now().toString(),
      ...scriptProduct,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    inMemoryData.scriptProducts.push(newScriptProduct);
    return newScriptProduct;
  }

  static activateScript(scriptId: string) {
    // Deactivate all scripts
    inMemoryData.scripts.forEach(script => {
      script.isActive = false;
    });
    
    // Activate selected script
    const script = inMemoryData.scripts.find(s => s._id === scriptId);
    if (script) {
      script.isActive = true;
    }
    
    // Update settings
    inMemoryData.settings.script = scriptId;
  }

  static updateSettings(settings: { script: string }) {
    inMemoryData.settings = { ...inMemoryData.settings, ...settings };
    return inMemoryData.settings;
  }

  static getProducts() {
    return inMemoryData.products;
  }

  static getScripts() {
    return inMemoryData.scripts;
  }

  static getScriptProducts(scriptId: string) {
    return inMemoryData.scriptProducts.filter(sp => sp.scriptId === scriptId);
  }

  static getSettings() {
    return inMemoryData.settings;
  }

  static getCategories() {
    return inMemoryData.categories;
  }

  static getFlashSaleProducts() {
    return inMemoryData.products.filter(p => p.isFlashSale);
  }

  static getProduct(id: string) {
    return inMemoryData.products.find(p => p._id === id);
  }

  static getProductBySlug(slug: string) {
    return inMemoryData.products.find(p => p.slug === slug);
  }

  static searchProducts(query: string) {
    return inMemoryData.products.filter(p => 
      p.title?.toLowerCase().includes(query.toLowerCase())
    );
  }

  static getProductsByCategory(category: string) {
    return inMemoryData.products.filter(p => p.category === category);
  }

  static getScript(id: string) {
    return inMemoryData.scripts.find(s => s._id === id);
  }

  static removeScriptProduct(scriptProductId: string) {
    inMemoryData.scriptProducts = inMemoryData.scriptProducts.filter(
      sp => sp._id !== scriptProductId
    );
  }

  static updateScriptProduct(id: string, updates: any) {
    const scriptProduct = inMemoryData.scriptProducts.find(sp => sp._id === id);
    if (scriptProduct) {
      Object.assign(scriptProduct, updates);
      return scriptProduct;
    }
    return null;
  }
}