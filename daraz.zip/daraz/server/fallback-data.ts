// Fallback data when MongoDB is not available
export const fallbackProducts = [
  {
    _id: '1',
    title: 'Premium Wireless Headphones',
    slug: 'premium-wireless-headphones',
    price: 'Rs. 2,999',
    originalPrice: 'Rs. 4,999',
    discount: 40,
    category: 'Electronics',
    imageUrl: 'https://res.cloudinary.com/duscymcfc/image/upload/v1751697300/0e32bef6f90df0f3653c998543e656b0.png',
    rating: '4.5',
    reviewCount: 156,
    isFlashSale: true,
    sold: 89,
    stock: 25
  },
  {
    _id: '2', 
    title: 'Bluetooth Speaker',
    slug: 'bluetooth-speaker',
    price: 'Rs. 1,499',
    originalPrice: 'Rs. 2,499',
    discount: 40,
    category: 'Electronics',
    imageUrl: 'https://res.cloudinary.com/duscymcfc/image/upload/v1751697300/cd60cdd52e292a87479ad57841833ab0.jpg',
    rating: '4.2',
    reviewCount: 89,
    isFlashSale: true,
    sold: 67,
    stock: 15
  }
];

export const fallbackCategories = [
  { _id: '1', name: 'Electronics', icon: 'smartphone', color: 'bg-blue-100 text-blue-600' },
  { _id: '2', name: 'Fashion', icon: 'shirt', color: 'bg-purple-100 text-purple-600' },
  { _id: '3', name: 'Beauty', icon: 'sparkles', color: 'bg-pink-100 text-pink-600' },
  { _id: '4', name: 'Home & Garden', icon: 'home', color: 'bg-green-100 text-green-600' }
];

export const fallbackScripts = [
  {
    _id: '1',
    name: 'Default Script',
    description: 'Default product display script',
    isActive: true,
    createdAt: new Date().toISOString()
  }
];

export const fallbackSettings = { script: 'none' };