import fs from 'fs';
import path from 'path';

const LOG_FILE = path.join(process.cwd(), 'logs.txt');
const MAX_LOG_SIZE = 5 * 1024 * 1024; // 5MB max file size

function getTimestamp(): string {
  return new Date().toISOString();
}

function rotateLogIfNeeded(): void {
  try {
    if (fs.existsSync(LOG_FILE)) {
      const stats = fs.statSync(LOG_FILE);
      if (stats.size > MAX_LOG_SIZE) {
        // Rename old log file
        const backupFile = LOG_FILE.replace('.txt', `.${Date.now()}.txt`);
        fs.renameSync(LOG_FILE, backupFile);
      }
    }
  } catch (error) {
    // Ignore rotation errors
  }
}

function writeToFile(message: string): void {
  try {
    rotateLogIfNeeded();
    fs.appendFileSync(LOG_FILE, message + '\n');
  } catch (error) {
    // Fallback to console if file write fails
  }
}

export function log(...args: any[]): void {
  const timestamp = getTimestamp();
  const message = args.map(arg => 
    typeof arg === 'object' ? JSON.stringify(arg) : String(arg)
  ).join(' ');
  
  const logLine = `[${timestamp}] ${message}`;
  console.log(logLine);
  writeToFile(logLine);
}

export function error(...args: any[]): void {
  const timestamp = getTimestamp();
  const message = args.map(arg => 
    typeof arg === 'object' ? JSON.stringify(arg) : String(arg)
  ).join(' ');
  
  const logLine = `[${timestamp}] ERROR: ${message}`;
  console.error(logLine);
  writeToFile(logLine);
}

export function info(...args: any[]): void {
  log('INFO:', ...args);
}

export function warn(...args: any[]): void {
  const timestamp = getTimestamp();
  const message = args.map(arg => 
    typeof arg === 'object' ? JSON.stringify(arg) : String(arg)
  ).join(' ');
  
  const logLine = `[${timestamp}] WARN: ${message}`;
  console.warn(logLine);
  writeToFile(logLine);
}

export default { log, error, info, warn };
