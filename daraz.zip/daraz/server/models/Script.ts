import mongoose from 'mongoose';

const ScriptSchema = new mongoose.Schema({
  // Basic Information
  name: { 
    type: String, 
    required: true,
    trim: true,
    index: true
  },
  description: { 
    type: String,
    default: ''
  },
  
  // Categorization & Organization
  category: { 
    type: String,
    enum: ['iPhone', 'Android', 'Accessories', 'Electronics', 'Fashion'],
    default: 'iPhone',
    index: true
  },
  tags: [{ 
    type: String,
    trim: true
  }],
  
  // Status & Visibility
  status: {
    type: String,
    enum: ['active', 'inactive', 'draft', 'archived'],
    default: 'draft',
    index: true
  },
  isActive: { 
    type: Boolean, 
    default: false,
    index: true
  },
  visibility: {
    type: String,
    enum: ['public', 'private', 'scheduled'],
    default: 'private'
  },
  
  // Priority & Ordering
  priority: {
    type: Number,
    default: 0,
    index: true
  },
  displayOrder: {
    type: Number,
    default: 0
  },
  
  // Scheduling
  scheduledStartDate: {
    type: Date,
    default: null
  },
  scheduledEndDate: {
    type: Date,
    default: null
  },
  
  // Metadata & Configuration
  metadata: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  config: {
    maxProducts: { type: Number, default: 50 },
    allowFlashDeals: { type: Boolean, default: true },
    autoActivate: { type: Boolean, default: false }
  },
  
  // Deployment & Notes
  deploymentNotes: {
    type: String,
    default: ''
  },
  lastActivatedAt: {
    type: Date,
    default: null
  },
  lastDeactivatedAt: {
    type: Date,
    default: null
  },
  
  // Statistics (for analytics)
  stats: {
    totalProducts: { type: Number, default: 0 },
    totalViews: { type: Number, default: 0 },
    totalOrders: { type: Number, default: 0 },
    lastSyncedAt: { type: Date, default: null }
  },
  
  // Versioning (for future use)
  version: {
    type: Number,
    default: 1
  },
  
  // Legacy fields (keep for backward compatibility)
  additionalInfo: { 
    type: String,
    default: ''
  }
}, {
  timestamps: true,
  collection: 'scripts'
});

// Indexes for better query performance
ScriptSchema.index({ name: 'text', description: 'text', tags: 'text' });
ScriptSchema.index({ createdAt: -1 });
ScriptSchema.index({ priority: -1, displayOrder: -1 });

// Pre-save middleware to update stats
ScriptSchema.pre('save', function(next) {
  // Update lastActivatedAt when isActive changes to true
  if (this.isModified('isActive') && this.isActive) {
    this.lastActivatedAt = new Date();
  } else if (this.isModified('isActive') && !this.isActive) {
    this.lastDeactivatedAt = new Date();
  }
  next();
});

// Virtual for active status check
ScriptSchema.virtual('isCurrentlyActive').get(function() {
  const now = new Date();
  const isScheduledActive = this.visibility === 'scheduled' && 
                           this.scheduledStartDate && 
                           this.scheduledEndDate &&
                           now >= this.scheduledStartDate && 
                           now <= this.scheduledEndDate;
  
  return this.isActive || isScheduledActive;
});

// Methods
ScriptSchema.methods.activate = function() {
  this.isActive = true;
  this.status = 'active';
  this.lastActivatedAt = new Date();
  return this.save();
};

ScriptSchema.methods.deactivate = function() {
  this.isActive = false;
  this.status = 'inactive';
  this.lastDeactivatedAt = new Date();
  return this.save();
};

ScriptSchema.methods.archive = function() {
  this.status = 'archived';
  this.isActive = false;
  return this.save();
};

// Statics for common queries
ScriptSchema.statics.findActive = function() {
  return this.find({ isActive: true, status: 'active' });
};

ScriptSchema.statics.findByCategory = function(category: string) {
  return this.find({ category }).sort({ priority: -1, displayOrder: -1 });
};

ScriptSchema.statics.searchScripts = function(query: string) {
  return this.find(
    { $text: { $search: query } },
    { score: { $meta: 'textScore' } }
  ).sort({ score: { $meta: 'textScore' } });
};

export default mongoose.models.Script || mongoose.model('Script', ScriptSchema);
