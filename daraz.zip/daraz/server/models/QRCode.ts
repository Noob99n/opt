import mongoose from 'mongoose';

const qrCodeSchema = new mongoose.Schema({
  imageUrl: {
    type: String,
    required: true
  },
  cloudinaryPublicId: {
    type: String,
    default: null
  },
  updatedAt: {
    type: Date,
    default: Date.now
  },
  updatedBy: {
    type: String,
    default: 'admin'
  },
  adminId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Admin',
    default: null,
    index: true
  },
  storeSlug: {
    type: String,
    default: null,
    index: true
  }
});

const QRCode = mongoose.model('QRCode', qrCodeSchema);

export default QRCode;
