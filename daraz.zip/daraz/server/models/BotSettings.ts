import mongoose from 'mongoose';

export interface IAdmin {
  userId: number;
  username?: string;
  firstName?: string;
  addedAt: Date;
}

export interface IBotSettings {
  _id?: string;
  admins: IAdmin[];
  botToken: string;
  updatedAt: Date;
}

const AdminSchema = new mongoose.Schema({
  userId: {
    type: Number,
    required: true,
    unique: false
  },
  username: {
    type: String,
    required: false
  },
  firstName: {
    type: String,
    required: false
  },
  addedAt: {
    type: Date,
    default: Date.now
  }
});

const BotSettingsSchema = new mongoose.Schema({
  admins: {
    type: [AdminSchema],
    default: []
  },
  botToken: {
    type: String,
    required: true
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

BotSettingsSchema.pre('save', function(next) {
  this.updatedAt = new Date();
  next();
});

const BotSettings = mongoose.model<IBotSettings>('BotSettings', BotSettingsSchema);

export default BotSettings;
