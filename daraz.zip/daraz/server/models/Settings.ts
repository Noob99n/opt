import mongoose from 'mongoose';

const SettingsSchema = new mongoose.Schema({
  key: { type: String, required: true, unique: true },
  value: { type: String, required: true },
}, {
  timestamps: true
});

const Settings = mongoose.models.Settings || mongoose.model('Settings', SettingsSchema);

export async function getSetting(key: string): Promise<string | null> {
  const setting = await Settings.findOne({ key });
  return setting?.value || null;
}

export async function setSetting(key: string, value: string): Promise<void> {
  await Settings.findOneAndUpdate(
    { key },
    { key, value },
    { upsert: true, new: true }
  );
}

export default Settings;