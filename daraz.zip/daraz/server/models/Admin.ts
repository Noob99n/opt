import mongoose from 'mongoose';
import bcrypt from 'bcrypt';

const AdminSchema = new mongoose.Schema({
  username: { 
    type: String, 
    required: true,
    unique: true,
    trim: true,
    index: true
  },
  password: { 
    type: String, 
    required: true,
    select: false
  },
  expiryDate: {
    type: Date,
    required: true,
    index: true
  },
  isActive: { 
    type: Boolean, 
    default: true,
    index: true
  },
  botToken: {
    type: String,
    default: null
  },
  botChatId: {
    type: String,
    default: null
  },
  storeSlug: {
    type: String,
    unique: true,
    sparse: true,
    index: true
  },
  activeScriptId: {
    type: String,
    default: null
  },
  lastLogin: {
    type: Date,
    default: null
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true,
  collection: 'admins'
});

AdminSchema.virtual('isExpired').get(function() {
  return new Date() > this.expiryDate;
});

AdminSchema.methods.isValid = function() {
  return this.isActive && !this.isExpired;
};

AdminSchema.methods.comparePassword = async function(candidatePassword: string): Promise<boolean> {
  return bcrypt.compare(candidatePassword, this.password);
};

AdminSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error: any) {
    next(error);
  }
});

export default mongoose.models.Admin || mongoose.model('Admin', AdminSchema);
