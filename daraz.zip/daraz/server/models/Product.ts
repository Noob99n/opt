import mongoose from 'mongoose';

const ProductSchema = new mongoose.Schema({
  title: { type: String, required: true },
  slug: { type: String },
  description: { type: String },
  price: { type: String, required: true },
  originalPrice: { type: String },
  category: { type: String, required: true },
  subcategory: { type: String },
  imageUrl: { type: String },
  imageUrl2: { type: String },
  imageUrl3: { type: String },
  imageUrl4: { type: String },
  rating: { type: String, default: '0' },
  reviewCount: { type: Number, default: 0 },
  isFlashSale: { type: Boolean, default: false },
  isScriptProduct: { type: Boolean, default: false },
  discount: { type: Number, default: 0 },
  stock: { type: Number, default: 0 },
  sold: { type: Number, default: 0 },
  brand: { type: String },
  specifications: { type: String }, // JSON string
}, {
  timestamps: true
});

// Generate slug from title before saving
ProductSchema.pre('save', function(next) {
  if (this.title && !this.slug) {
    this.slug = this.title
      .toLowerCase()
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .trim()
      .substring(0, 80);
  }
  next();
});

export default mongoose.models.Product || mongoose.model('Product', ProductSchema);