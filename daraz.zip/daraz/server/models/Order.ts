import mongoose from 'mongoose';

const OrderSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  addressId: { type: mongoose.Schema.Types.ObjectId, ref: 'Address', required: true },
  subtotal: { type: String, required: true },
  shippingFee: { type: String, required: true },
  total: { type: String, required: true },
  paymentMethod: { type: String, required: true },
  status: { type: String, default: 'pending' },
}, {
  timestamps: true
});

export default mongoose.models.Order || mongoose.model('Order', OrderSchema);