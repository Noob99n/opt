import mongoose from 'mongoose';

const transactionLogSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
    default: 'guest'
  },
  amount: {
    type: Number,
    required: true
  },
  productTitle: {
    type: String,
    required: true
  },
  screenshotUrl: {
    type: String,
    default: ''
  },
  status: {
    type: String,
    enum: ['pending', 'approved', 'declined', 'verified', 'failed'],
    default: 'pending'
  },
  timestamp: {
    type: Date,
    default: Date.now
  },
  telegramMessageId: {
    type: Number,
    default: null
  },
  adminId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Admin',
    default: null,
    index: true
  },
  storeSlug: {
    type: String,
    default: null,
    index: true
  }
});

const TransactionLog = mongoose.model('TransactionLog', transactionLogSchema);

export default TransactionLog;
