import mongoose from 'mongoose';

const AddressSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  fullName: { type: String, required: true },
  phoneNumber: { type: String, required: true },
  province: { type: String, required: true },
  city: { type: String, required: true },
  zone: { type: String, required: true },
  address: { type: String, required: true },
  landmark: { type: String },
  label: { type: String, required: true }, // HOME, OFFICE
  isDefaultShipping: { type: Boolean, default: false },
  isDefaultBilling: { type: Boolean, default: false },
}, {
  timestamps: true
});

export default mongoose.models.Address || mongoose.model('Address', AddressSchema);