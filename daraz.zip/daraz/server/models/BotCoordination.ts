import mongoose from 'mongoose';

const BotCoordinationSchema = new mongoose.Schema({
  instanceId: { type: String, required: true },
  adminId: { type: String, required: true },
  botToken: { type: String, required: true },
  isActive: { type: Boolean, default: true },
  lastHeartbeat: { type: Date, default: Date.now },
  startedAt: { type: Date, default: Date.now },
  host: { type: String },
  port: { type: Number }
}, {
  timestamps: true
});

// Compound unique index - one record per (instanceId, adminId) pair
BotCoordinationSchema.index({ instanceId: 1, adminId: 1 }, { unique: true });
BotCoordinationSchema.index({ adminId: 1 });
BotCoordinationSchema.index({ lastHeartbeat: 1 });
BotCoordinationSchema.index({ isActive: 1 });

export default mongoose.model('BotCoordination', BotCoordinationSchema);
