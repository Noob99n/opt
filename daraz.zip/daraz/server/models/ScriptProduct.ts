import mongoose from 'mongoose';

const ScriptProductSchema = new mongoose.Schema({
  // References - Using String for scriptId since scripts use custom string IDs
  scriptId: { 
    type: String, 
    required: true,
    index: true
  },
  productId: { 
    type: String,
    index: true
  },
  
  // Display & Ordering
  order: { 
    type: Number, 
    default: 0,
    index: true
  },
  displayOrder: {
    type: Number,
    default: 0
  },
  
  // Product Type & Flags
  isFlashDeal: { 
    type: Boolean, 
    default: false,
    index: true
  },
  isFeatured: {
    type: Boolean,
    default: false
  },
  isHidden: {
    type: Boolean,
    default: false
  },
  
  // Grouping & Organization
  group: {
    type: String,
    default: 'default'
  },
  section: {
    type: String,
    enum: ['hero', 'flash-sale', 'trending', 'recommended', 'regular'],
    default: 'regular'
  },
  
  // Custom Overrides (optional overrides for this specific script-product combination)
  customTitle: {
    type: String,
    default: null
  },
  customPrice: {
    type: Number,
    default: null
  },
  customDiscount: {
    type: Number,
    default: null
  },
  customImage: {
    type: String,
    default: null
  },
  
  // Scheduling
  availableFrom: {
    type: Date,
    default: null
  },
  availableTo: {
    type: Date,
    default: null
  },
  
  // Stock & Limits
  maxQuantity: {
    type: Number,
    default: null // null means no limit
  },
  soldCount: {
    type: Number,
    default: 0
  },
  
  // Metadata
  metadata: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  notes: {
    type: String,
    default: ''
  },
  
  // Stats (for analytics)
  stats: {
    views: { type: Number, default: 0 },
    clicks: { type: Number, default: 0 },
    addToCarts: { type: Number, default: 0 },
    purchases: { type: Number, default: 0 }
  }
}, {
  timestamps: true,
  collection: 'script_products'
});

// Compound indexes for better query performance
ScriptProductSchema.index({ scriptId: 1, order: 1 });
ScriptProductSchema.index({ scriptId: 1, isFlashDeal: 1 });
ScriptProductSchema.index({ scriptId: 1, section: 1, order: 1 });
ScriptProductSchema.index({ productId: 1, scriptId: 1 }, { unique: true }); // Prevent duplicates

// Virtual for availability check
ScriptProductSchema.virtual('isCurrentlyAvailable').get(function() {
  if (this.isHidden) return false;
  
  const now = new Date();
  const afterStart = !this.availableFrom || now >= this.availableFrom;
  const beforeEnd = !this.availableTo || now <= this.availableTo;
  const stockAvailable = !this.maxQuantity || this.soldCount < this.maxQuantity;
  
  return afterStart && beforeEnd && stockAvailable;
});

// Methods
ScriptProductSchema.methods.incrementViews = function() {
  this.stats.views += 1;
  return this.save();
};

ScriptProductSchema.methods.incrementClicks = function() {
  this.stats.clicks += 1;
  return this.save();
};

ScriptProductSchema.methods.incrementAddToCarts = function() {
  this.stats.addToCarts += 1;
  return this.save();
};

ScriptProductSchema.methods.recordPurchase = function(quantity = 1) {
  this.stats.purchases += quantity;
  this.soldCount += quantity;
  return this.save();
};

// Statics
ScriptProductSchema.statics.findByScript = function(scriptId: string) {
  return this.find({ scriptId }).sort({ order: 1, displayOrder: 1 });
};

ScriptProductSchema.statics.findFlashDeals = function(scriptId: string) {
  return this.find({ scriptId, isFlashDeal: true }).sort({ order: 1 });
};

ScriptProductSchema.statics.findBySection = function(scriptId: string, section: string) {
  return this.find({ scriptId, section }).sort({ order: 1 });
};

ScriptProductSchema.statics.reorderProducts = async function(scriptId: string, productOrders: Array<{productId: string, order: number}>) {
  const bulkOps = productOrders.map(({ productId, order }) => ({
    updateOne: {
      filter: { scriptId, productId },
      update: { $set: { order } }
    }
  }));
  
  return this.bulkWrite(bulkOps);
};

export default mongoose.models.ScriptProduct || mongoose.model('ScriptProduct', ScriptProductSchema);
