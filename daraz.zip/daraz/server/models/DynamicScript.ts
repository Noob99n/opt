import mongoose from 'mongoose';

// Dynamic collection creator for each script
class DynamicScriptManager {
  
  // Create a new collection for a script
  static createScriptCollection(scriptName: string) {
    const collectionName = `script_${scriptName.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
    
    const ScriptCollectionSchema = new mongoose.Schema({
      // Script info
      scriptName: { type: String, required: true },
      isActive: { type: Boolean, default: false },
      description: { type: String },
      
      // Products array within the same collection
      products: [{
        title: { type: String, required: true },
        description: { type: String },
        price: { type: String, required: true },
        originalPrice: { type: String },
        category: { type: String, default: 'Miscellaneous' },
        subcategory: { type: String, default: 'Others' },
        imageUrl: { type: String },
        imageUrl2: { type: String },
        imageUrl3: { type: String },
        imageUrl4: { type: String },
        rating: { type: String, default: '0' },
        reviewCount: { type: Number, default: 0 },
        discount: { type: Number, default: 0 },
        stock: { type: Number, default: 0 },
        sold: { type: Number, default: 0 },
        brand: { type: String },
        isFlashDeal: { type: Boolean, default: false },
        order: { type: Number, default: 0 },
        
        // Product Details
        model: { type: String },
        modelYear: { type: String },
        displayProtection: { type: String },
        
        // Specifications
        specifications: {
          display: { type: String },
          size: { type: String },
          resolution: { type: String },
          contrastRatio: { type: String },
          brightness: { type: String },
          features: { type: String },
          waterResistance: { type: String },
          chip: { type: String },
          cpu: { type: String },
          gpu: { type: String },
          neuralEngine: { type: String },
          operatingSystem: { type: String },
          camera: { type: String },
          storage: { type: String },
          ram: { type: String },
          color: { type: String }
        },
        
        // Delivery Information
        delivery: {
          location: { type: String, default: 'Bagmati, Kathmandu Metro 22 - Newroad Area, Newroad' },
          type: { type: String, default: 'Standard Delivery' },
          timeframe: { type: String, default: 'Guaranteed by 21-24 Jul' },
          cost: { type: String, default: '75' }
        },
        
        // Service Information
        service: {
          returnPolicy: { type: String, default: '14 Days Free Returns' },
          returnNote: { type: String, default: 'Change of mind is not applicable' },
          warranty: { type: String, default: '2 Years Brand Warranty' }
        },
        
        // Product Highlights
        highlights: [{ type: String }],
        
        // Technical Details
        technicalDetails: [{ type: String }],
        
        // Description Content
        descriptionContent: { type: String },
        descriptionImages: [{ type: String }],
        
        createdAt: { type: Date, default: Date.now }
      }]
    }, {
      timestamps: true,
      collection: collectionName
    });
    
    // Return the model for this collection
    return mongoose.models[collectionName] || mongoose.model(collectionName, ScriptCollectionSchema);
  }
  
  // Get all script collections
  static async getAllScriptCollections() {
    const db = mongoose.connection.db;
    const collections = await db.listCollections().toArray();
    
    return collections
      .filter(col => col.name.startsWith('script_'))
      .map(col => ({
        collectionName: col.name,
        scriptName: col.name.replace('script_', '').replace(/_/g, ' ')
      }));
  }
  
  // Get specific script collection
  static getScriptModel(scriptName: string) {
    const collectionName = `script_${scriptName.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
    
    // If model doesn't exist, try to create it
    if (!mongoose.models[collectionName]) {
      try {
        return this.createScriptCollection(scriptName);
      } catch (error) {
        console.error('Error creating script model:', error);
        return null;
      }
    }
    
    return mongoose.models[collectionName];
  }
  
  // Delete entire script collection
  static async deleteScriptCollection(scriptName: string) {
    const collectionName = `script_${scriptName.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
    const db = mongoose.connection.db;
    
    try {
      await db.dropCollection(collectionName);
      // Also remove from mongoose models
      delete mongoose.models[collectionName];
      return true;
    } catch (error) {
      console.error('Error deleting collection:', error);
      return false;
    }
  }
}

export default DynamicScriptManager;