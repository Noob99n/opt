// Client to communicate with standalone bot server
// Used when DISABLE_TELEGRAM_BOT=true (multi-VPS setup)

const BOT_SERVER_URL = process.env.BOT_SERVER_URL || '';
const BOT_SERVER_API_KEY = process.env.BOT_SERVER_API_KEY || '';

export function isBotServerEnabled(): boolean {
  return process.env.DISABLE_TELEGRAM_BOT === 'true' && !!BOT_SERVER_URL;
}

async function callBotServer(endpoint: string, data: any = {}): Promise<boolean> {
  if (!isBotServerEnabled()) {
    return false;
  }
  
  try {
    const response = await fetch(`${BOT_SERVER_URL}${endpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': BOT_SERVER_API_KEY
      },
      body: JSON.stringify(data)
    });
    
    const result = await response.json();
    console.log(`📡 [BOT SERVER] ${endpoint}:`, result);
    return result.success === true;
  } catch (error) {
    console.error(`❌ [BOT SERVER] Failed to call ${endpoint}:`, error);
    return false;
  }
}

// Start/Restart admin bot on external server
export async function notifyStartAdminBot(
  adminId: string, 
  botToken: string, 
  chatId: string, 
  storeSlug: string
): Promise<boolean> {
  return callBotServer('/api/admin-bot/start', { adminId, botToken, chatId, storeSlug });
}

// Stop admin bot on external server
export async function notifyStopAdminBot(adminId: string): Promise<boolean> {
  return callBotServer('/api/admin-bot/stop', { adminId });
}

// Reload owner bot on external server
export async function notifyReloadOwnerBot(botToken?: string): Promise<boolean> {
  return callBotServer('/api/owner-bot/reload', botToken ? { botToken } : {});
}

// Refresh all admin bots on external server
export async function notifyRefreshAllBots(): Promise<boolean> {
  return callBotServer('/api/admin-bots/refresh', {});
}
