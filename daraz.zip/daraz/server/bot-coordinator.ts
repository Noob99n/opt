import { v4 as uuidv4 } from 'uuid';
import BotCoordination from './models/BotCoordination';
import Admin from './models/Admin';
import { startAdminBot, stopAdminBot, getAdminBotStatus, getActiveBotCount } from './bot-manager';

const HEARTBEAT_INTERVAL = 30000; // 30 seconds
const HEARTBEAT_TIMEOUT = 90000; // 90 seconds - consider dead if no heartbeat
const CHECK_INTERVAL = 60000; // Check every 60 seconds for dead bots

let instanceId: string;
let heartbeatTimer: ReturnType<typeof setInterval> | null = null;
let checkTimer: ReturnType<typeof setInterval> | null = null;
let isRunning = false;

export function getInstanceId(): string {
  if (!instanceId) {
    instanceId = `bot_${uuidv4().substring(0, 8)}_${Date.now()}`;
  }
  return instanceId;
}

async function sendHeartbeat(adminId: string): Promise<void> {
  try {
    await BotCoordination.findOneAndUpdate(
      { instanceId: getInstanceId(), adminId },
      { 
        lastHeartbeat: new Date(),
        isActive: true 
      },
      { upsert: false }
    );
  } catch (err) {
    console.error(`❌ [BOT COORD] Heartbeat failed for ${adminId}:`, err);
  }
}

async function canStartBot(adminId: string): Promise<boolean> {
  try {
    const now = new Date();
    const timeoutDate = new Date(now.getTime() - HEARTBEAT_TIMEOUT);
    
    const activeBot = await BotCoordination.findOne({
      adminId,
      isActive: true,
      lastHeartbeat: { $gte: timeoutDate }
    });
    
    if (activeBot && activeBot.instanceId !== getInstanceId()) {
      console.log(`⚠️ [BOT COORD] Bot for admin ${adminId} already running on instance ${activeBot.instanceId}`);
      return false;
    }
    
    const staleBot = await BotCoordination.findOne({
      adminId,
      isActive: true,
      lastHeartbeat: { $lt: timeoutDate }
    });
    
    if (staleBot) {
      console.log(`🔄 [BOT COORD] Taking over stale bot for admin ${adminId} (last heartbeat: ${staleBot.lastHeartbeat})`);
      await BotCoordination.deleteOne({ _id: staleBot._id });
    }
    
    return true;
  } catch (err) {
    console.error(`❌ [BOT COORD] Error checking bot status:`, err);
    return false;
  }
}

export async function startBotWithCoordination(adminId: string, botToken: string, storeSlug: string, chatId: string): Promise<boolean> {
  try {
    const canStart = await canStartBot(adminId);
    
    if (!canStart) {
      console.log(`⏭️ [BOT COORD] Skipping bot start for ${storeSlug} - already active elsewhere`);
      return false;
    }
    
    await BotCoordination.findOneAndUpdate(
      { instanceId: getInstanceId(), adminId },
      {
        instanceId: getInstanceId(),
        adminId,
        botToken,
        isActive: true,
        lastHeartbeat: new Date(),
        startedAt: new Date(),
        host: process.env.REPL_SLUG || process.env.HOSTNAME || 'unknown',
        port: parseInt(process.env.PORT || '5000')
      },
      { upsert: true, new: true }
    );
    
    // Note: startAdminBot params are (adminId, botToken, chatId, storeSlug)
    const success = await startAdminBot(adminId, botToken, chatId, storeSlug);
    
    if (success) {
      console.log(`✅ [BOT COORD] Bot started for ${storeSlug} on instance ${getInstanceId()}`);
      
      if (!heartbeatTimer) {
        heartbeatTimer = setInterval(async () => {
          const activeAdmins = await Admin.find({ 
            botToken: { $exists: true, $ne: null },
            chatId: { $exists: true, $ne: null }
          });
          
          for (const admin of activeAdmins) {
            if (getAdminBotStatus(admin._id.toString())) {
              await sendHeartbeat(admin._id.toString());
            }
          }
        }, HEARTBEAT_INTERVAL);
      }
      
      return true;
    } else {
      await BotCoordination.deleteOne({ instanceId: getInstanceId(), adminId });
      return false;
    }
  } catch (err) {
    console.error(`❌ [BOT COORD] Error starting bot:`, err);
    return false;
  }
}

export async function stopBotWithCoordination(adminId: string): Promise<void> {
  try {
    await BotCoordination.findOneAndUpdate(
      { instanceId: getInstanceId(), adminId },
      { isActive: false }
    );
    
    await stopAdminBot(adminId);
    console.log(`✅ [BOT COORD] Bot stopped for admin ${adminId}`);
  } catch (err) {
    console.error(`❌ [BOT COORD] Error stopping bot:`, err);
  }
}

async function checkAndTakeoverStaleBots(): Promise<void> {
  try {
    const now = new Date();
    const timeoutDate = new Date(now.getTime() - HEARTBEAT_TIMEOUT);
    
    const staleBots = await BotCoordination.find({
      isActive: true,
      lastHeartbeat: { $lt: timeoutDate }
    });
    
    for (const staleBot of staleBots) {
      console.log(`🔄 [BOT COORD] Found stale bot for admin ${staleBot.adminId}, attempting takeover...`);
      
      const admin = await Admin.findById(staleBot.adminId);
      if (admin && admin.botToken && admin.chatId) {
        await BotCoordination.deleteOne({ _id: staleBot._id });
        
        const success = await startBotWithCoordination(
          admin._id.toString(),
          admin.botToken,
          admin.storeSlug,
          admin.chatId
        );
        
        if (success) {
          console.log(`✅ [BOT COORD] Takeover successful for ${admin.storeSlug}`);
        }
      }
    }
  } catch (err) {
    console.error(`❌ [BOT COORD] Error checking stale bots:`, err);
  }
}

export async function initializeBotCoordination(): Promise<void> {
  if (isRunning) {
    console.log(`⚠️ [BOT COORD] Already initialized`);
    return;
  }
  
  isRunning = true;
  console.log(`🚀 [BOT COORD] Initializing bot coordination (instance: ${getInstanceId()})`);
  
  try {
    const adminsWithBots = await Admin.find({
      botToken: { $exists: true, $ne: null },
      chatId: { $exists: true, $ne: null }
    });
    
    console.log(`📋 [BOT COORD] Found ${adminsWithBots.length} admins with configured bots`);
    
    for (const admin of adminsWithBots) {
      await startBotWithCoordination(
        admin._id.toString(),
        admin.botToken,
        admin.storeSlug,
        admin.chatId
      );
      // Small delay to avoid rate limits
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    checkTimer = setInterval(checkAndTakeoverStaleBots, CHECK_INTERVAL);
    
    console.log(`✅ [BOT COORD] Initialization complete. Active bots: ${getActiveBotCount()}`);
  } catch (err) {
    console.error(`❌ [BOT COORD] Initialization error:`, err);
    isRunning = false;
  }
}

export async function cleanupBotCoordination(): Promise<void> {
  console.log(`🛑 [BOT COORD] Cleaning up...`);
  
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
  
  if (checkTimer) {
    clearInterval(checkTimer);
    checkTimer = null;
  }
  
  try {
    await BotCoordination.updateMany(
      { instanceId: getInstanceId() },
      { isActive: false }
    );
  } catch (err) {
    console.error(`❌ [BOT COORD] Cleanup error:`, err);
  }
  
  isRunning = false;
}

export async function getBotCoordinationStatus(): Promise<any[]> {
  try {
    const records = await BotCoordination.find({ isActive: true }).lean();
    return records;
  } catch (err) {
    return [];
  }
}
