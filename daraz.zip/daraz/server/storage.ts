import connectDB from './mongodb';
import Product from './models/Product';
import Category from './models/Category';
import CartItem from './models/CartItem';
import Address from './models/Address';
import Order from './models/Order';
import OrderItem from './models/OrderItem';
import Script from './models/Script';
import ScriptProduct from './models/ScriptProduct';
import Settings from './models/Settings';
import TransactionLog from './models/TransactionLog';
import QRCode from './models/QRCode';
import Admin from './models/Admin';
import { fallbackProducts, fallbackCategories, fallbackScripts, fallbackSettings } from './fallback-data';
import { InMemoryPersistence } from './persistence';
import DynamicScriptManager from './models/DynamicScript';
import mongoose from 'mongoose';
import { log, error as logError } from './logger';

// Utility function to generate URL-friendly slugs
function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^\w\s-]/g, '') // Remove special characters
    .replace(/\s+/g, '-') // Replace spaces with hyphens
    .replace(/-+/g, '-') // Replace multiple hyphens with single
    .trim()
    .substring(0, 80); // Limit length
}

export interface IStorage {
  // Products
  getProducts(): Promise<any[]>;
  getProduct(id: string): Promise<any | undefined>;
  getProductBySlug(slug: string): Promise<any | undefined>;
  getProductsByCategory(category: string): Promise<any[]>;
  searchProducts(query: string): Promise<any[]>;
  getFlashSaleProducts(): Promise<any[]>;
  createProduct(product: any): Promise<any>;
  updateProduct(id: string, updates: any): Promise<any>;
  
  // Categories
  getCategories(): Promise<any[]>;
  createCategory(category: any): Promise<any>;
  
  // Cart Items
  getCartItems(userId: string): Promise<any[]>;
  addCartItem(cartItem: any): Promise<any>;
  updateCartItem(id: string, cartItem: any): Promise<any>;
  removeCartItem(id: string): Promise<void>;
  clearCart(userId: string): Promise<void>;
  
  // Addresses
  getAddresses(userId: string): Promise<any[]>;
  createAddress(address: any): Promise<any>;
  updateAddress(id: string, address: any): Promise<any>;
  removeAddress(id: string): Promise<void>;
  
  // Orders
  getOrders(userId: string): Promise<any[]>;
  getOrder(id: string): Promise<any | undefined>;
  createOrder(order: any): Promise<any>;
  updateOrderStatus(id: string, status: string): Promise<any>;
  
  // Order Items
  getOrderItems(orderId: string): Promise<any[]>;
  createOrderItem(orderItem: any): Promise<any>;
  
  // Settings
  getSettings(): Promise<{ script: string }>;
  updateSettings(settings: { script: string }): Promise<{ script: string }>;
  
  // Scripts
  getScripts(): Promise<any[]>;
  getScript(id: string): Promise<any | undefined>;
  createScript(script: any): Promise<any>;
  updateScript(id: string, script: any): Promise<any>;
  deleteScript(id: string): Promise<void>;
  activateScript(scriptId: string): Promise<void>;
  
  // Script Products
  getScriptProducts(scriptId: string): Promise<any[]>;
  addProductToScript(scriptProduct: any): Promise<any>;
  removeProductFromScript(scriptId: string, productId: string): Promise<void>;
  removeScriptProduct(scriptProductId: string): Promise<void>;
  updateScriptProduct(scriptName: string, productId: string, updates: any): Promise<any>;
  updateScriptProductById(scriptId: string, productId: string, updates: any): Promise<any>;
  
  // Transaction Logs
  createTransactionLog(log: any): Promise<any>;
  getTransactionById(id: string): Promise<any>;
  getTransactionLogs(): Promise<any[]>;
  getTodayTransactions(): Promise<any[]>;
  deleteAllTransactionLogs(): Promise<void>;
  
  // QR Code
  getQRCode(): Promise<string | null>;
  updateQRCode(imageUrl: string): Promise<void>;
}

// Global initialization flag to prevent multiple connection attempts
let globalInitialized = false;
let globalInitializing = false;

export class MongoStorage implements IStorage {
  private connectionAttempted = false;
  
  constructor() {
    // Don't call async in constructor - it will be called when needed
  }

  private async ensureInitialized() {
    // If already initialized globally, just return
    if (globalInitialized) {
      return true;
    }

    // If currently initializing, wait for it to complete
    if (globalInitializing) {
      // Wait a bit and check again
      await new Promise(resolve => setTimeout(resolve, 100));
      return globalInitialized;
    }

    globalInitializing = true;
    
    try {
      log('🔄 Connecting to MongoDB with new credentials...');
      await connectDB();
      log('✅ MongoDB connected successfully');
      // await this.seedData(); // Disabled - User wants fresh start
      
      // Auto-activate iPhone script if it exists
      try {
        await this.activateScript('script_iphone');
        log('📱 Auto-activated iPhone script on startup');
      } catch (error: any) {
        log('⚠️ Could not auto-activate script:', error.message);
      }
      
      globalInitialized = true;
      log('✅ MongoDB initialized successfully');
      
      // Migrate admins without storeSlug
      await this.migrateAdminStoreSlugs();
    } catch (error: any) {
      // Only log once to avoid console spam
      if (!this.connectionAttempted) {
        if (error.message && error.message.includes('authentication failed')) {
          logError('❌ MongoDB authentication failed - Check username/password');
          log('💡 Current connection string may have wrong credentials');
        } else if (error.message && error.message.includes('IP')) {
          logError('❌ MongoDB connection failed - IP not whitelisted in Atlas');
          log('💡 Fix: Add 0.0.0.0/0 to MongoDB Atlas Network Access');
        } else {
          logError('❌ MongoDB connection failed:', error.message || error);
        }
        log('📝 Using persistent in-memory storage');
        this.connectionAttempted = true;
      }
      globalInitialized = false;
      return false;
    } finally {
      globalInitializing = false;
    }
    
    return true;
  }

  // Admin storeSlug migration helper
  private async migrateAdminStoreSlugs() {
    try {
      const adminsWithoutSlug = await Admin.find({ 
        $or: [
          { storeSlug: null }, 
          { storeSlug: { $exists: false } }, 
          { storeSlug: '' }
        ] 
      });
      
      for (const admin of adminsWithoutSlug) {
        const baseSlug = generateSlug(admin.username);
        let slug = baseSlug;
        let counter = 1;
        
        while (await Admin.findOne({ storeSlug: slug, _id: { $ne: admin._id } })) {
          slug = `${baseSlug}-${counter}`;
          counter++;
        }
        
        admin.storeSlug = slug;
        await admin.save();
        console.log(`🔄 Migrated admin ${admin.username} with storeSlug: ${slug}`);
      }
      
      if (adminsWithoutSlug.length > 0) {
        console.log(`✅ Migrated ${adminsWithoutSlug.length} admins with storeSlugs`);
      }
    } catch (error) {
      console.error('Error migrating admin store slugs:', error);
    }
  }
  
  // Scripts - Using dynamic collections
  async getScripts(): Promise<any[]> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      const persistedScripts = InMemoryPersistence.getScripts();
      return persistedScripts.length > 0 ? persistedScripts : fallbackScripts;
    }
    try {
      const scriptCollections = await DynamicScriptManager.getAllScriptCollections();
      
      const scripts = [];
      for (const collection of scriptCollections) {
        const model = DynamicScriptManager.getScriptModel(collection.scriptName);
        if (model) {
          const scriptData = await model.findOne();
          if (scriptData) {
            scripts.push({
              _id: collection.collectionName,
              name: collection.scriptName,
              isActive: scriptData.isActive,
              description: scriptData.description,
              productsCount: scriptData.products?.length || 0,
              collectionName: collection.collectionName
            });
          }
        }
      }
      return scripts;
    } catch (error) {
      console.error('Error getting scripts:', error);
      return fallbackScripts;
    }
  }

  async getScript(id: string): Promise<any | undefined> {
    await this.ensureInitialized();
    try {
      let scriptName = id;
      if (id.startsWith('script_')) {
        scriptName = id.replace('script_', '').replace(/_/g, ' ');
      }
      
      const model = DynamicScriptManager.getScriptModel(scriptName);
      if (!model) return undefined;
      
      const scriptData = await model.findOne();
      return scriptData || undefined;
    } catch (error) {
      return undefined;
    }
  }

  async createScript(script: any): Promise<any> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return InMemoryPersistence.addScript(script);
    }
    try {
      // Create dynamic collection for this script
      const ScriptModel = DynamicScriptManager.createScriptCollection(script.name);
      
      // Create new script document in its own collection
      const newScript = new ScriptModel({
        scriptName: script.name,
        isActive: script.isActive || false,
        description: script.description || null,
        products: [] // Start with empty products array
      });
      
      const savedScript = await newScript.save();
      
      return {
        _id: `script_${script.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
        name: script.name,
        isActive: savedScript.isActive,
        description: savedScript.description,
        collectionName: `script_${script.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
        createdAt: savedScript.createdAt
      };
    } catch (error) {
      console.error('Error creating script:', error);
      throw error;
    }
  }

  async updateScript(id: string, script: any): Promise<any> {
    await this.ensureInitialized();
    try {
      let scriptName = id;
      if (id.startsWith('script_')) {
        scriptName = id.replace('script_', '').replace(/_/g, ' ');
      }
      
      const model = DynamicScriptManager.getScriptModel(scriptName);
      if (!model) throw new Error('Script not found');
      
      return await model.findOneAndUpdate({}, script, { new: true }).lean();
    } catch (error) {
      throw error;
    }
  }

  async deleteScript(id: string): Promise<void> {
    await this.ensureInitialized();
    try {
      let scriptName = id;
      if (id.startsWith('script_')) {
        scriptName = id.replace('script_', '').replace(/_/g, ' ');
      }
      
      await DynamicScriptManager.deleteScriptCollection(scriptName);
    } catch (error) {
      console.error('Error deleting script:', error);
      throw error;
    }
  }

  async activateScript(scriptId: string): Promise<void> {
    if (!scriptId || scriptId === 'undefined' || scriptId === 'null') {
      throw new Error('Valid script ID is required');
    }
    
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      InMemoryPersistence.activateScript(scriptId);
      return;
    }
    try {
      const scriptCollections = await DynamicScriptManager.getAllScriptCollections();
      
      // Deactivate all scripts
      for (const collection of scriptCollections) {
        const model = DynamicScriptManager.getScriptModel(collection.scriptName);
        if (model) {
          await model.findOneAndUpdate({}, { isActive: false });
        }
      }
      
      // Activate the selected script
      let scriptName = scriptId;
      if (scriptId.startsWith('script_')) {
        scriptName = scriptId.replace('script_', '').replace(/_/g, ' ');
      }
      
      const selectedModel = DynamicScriptManager.getScriptModel(scriptName);
      if (selectedModel) {
        await selectedModel.findOneAndUpdate({}, { isActive: true });
      }
      
      // Map script to valid setting value
      let settingValue = 'none';
      if (scriptId.includes('iphone') || scriptId.includes('phone')) {
        settingValue = 'phone';
      } else if (scriptId.includes('watch')) {
        settingValue = 'watch';
      }
      
      await this.updateSettings({ script: settingValue });
    } catch (error) {
      console.error('Error activating script:', error);
      throw error;
    }
  }

  // Script Products - Now within script collections
  async getScriptProducts(scriptId: string): Promise<any[]> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return [];
    }
    try {
      let scriptName = scriptId;
      if (scriptId.startsWith('script_')) {
        scriptName = scriptId.replace('script_', '').replace(/_/g, ' ');
      }
      
      const model = DynamicScriptManager.getScriptModel(scriptName);
      if (!model) return [];
      
      // Products are embedded documents, no need to populate
      const scriptData = await model.findOne();
      return scriptData?.products || [];
    } catch (error) {
      console.error('Error getting script products:', error);
      return [];
    }
  }

  async addProductToScript(scriptProduct: any): Promise<any> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return InMemoryPersistence.addScriptProduct(scriptProduct);
    }
    try {
      let scriptName = scriptProduct.scriptId;
      if (scriptProduct.scriptId.startsWith('script_')) {
        scriptName = scriptProduct.scriptId.replace('script_', '').replace(/_/g, ' ');
      }
      
      const model = DynamicScriptManager.getScriptModel(scriptName);
      if (!model) throw new Error('Script not found');
      
      const scriptData = await model.findOne();
      if (!scriptData) throw new Error('Script data not found');
      
      // Validate required fields
      if (!scriptProduct.title || !scriptProduct.price) {
        throw new Error('Title and price are required');
      }

      // Handle images array - use images array if provided, otherwise use individual imageUrl fields
      const imagesArray = scriptProduct.images || [];
      const imageUrl = imagesArray[0] || scriptProduct.imageUrl || '';
      const imageUrl2 = imagesArray[1] || scriptProduct.imageUrl2 || '';
      const imageUrl3 = imagesArray[2] || scriptProduct.imageUrl3 || '';
      const imageUrl4 = imagesArray[3] || scriptProduct.imageUrl4 || '';
      
      const newProduct = {
        title: scriptProduct.title,
        description: Array.isArray(scriptProduct.description) 
          ? scriptProduct.description.join('\n') 
          : (scriptProduct.description || ''),
        price: scriptProduct.price,
        originalPrice: scriptProduct.originalPrice || scriptProduct.price,
        category: scriptProduct.category || 'Miscellaneous',
        subcategory: scriptProduct.subcategory || 'Others',
        // Store both formats for compatibility
        images: [imageUrl, imageUrl2, imageUrl3, imageUrl4].filter(img => img),
        imageUrl: imageUrl,
        imageUrl2: imageUrl2,
        imageUrl3: imageUrl3,
        imageUrl4: imageUrl4,
        rating: scriptProduct.rating || '0',
        reviewCount: scriptProduct.reviewCount || 0,
        discount: scriptProduct.discount || 0,
        stock: scriptProduct.stock || 999,
        sold: scriptProduct.sold || 0,
        brand: scriptProduct.brand || '',
        model: scriptProduct.model || '',
        isFlashDeal: scriptProduct.isFlashDeal || false,
        order: scriptProduct.order || 0,
        highlights: scriptProduct.highlights || [],
        review: scriptProduct.review || '',
        technicalDetails: scriptProduct.technicalDetails || [],
        descriptionImages: scriptProduct.descriptionImages || [],
        descriptionContent: scriptProduct.descriptionContent || '',
        specifications: scriptProduct.specifications || {},
        // Daraz-specific fields
        colorVariants: scriptProduct.colorVariants || [],
        deliveryLocation: scriptProduct.deliveryLocation || 'Kathmandu',
        deliveryCharge: scriptProduct.deliveryCharge || '75',
        freeReturn: scriptProduct.freeReturn || '14 Days Free Return',
        warranty: scriptProduct.warranty || '1 Year Brand Warranty',
        disclaimer: scriptProduct.disclaimer || '',
        delivery: scriptProduct.delivery || {
          location: "Bagmati, Kathmandu Metro 22 - Newroad Area, Newroad",
          type: "Standard Delivery", 
          timeframe: "Guaranteed by 21-24 Jul",
          cost: "75"
        },
        service: scriptProduct.service || {
          returnPolicy: "14 Days Free Returns",
          returnNote: "Change of mind is not applicable", 
          warranty: "2 Years Brand Warranty"
        },
        createdAt: new Date()
      };
      
      scriptData.products.push(newProduct);
      await scriptData.save();
      
      return newProduct;
    } catch (error) {
      console.error('Error adding product to script:', error);
      throw error;
    }
  }

  // Placeholder implementations for interface requirements
  async getProducts(): Promise<any[]> { return []; }
  async getProduct(id: string): Promise<any | undefined> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return undefined;
    }
    try {
      const scripts = await this.getScripts();
      
      for (const script of scripts) {
        const products = await this.getScriptProducts(script._id);
        
        for (const product of products) {
          if (product._id && product._id.toString() === id) {
            return product;
          }
        }
      }
      
      return undefined;
    } catch (error) {
      console.error('Error getting product:', error);
      return undefined;
    }
  }
  async getProductBySlug(slug: string): Promise<any | undefined> {
    // For now, treat slug same as ID since we're using MongoDB ObjectIds
    return this.getProduct(slug);
  }
  async getProductsByCategory(category: string): Promise<any[]> { return []; }
  async searchProducts(query: string): Promise<any[]> { return []; }
  async getFlashSaleProducts(): Promise<any[]> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return InMemoryPersistence.getFlashSaleProducts();
    }
    try {
      const scripts = await this.getScripts();
      const activeScripts = scripts.filter(script => script.isActive);
      
      let allFlashProducts: any[] = [];
      
      for (const script of activeScripts) {
        const products = await this.getScriptProducts(script._id);
        const flashProducts = products.filter(product => product.isFlashDeal);
        allFlashProducts = [...allFlashProducts, ...flashProducts];
      }
      
      return allFlashProducts;
    } catch (error: any) {
      console.error('Error getting flash sale products:', error);
      return [];
    }
  }
  async createProduct(product: any): Promise<any> { return {}; }
  async updateProduct(id: string, updates: any): Promise<any> { 
    // This is a placeholder - product updates are handled via updateScriptProduct with 3 params
    // Direct updateProduct calls are not supported in current architecture
    return {}; 
  }
  async getCategories(): Promise<any[]> { return []; }
  async createCategory(category: any): Promise<any> { return {}; }
  async getCartItems(userId: string): Promise<any[]> { return []; }
  async addCartItem(cartItem: any): Promise<any> { return {}; }
  async updateCartItem(id: string, cartItem: any): Promise<any> { return {}; }
  async removeCartItem(id: string): Promise<void> {}
  async clearCart(userId: string): Promise<void> {}
  async getAddresses(userId: string): Promise<any[]> { return []; }
  async createAddress(address: any): Promise<any> { return {}; }
  async updateAddress(id: string, address: any): Promise<any> { return {}; }
  async removeAddress(id: string): Promise<void> {}
  async getOrders(userId: string): Promise<any[]> { return []; }
  async getOrder(id: string): Promise<any | undefined> { return undefined; }
  async createOrder(order: any): Promise<any> { return {}; }
  async updateOrderStatus(id: string, status: string): Promise<any> { return {}; }
  async getOrderItems(orderId: string): Promise<any[]> { return []; }
  async createOrderItem(orderItem: any): Promise<any> { return {}; }
  async getSettings(): Promise<{ script: string }> { return { script: 'none' }; }
  async updateSettings(settings: { script: string }): Promise<{ script: string }> { return settings; }
  async removeProductFromScript(scriptId: string, productId: string): Promise<void> {}
  async removeScriptProduct(scriptProductId: string): Promise<void> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return InMemoryPersistence.removeScriptProduct(scriptProductId);
    }
    try {
      // Find which script contains this product and remove it
      const scripts = await this.getScripts();
      
      for (const script of scripts) {
        const model = DynamicScriptManager.getScriptModel(script.name);
        if (model) {
          const scriptData = await model.findOne();
          if (scriptData && scriptData.products) {
            const initialLength = scriptData.products.length;
            scriptData.products = scriptData.products.filter((product: any) => 
              product._id.toString() !== scriptProductId
            );
            
            if (scriptData.products.length < initialLength) {
              await scriptData.save();
              console.log(`Product ${scriptProductId} removed from script ${script.name}`);
              return;
            }
          }
        }
      }
      console.log(`Product ${scriptProductId} not found in any script`);
    } catch (error) {
      console.error('Error removing script product:', error);
      throw error;
    }
  }
  async updateScriptProduct(scriptName: string, productId: string, updates: any): Promise<any> { 
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return InMemoryPersistence.updateScriptProduct(productId, updates);
    }
    try {
      console.log('🔍 Looking for script:', scriptName);
      
      // DON'T trim! The script name might have trailing space which is significant
      // DynamicScriptManager.getScriptModel handles the conversion to collection name
      const collectionName = `script_${scriptName.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
      
      console.log('📦 Expected collection name:', collectionName);
      
      // Get the script model - pass script name as-is
      const model = DynamicScriptManager.getScriptModel(scriptName);
      if (!model) {
        throw new Error(`Script model for "${scriptName}" not found`);
      }
      
      console.log('🔎 Finding product with ID:', productId);
      
      // Convert productId string to ObjectId for MongoDB query
      const productObjectId = new mongoose.Types.ObjectId(productId);
      console.log('🔄 Converted to ObjectId:', productObjectId);
      
      // First, check if the script document exists
      const scriptDoc = await model.findOne();
      if (!scriptDoc) {
        throw new Error(`Script document not found for ${scriptName}`);
      }
      console.log('📄 Script document found, products count:', scriptDoc.products?.length || 0);
      
      // Check if product exists in the array
      const productExists = scriptDoc.products?.some((p: any) => p._id.toString() === productId);
      console.log('🔍 Product exists in array:', productExists);
      
      if (scriptDoc.products && scriptDoc.products.length > 0) {
        console.log('📋 First product ID:', scriptDoc.products[0]._id.toString());
      }
      
      // Use MongoDB positional operator to update embedded document
      const result = await model.findOneAndUpdate(
        { 'products._id': productObjectId },
        { $set: updates },
        { new: true }
      );
      
      if (!result) {
        throw new Error(`Product ${productId} not found in script ${scriptName}`);
      }
      
      // Find and return the updated product
      const updatedProduct = result.products.find((p: any) => p._id.toString() === productId);
      console.log('✅ Product updated successfully:', updatedProduct?.title);
      
      return updatedProduct;
    } catch (error: any) {
      console.error('❌ Error updating script product:', error);
      throw error;
    }
  }

  async updateScriptProductById(scriptId: string, productId: string, updates: any): Promise<any> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return InMemoryPersistence.updateScriptProduct(productId, updates);
    }
    try {
      const productObjectId = new mongoose.Types.ObjectId(productId);
      const scripts = await this.getScripts();
      
      for (const script of scripts) {
        const model = DynamicScriptManager.getScriptModel(script.name);
        if (!model) continue;
        
        const scriptData = await model.findOne({ 'products._id': productObjectId });
        if (!scriptData) continue;
        
        const updateFields: any = {};
        for (const [key, value] of Object.entries(updates)) {
          updateFields[`products.$.${key}`] = value;
        }
        
        const result = await model.findOneAndUpdate(
          { 'products._id': productObjectId },
          { $set: updateFields },
          { new: true }
        );
        
        if (result) {
          const updatedProduct = result.products.find((p: any) => p._id.toString() === productId);
          console.log('✅ Product updated by ID:', updatedProduct?.title);
          return updatedProduct;
        }
      }
      
      console.error(`Product ${productId} not found in any script`);
      return null;
    } catch (error: any) {
      console.error('❌ Error updating script product by ID:', error);
      throw error;
    }
  }
  
  async createTransactionLog(log: any): Promise<any> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return {};
    }
    try {
      const transaction = new TransactionLog(log);
      await transaction.save();
      return transaction;
    } catch (error) {
      console.error('Error creating transaction log:', error);
      throw error;
    }
  }
  
  async getTransactionById(id: string): Promise<any> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return null;
    }
    try {
      const transaction = await TransactionLog.findById(id);
      return transaction;
    } catch (error) {
      console.error('Error getting transaction by ID:', error);
      return null;
    }
  }
  
  async getTransactionLogs(): Promise<any[]> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return [];
    }
    try {
      const logs = await TransactionLog.find().sort({ timestamp: -1 });
      return logs;
    } catch (error) {
      console.error('Error getting transaction logs:', error);
      return [];
    }
  }
  
  async getTodayTransactions(): Promise<any[]> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return [];
    }
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const logs = await TransactionLog.find({
        timestamp: { $gte: today }
      });
      return logs;
    } catch (error) {
      console.error('Error getting today transactions:', error);
      return [];
    }
  }
  
  async deleteAllTransactionLogs(): Promise<void> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return;
    }
    try {
      await TransactionLog.deleteMany({});
    } catch (error) {
      console.error('Error deleting transaction logs:', error);
      throw error;
    }
  }
  
  async getQRCode(): Promise<string | null> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return null;
    }
    try {
      const qr = await QRCode.findOne();
      return qr ? qr.imageUrl : null;
    } catch (error) {
      console.error('Error getting QR code:', error);
      return null;
    }
  }
  
  async updateQRCode(imageUrl: string): Promise<void> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return;
    }
    try {
      await QRCode.findOneAndUpdate(
        {},
        { imageUrl, updatedAt: new Date() },
        { upsert: true, new: true }
      );
    } catch (error) {
      console.error('Error updating QR code:', error);
      throw error;
    }
  }
}

export const storage = new MongoStorage();