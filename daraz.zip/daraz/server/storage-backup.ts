import connectDB from './mongodb';
import Product from './models/Product';
import Category from './models/Category';
import CartItem from './models/CartItem';
import Address from './models/Address';
import Order from './models/Order';
import OrderItem from './models/OrderItem';
import Script from './models/Script';
import ScriptProduct from './models/ScriptProduct';
import Settings from './models/Settings';
import { fallbackProducts, fallbackCategories, fallbackScripts, fallbackSettings } from './fallback-data';
import { InMemoryPersistence } from './persistence';

// Utility function to generate URL-friendly slugs
function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^\w\s-]/g, '') // Remove special characters
    .replace(/\s+/g, '-') // Replace spaces with hyphens
    .replace(/-+/g, '-') // Replace multiple hyphens with single
    .trim()
    .substring(0, 80); // Limit length
}

export interface IStorage {
  // Products
  getProducts(): Promise<any[]>;
  getProduct(id: string): Promise<any | undefined>;
  getProductBySlug(slug: string): Promise<any | undefined>;
  getProductsByCategory(category: string): Promise<any[]>;
  searchProducts(query: string): Promise<any[]>;
  getFlashSaleProducts(): Promise<any[]>;
  createProduct(product: any): Promise<any>;
  
  // Categories
  getCategories(): Promise<any[]>;
  getCategory(id: string): Promise<any | undefined>;
  createCategory(category: any): Promise<any>;
  
  // Cart
  getCartItems(userId: string): Promise<any[]>;
  addToCart(cartItem: any): Promise<any>;
  updateCartItem(id: string, quantity: number): Promise<any>;
  removeFromCart(id: string): Promise<void>;
  clearCart(userId: string): Promise<void>;
  
  // Addresses
  getAddresses(userId: string): Promise<any[]>;
  getAddress(id: string): Promise<any | undefined>;
  createAddress(address: any): Promise<any>;
  updateAddress(id: string, address: any): Promise<any>;
  deleteAddress(id: string): Promise<void>;
  
  // Orders
  getOrders(userId: string): Promise<any[]>;
  getOrder(id: string): Promise<any | undefined>;
  createOrder(order: any): Promise<any>;
  getOrderItems(orderId: string): Promise<any[]>;
  createOrderItem(orderItem: any): Promise<any>;
  
  // Settings
  getSettings(): Promise<{ script: string }>;
  updateSettings(settings: { script: string }): Promise<{ script: string }>;
  
  // Scripts
  getScripts(): Promise<any[]>;
  getScript(id: string): Promise<any | undefined>;
  createScript(script: any): Promise<any>;
  updateScript(id: string, script: any): Promise<any>;
  deleteScript(id: string): Promise<void>;
  activateScript(scriptId: string): Promise<void>;
  
  // Product management
  updateProduct(id: string, product: any): Promise<any>;
  deleteProduct(id: string): Promise<void>;
  
  // Script Products
  getScriptProducts(scriptId: string): Promise<any[]>;
  addProductToScript(scriptProduct: any): Promise<any>;
  removeProductFromScript(scriptId: string, productId: string): Promise<void>;
  removeScriptProduct(scriptProductId: string): Promise<void>;
  updateScriptProduct(id: string, updates: any): Promise<any>;
}

// Global initialization flag to prevent multiple connection attempts
let globalInitialized = false;
let globalInitializing = false;

export class MongoStorage implements IStorage {
  private connectionAttempted = false;
  
  constructor() {
    // Don't call async in constructor - it will be called when needed
  }

  private async ensureInitialized() {
    // If already initialized globally, just return
    if (globalInitialized) {
      return true;
    }

    // If currently initializing, wait for it to complete
    if (globalInitializing) {
      // Wait a bit and check again
      await new Promise(resolve => setTimeout(resolve, 100));
      return globalInitialized;
    }

    globalInitializing = true;
    
    try {
      console.log('🔄 Connecting to MongoDB with new credentials...');
      await connectDB();
      console.log('✅ MongoDB connected successfully');
      // await this.seedData(); // Disabled - User wants fresh start
      globalInitialized = true;
      console.log('✅ MongoDB initialized successfully');
    } catch (error) {
      // Only log once to avoid console spam
      if (!this.connectionAttempted) {
        if (error.message.includes('authentication failed')) {
          console.log('❌ MongoDB authentication failed - Check username/password');
          console.log('💡 Current connection string may have wrong credentials');
        } else if (error.message.includes('IP')) {
          console.log('❌ MongoDB connection failed - IP not whitelisted in Atlas');
          console.log('💡 Fix: Add 0.0.0.0/0 to MongoDB Atlas Network Access');
        } else {
          console.log('❌ MongoDB connection failed:', error.message);
        }
        console.log('📝 Using persistent in-memory storage');
        this.connectionAttempted = true;
      }
      globalInitialized = false;
      return false;
    } finally {
      globalInitializing = false;
    }
    
    return true;
  }

  private async seedData() {
    try {
      // Check if data already exists
      const existingProducts = await Product.countDocuments();
      if (existingProducts > 0) {
        return; // Data already seeded
      }

      // Seed categories
      const categoryData = [
        { name: "Electronics", icon: "smartphone", color: "bg-blue-100 text-blue-600" },
        { name: "Fashion", icon: "shirt", color: "bg-purple-100 text-purple-600" },
        { name: "Beauty", icon: "sparkles", color: "bg-pink-100 text-pink-600" },
        { name: "Home & Garden", icon: "home", color: "bg-green-100 text-green-600" },
        { name: "Sports & Outdoors", icon: "dumbbell", color: "bg-yellow-100 text-yellow-600" },
        { name: "Books & Media", icon: "book", color: "bg-indigo-100 text-indigo-600" },
        { name: "Health & Wellness", icon: "heart", color: "bg-red-100 text-red-600" },
        { name: "Toys & Games", icon: "gamepad", color: "bg-orange-100 text-orange-600" },
      ];

      await Category.insertMany(categoryData);

      // Seed products
      const productData = [
        {
          title: "Vintage T-9 Hair Trimmer For Men Battery",
          description: "Professional hair trimmer with battery operation",
          price: "299.00",
          originalPrice: "1500.00",
          category: "Beauty",
          imageUrl: "https://res.cloudinary.com/dtporx34i/image/upload/v1752388177/dbcf6796af6b330d362b6b6a6d0fc5e1.png_2200x2200q80.png__1751697300192_u5djyb.webp",
          rating: "4.5",
          reviewCount: 349,
          isFlashSale: true,
          discount: 80,
          stock: 50,
          sold: 122,
          brand: "No Brand",
        },
        {
          title: "Rechargeable 2 In 1 Flawless Facial And Eye Hair Remover",
          description: "2-in-1 facial and eye hair remover with rechargeable battery",
          price: "389.00",
          originalPrice: "1200.00",
          category: "Beauty",
          imageUrl: "https://res.cloudinary.com/dtporx34i/image/upload/v1752388177/0e32bef6f90df0f3653c998543e656b0.png_2200x2200q80.png__1751697300070_cjy7uw.webp",
          rating: "4.7",
          reviewCount: 35,
          isFlashSale: true,
          discount: 67,
          stock: 30,
          sold: 60,
          brand: "Pei Mei",
        },
      ];

      await Product.insertMany(productData);

      // Create default script
      const defaultScript = await Script.create({
        name: "Default Script",
        description: "Default product display script",
        isActive: true,
      });

      // Create script products
      const products = await Product.find();
      const scriptProducts = products.map(product => ({
        scriptId: defaultScript._id,
        productId: product._id,
        isFlashDeal: product.isFlashSale,
        order: 0,
      }));

      await ScriptProduct.insertMany(scriptProducts);

      // Set default settings
      await Settings.create({
        key: 'script',
        value: defaultScript._id.toString(),
      });

    } catch (error) {
      console.error('Error seeding data:', error);
    }
  }

  // Products
  async getProducts(): Promise<any[]> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      // Use persistent in-memory storage or fallback
      const persistedProducts = InMemoryPersistence.getProducts();
      return persistedProducts.length > 0 ? persistedProducts : fallbackProducts;
    }
    try {
      return await Product.find().lean();
    } catch (error) {
      return fallbackProducts;
    }
  }

  async getProduct(id: string): Promise<any | undefined> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) return fallbackProducts.find(p => p._id === id);
    try {
      const product = await Product.findById(id).lean();
      return product || undefined;
    } catch (error) {
      return fallbackProducts.find(p => p._id === id);
    }
  }

  async getProductBySlug(slug: string): Promise<any | undefined> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) return fallbackProducts.find(p => p.slug === slug);
    try {
      const product = await Product.findOne({ slug }).lean();
      return product || undefined;
    } catch (error) {
      return fallbackProducts.find(p => p.slug === slug);
    }
  }

  async getProductsByCategory(category: string): Promise<any[]> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) return fallbackProducts.filter(p => p.category === category);
    try {
      return await Product.find({ category }).lean();
    } catch (error) {
      return fallbackProducts.filter(p => p.category === category);
    }
  }

  async searchProducts(query: string): Promise<any[]> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return fallbackProducts.filter(p => 
        p.title.toLowerCase().includes(query.toLowerCase())
      );
    }
    try {
      return await Product.find({
        title: { $regex: query, $options: 'i' }
      }).lean();
    } catch (error) {
      return fallbackProducts.filter(p => 
        p.title.toLowerCase().includes(query.toLowerCase())
      );
    }
  }

  async getFlashSaleProducts(): Promise<any[]> {
    const isInitialized = await this.ensureInitialized();
    
    // First get the active script
    const settings = await this.getSettings();
    if (settings.script === 'none') {
      return []; // No active script, no products to show
    }
    
    try {
      // Get the active script products
      const scriptProducts = await this.getScriptProducts(settings.script);
      if (scriptProducts.length === 0) {
        return []; // Active script has no products
      }
      
      // Extract the products from script products and filter for flash deals
      const products = scriptProducts
        .filter((sp: any) => sp.isFlashDeal && sp.productId)
        .map((sp: any) => sp.productId);
      
      return products;
    } catch (error) {
      console.error('Error getting flash sale products:', error);
      return [];
    }
  }

  async createProduct(product: any): Promise<any> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      // Use persistent in-memory storage
      return InMemoryPersistence.addProduct(product);
    }
    try {
      const newProduct = new Product(product);
      return await newProduct.save();
    } catch (error) {
      console.error('Error creating product:', error);
      throw error;
    }
  }

  async updateProduct(id: string, product: any): Promise<any> {
    await this.ensureInitialized();
    return await Product.findByIdAndUpdate(id, product, { new: true }).lean();
  }

  async deleteProduct(id: string): Promise<void> {
    await this.ensureInitialized();
    await Product.findByIdAndDelete(id);
  }

  // Categories
  async getCategories(): Promise<any[]> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) return fallbackCategories;
    try {
      return await Category.find().lean();
    } catch (error) {
      return fallbackCategories;
    }
  }

  async getCategory(id: string): Promise<any | undefined> {
    await this.ensureInitialized();
    const category = await Category.findById(id).lean();
    return category || undefined;
  }

  async createCategory(category: any): Promise<any> {
    await this.ensureInitialized();
    const newCategory = new Category(category);
    return await newCategory.save();
  }

  // Cart
  async getCartItems(userId: string): Promise<any[]> {
    await this.ensureInitialized();
    return await CartItem.find({ userId }).populate('productId').lean();
  }

  async addToCart(cartItem: any): Promise<any> {
    await this.ensureInitialized();
    const newCartItem = new CartItem(cartItem);
    return await newCartItem.save();
  }

  async updateCartItem(id: string, quantity: number): Promise<any> {
    await this.ensureInitialized();
    return await CartItem.findByIdAndUpdate(id, { quantity }, { new: true }).lean();
  }

  async removeFromCart(id: string): Promise<void> {
    await this.ensureInitialized();
    await CartItem.findByIdAndDelete(id);
  }

  async clearCart(userId: string): Promise<void> {
    await this.ensureInitialized();
    await CartItem.deleteMany({ userId });
  }

  // Addresses
  async getAddresses(userId: string): Promise<any[]> {
    await this.ensureInitialized();
    return await Address.find({ userId }).lean();
  }

  async getAddress(id: string): Promise<any | undefined> {
    await this.ensureInitialized();
    const address = await Address.findById(id).lean();
    return address || undefined;
  }

  async createAddress(address: any): Promise<any> {
    await this.ensureInitialized();
    const newAddress = new Address(address);
    return await newAddress.save();
  }

  async updateAddress(id: string, address: any): Promise<any> {
    await this.ensureInitialized();
    return await Address.findByIdAndUpdate(id, address, { new: true }).lean();
  }

  async deleteAddress(id: string): Promise<void> {
    await this.ensureInitialized();
    await Address.findByIdAndDelete(id);
  }

  // Orders
  async getOrders(userId: string): Promise<any[]> {
    await this.ensureInitialized();
    return await Order.find({ userId }).lean();
  }

  async getOrder(id: string): Promise<any | undefined> {
    await this.ensureInitialized();
    const order = await Order.findById(id).lean();
    return order || undefined;
  }

  async createOrder(order: any): Promise<any> {
    await this.ensureInitialized();
    const newOrder = new Order(order);
    return await newOrder.save();
  }

  async getOrderItems(orderId: string): Promise<any[]> {
    await this.ensureInitialized();
    return await OrderItem.find({ orderId }).populate('productId').lean();
  }

  async createOrderItem(orderItem: any): Promise<any> {
    await this.ensureInitialized();
    const newOrderItem = new OrderItem(orderItem);
    return await newOrderItem.save();
  }

  // Settings
  async getSettings(): Promise<{ script: string }> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      // Use persistent in-memory storage or fallback
      const persistedSettings = InMemoryPersistence.getSettings();
      return persistedSettings.script !== 'none' ? persistedSettings : fallbackSettings;
    }
    try {
      const setting = await Settings.findOne({ key: 'script' }).lean();
      return { script: setting?.value || 'none' };
    } catch (error) {
      return fallbackSettings;
    }
  }

  async updateSettings(settings: { script: string }): Promise<{ script: string }> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      // Use persistent in-memory storage
      return InMemoryPersistence.updateSettings(settings);
    }
    try {
      await Settings.findOneAndUpdate(
        { key: 'script' },
        { value: settings.script },
        { upsert: true }
      );
      return settings;
    } catch (error) {
      console.error('Error updating settings:', error);
      throw error;
    }
  }

  // Scripts - Now using dynamic collections
  async getScripts(): Promise<any[]> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      // Use persistent in-memory storage or fallback
      const persistedScripts = InMemoryPersistence.getScripts();
      return persistedScripts.length > 0 ? persistedScripts : fallbackScripts;
    }
    try {
      // Import DynamicScriptManager here to avoid circular imports
      const DynamicScriptManager = (await import('./models/DynamicScript')).default;
      const scriptCollections = await DynamicScriptManager.getAllScriptCollections();
      
      const scripts = [];
      for (const collection of scriptCollections) {
        const model = DynamicScriptManager.getScriptModel(collection.scriptName);
        if (model) {
          const scriptData = await model.findOne();
          if (scriptData) {
            scripts.push({
              _id: collection.collectionName,
              name: collection.scriptName,
              isActive: scriptData.isActive,
              description: scriptData.description,
              productsCount: scriptData.products?.length || 0,
              collectionName: collection.collectionName
            });
          }
        }
      }
      return scripts;
    } catch (error) {
      console.error('Error getting scripts:', error);
      return fallbackScripts;
    }
  }

  async getScript(id: string): Promise<any | undefined> {
    await this.ensureInitialized();
    const script = await Script.findById(id).lean();
    return script || undefined;
  }

  async createScript(script: any): Promise<any> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      // Use persistent in-memory storage
      return InMemoryPersistence.addScript(script);
    }
    try {
      // Import DynamicScriptManager
      const DynamicScriptManager = (await import('./models/DynamicScript')).default;
      
      // Create dynamic collection for this script
      const ScriptModel = DynamicScriptManager.createScriptCollection(script.name);
      
      // Create new script document in its own collection
      const newScript = new ScriptModel({
        scriptName: script.name,
        isActive: script.isActive || false,
        description: script.description || null,
        products: [] // Start with empty products array
      });
      
      const savedScript = await newScript.save();
      
      return {
        _id: `script_${script.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
        name: script.name,
        isActive: savedScript.isActive,
        description: savedScript.description,
        collectionName: `script_${script.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
        createdAt: savedScript.createdAt
      };
    } catch (error) {
      console.error('Error creating script:', error);
      throw error;
    }
  }

  async updateScript(id: string, script: any): Promise<any> {
    await this.ensureInitialized();
    return await Script.findByIdAndUpdate(id, script, { new: true }).lean();
  }

  async deleteScript(id: string): Promise<void> {
    await this.ensureInitialized();
    try {
      // Import DynamicScriptManager
      const DynamicScriptManager = (await import('./models/DynamicScript')).default;
      
      // If it's a collection name, extract script name
      let scriptName = id;
      if (id.startsWith('script_')) {
        scriptName = id.replace('script_', '').replace(/_/g, ' ');
      }
      
      // Delete the entire collection
      await DynamicScriptManager.deleteScriptCollection(scriptName);
    } catch (error) {
      console.error('Error deleting script:', error);
      throw error;
    }
  }

  async activateScript(scriptId: string): Promise<void> {
    // Validate script ID first
    if (!scriptId || scriptId === 'undefined' || scriptId === 'null') {
      throw new Error('Valid script ID is required');
    }
    
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      // Use persistent in-memory storage
      InMemoryPersistence.activateScript(scriptId);
      return;
    }
    try {
      // Import DynamicScriptManager
      const DynamicScriptManager = (await import('./models/DynamicScript')).default;
      
      // Get all script collections to deactivate them
      const scriptCollections = await DynamicScriptManager.getAllScriptCollections();
      
      // Deactivate all scripts
      for (const collection of scriptCollections) {
        const model = DynamicScriptManager.getScriptModel(collection.scriptName);
        if (model) {
          await model.findOneAndUpdate({}, { isActive: false });
        }
      }
      
      // Activate the selected script
      let scriptName = scriptId;
      if (scriptId.startsWith('script_')) {
        scriptName = scriptId.replace('script_', '').replace(/_/g, ' ');
      }
      
      const selectedModel = DynamicScriptManager.getScriptModel(scriptName);
      if (selectedModel) {
        await selectedModel.findOneAndUpdate({}, { isActive: true });
      }
      
      // Update settings
      await this.updateSettings({ script: scriptId });
    } catch (error) {
      console.error('Error activating script:', error);
      throw error;
    }
  }

  // Script Products - Now within script collections
  async getScriptProducts(scriptId: string): Promise<any[]> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      return [];
    }
    try {
      // Import DynamicScriptManager
      const { DynamicScriptManager } = await import('./models/DynamicScript');
      
      // Extract script name from scriptId
      let scriptName = scriptId;
      if (scriptId.startsWith('script_')) {
        scriptName = scriptId.replace('script_', '').replace(/_/g, ' ');
      }
      
      const model = DynamicScriptManager.getScriptModel(scriptName);
      if (!model) return [];
      
      const scriptData = await model.findOne();
      return scriptData?.products || [];
    } catch (error) {
      console.error('Error getting script products:', error);
      return [];
    }
  }

  async addProductToScript(scriptProduct: any): Promise<any> {
    const isInitialized = await this.ensureInitialized();
    if (!isInitialized) {
      // Use persistent in-memory storage
      return InMemoryPersistence.addScriptProduct(scriptProduct);
    }
    try {
      // Import DynamicScriptManager
      const { DynamicScriptManager } = await import('./models/DynamicScript');
      
      // Extract script name from scriptId
      let scriptName = scriptProduct.scriptId;
      if (scriptProduct.scriptId.startsWith('script_')) {
        scriptName = scriptProduct.scriptId.replace('script_', '').replace(/_/g, ' ');
      }
      
      const model = DynamicScriptManager.getScriptModel(scriptName);
      if (!model) throw new Error('Script not found');
      
      // Add product to the products array
      const scriptData = await model.findOne();
      if (!scriptData) throw new Error('Script data not found');
      
      const newProduct = {
        title: scriptProduct.title,
        description: scriptProduct.description,
        price: scriptProduct.price,
        originalPrice: scriptProduct.originalPrice,
        category: scriptProduct.category,
        imageUrl: scriptProduct.imageUrl,
        imageUrl2: scriptProduct.imageUrl2,
        imageUrl3: scriptProduct.imageUrl3,
        imageUrl4: scriptProduct.imageUrl4,
        rating: scriptProduct.rating || '0',
        reviewCount: scriptProduct.reviewCount || 0,
        discount: scriptProduct.discount || 0,
        stock: scriptProduct.stock || 999,
        sold: scriptProduct.sold || 0,
        brand: scriptProduct.brand,
        isFlashDeal: scriptProduct.isFlashDeal || false,
        order: scriptProduct.order || 0,
        highlights: scriptProduct.highlights || [],
        technicalDetails: scriptProduct.technicalDetails || [],
        descriptionImages: scriptProduct.descriptionImages || [],
        descriptionContent: scriptProduct.descriptionContent || '',
        specifications: scriptProduct.specifications || {},
        delivery: scriptProduct.delivery || {
          location: "Bagmati, Kathmandu Metro 22 - Newroad Area, Newroad",
          type: "Standard Delivery", 
          timeframe: "Guaranteed by 21-24 Jul",
          cost: "75"
        },
        service: scriptProduct.service || {
          returnPolicy: "14 Days Free Returns",
          returnNote: "Change of mind is not applicable", 
          warranty: "2 Years Brand Warranty"
        },
        createdAt: new Date()
      };
      
      scriptData.products.push(newProduct);
      await scriptData.save();
      
      return newProduct;
    } catch (error) {
      console.error('Error adding product to script:', error);
      throw error;
    }
  }

  async removeProductFromScript(scriptId: string, productId: string): Promise<void> {
    await this.ensureInitialized();
    await ScriptProduct.deleteOne({ scriptId, productId });
  }

  async removeScriptProduct(scriptProductId: string): Promise<void> {
    await this.ensureInitialized();
    await ScriptProduct.findByIdAndDelete(scriptProductId);
  }

  async updateScriptProduct(id: string, updates: any): Promise<any> {
    await this.ensureInitialized();
    return await ScriptProduct.findByIdAndUpdate(id, updates, { new: true }).lean();
  }
}

export const storage = new MongoStorage();