import { v2 as cloudinary } from 'cloudinary';

cloudinary.config({
  cloud_name: 'djbiyudvw',
  api_key: '237276653695988',
  api_secret: 'Bdy4aNMX6iknWhvD89YrJZsrvZw'
});

export async function uploadQRToCloudinary(imageUrl: string, folder: string = 'qr-codes'): Promise<{ url: string; publicId: string }> {
  try {
    const result = await cloudinary.uploader.upload(imageUrl, {
      folder: folder,
      resource_type: 'image',
      format: 'png',
      transformation: [
        { quality: 'auto:best' },
        { fetch_format: 'auto' }
      ]
    });
    
    console.log('✅ [Cloudinary] QR uploaded:', result.secure_url);
    return {
      url: result.secure_url,
      publicId: result.public_id
    };
  } catch (error: any) {
    console.error('❌ [Cloudinary] Upload error:', error.message);
    throw error;
  }
}

export async function deleteFromCloudinary(publicId: string): Promise<boolean> {
  try {
    if (!publicId) {
      console.log('⚠️ [Cloudinary] No publicId provided, skipping delete');
      return false;
    }
    
    const result = await cloudinary.uploader.destroy(publicId);
    console.log('✅ [Cloudinary] Deleted:', publicId, 'Result:', result.result);
    return result.result === 'ok';
  } catch (error: any) {
    console.error('❌ [Cloudinary] Delete error:', error.message);
    return false;
  }
}

export async function uploadBase64ToCloudinary(base64Data: string, folder: string = 'qr-codes'): Promise<{ url: string; publicId: string }> {
  try {
    const result = await cloudinary.uploader.upload(base64Data, {
      folder: folder,
      resource_type: 'image',
      format: 'png'
    });
    
    console.log('✅ [Cloudinary] Base64 QR uploaded:', result.secure_url);
    return {
      url: result.secure_url,
      publicId: result.public_id
    };
  } catch (error: any) {
    console.error('❌ [Cloudinary] Base64 upload error:', error.message);
    throw error;
  }
}

// Upload product image to Cloudinary
export async function uploadProductImage(base64Data: string, folder: string = 'products'): Promise<{ url: string; publicId: string }> {
  try {
    const result = await cloudinary.uploader.upload(base64Data, {
      folder: folder,
      resource_type: 'image',
      transformation: [
        { width: 800, height: 800, crop: 'limit' },
        { quality: 'auto:good' },
        { fetch_format: 'auto' }
      ]
    });
    
    console.log('✅ [Cloudinary] Product image uploaded:', result.secure_url);
    return {
      url: result.secure_url,
      publicId: result.public_id
    };
  } catch (error: any) {
    console.error('❌ [Cloudinary] Product image upload error:', error.message);
    throw error;
  }
}

export default cloudinary;
